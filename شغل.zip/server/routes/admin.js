const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const QRCode = require('qrcode');
const db = require('../db');
const config = require('../config');
const { requireAdmin } = require('../middleware/auth');
const { sanitizeBody } = require('../middleware/sanitize');
const { logAuditEvent } = require('../middleware/auditLog');

// Strict Admin-only middleware: Rejects any token that does not have role: 'admin'
router.use('/admin', requireAdmin);

// ==========================================
// 1. MENU & CATEGORY MANAGEMENT
// ==========================================

router.get('/admin/categories', (req, res) => {
  try {
    const categories = db.prepare(`
      SELECT id, name_ar, name_en, sort_order, created_at
      FROM categories
      ORDER BY sort_order ASC, name_ar ASC
    `).all();
    res.json({ success: true, data: categories });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب الفئات' });
  }
});

router.post('/admin/categories', sanitizeBody, (req, res) => {
  const { name_ar, name_en, sort_order } = req.body;
  if (!name_ar || !name_en) {
    return res.status(400).json({ success: false, error: 'اسم الفئة بالعربية والإنجليزية مطلوب' });
  }

  const id = 'cat-' + crypto.randomUUID().substring(0, 8);
  db.prepare(`
    INSERT INTO categories (id, name_ar, name_en, sort_order)
    VALUES (?, ?, ?, ?)
  `).run(id, name_ar.trim(), name_en.trim(), parseInt(sort_order, 10) || 0);

  res.status(201).json({ success: true, message: 'تم إضافة الفئة بنجاح', data: { id, name_ar, name_en, sort_order } });
});

router.put('/admin/categories/:id', sanitizeBody, (req, res) => {
  const { name_ar, name_en, sort_order } = req.body;
  const id = req.params.id;

  db.prepare(`
    UPDATE categories
    SET name_ar = ?, name_en = ?, sort_order = ?
    WHERE id = ?
  `).run(name_ar.trim(), name_en.trim(), parseInt(sort_order, 10) || 0, id);

  res.json({ success: true, message: 'تم تحديث الفئة بنجاح' });
});

router.delete('/admin/categories/:id', (req, res) => {
  const id = req.params.id;
  const itemsCount = db.prepare('SELECT COUNT(*) as count FROM menu_items WHERE category_id = ?').get(id).count;
  if (itemsCount > 0) {
    return res.status(400).json({
      success: false,
      error: `لا يمكن حذف الفئة لأنها تحتوي على ${itemsCount} أصناف. يرجى نقل أو حذف الأصناف أولاً.`
    });
  }

  db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  res.json({ success: true, message: 'تم حذف الفئة بنجاح' });
});

router.get('/admin/menu-items', (req, res) => {
  try {
    const items = db.prepare(`
      SELECT mi.*, c.name_ar as category_name_ar, c.name_en as category_name_en
      FROM menu_items mi
      JOIN categories c ON mi.category_id = c.id
      ORDER BY c.sort_order ASC, mi.name_ar ASC
    `).all();
    res.json({ success: true, data: items });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب قائمة الطعام' });
  }
});

router.post('/admin/menu-items', sanitizeBody, (req, res) => {
  const { category_id, name_ar, name_en, description_ar, description_en, price, image_url, is_available } = req.body;

  if (!category_id || !name_ar || !name_en || price === undefined) {
    return res.status(400).json({ success: false, error: 'الفئة، الأسماء، والسعر حقول مطلوبة' });
  }

  const numPrice = parseFloat(price);
  if (isNaN(numPrice) || numPrice < 0) {
    return res.status(400).json({ success: false, error: 'السعر غير صالح' });
  }

  const id = 'item-' + crypto.randomUUID().substring(0, 8);

  db.prepare(`
    INSERT INTO menu_items (id, category_id, name_ar, name_en, description_ar, description_en, price, image_url, is_available)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    category_id,
    name_ar.trim(),
    name_en.trim(),
    description_ar ? description_ar.trim() : '',
    description_en ? description_en.trim() : '',
    numPrice,
    image_url || null,
    is_available === undefined || is_available === 1 || is_available === true ? 1 : 0
  );

  res.status(201).json({ success: true, message: 'تم إضافة الصنف بنجاح', data: { id, name_ar, name_en, price: numPrice } });
});

router.put('/admin/menu-items/:id', sanitizeBody, (req, res) => {
  const id = req.params.id;
  const { category_id, name_ar, name_en, description_ar, description_en, price, image_url, is_available } = req.body;

  const numPrice = parseFloat(price);
  if (isNaN(numPrice) || numPrice < 0) {
    return res.status(400).json({ success: false, error: 'السعر غير صالح' });
  }

  db.prepare(`
    UPDATE menu_items
    SET category_id = ?, name_ar = ?, name_en = ?, description_ar = ?, description_en = ?,
        price = ?, image_url = ?, is_available = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(
    category_id,
    name_ar.trim(),
    name_en.trim(),
    description_ar ? description_ar.trim() : '',
    description_en ? description_en.trim() : '',
    numPrice,
    image_url || null,
    is_available === 1 || is_available === true ? 1 : 0,
    id
  );

  res.json({ success: true, message: 'تم تحديث بيانات الصنف بنجاح' });
});

router.patch('/admin/menu-items/:id/availability', (req, res) => {
  const id = req.params.id;
  const item = db.prepare('SELECT id, is_available, name_ar FROM menu_items WHERE id = ?').get(id);

  if (!item) {
    return res.status(404).json({ success: false, error: 'الصنف غير موجود' });
  }

  const newStatus = item.is_available ? 0 : 1;
  db.prepare(`UPDATE menu_items SET is_available = ?, updated_at = datetime('now') WHERE id = ?`).run(newStatus, id);

  res.json({
    success: true,
    message: `تم ${newStatus ? 'تفعيل' : 'إيقاف توفر'} صنف "${item.name_ar}" بنجاح`,
    data: { id, is_available: newStatus }
  });
});

router.delete('/admin/menu-items/:id', (req, res) => {
  const id = req.params.id;
  try {
    db.prepare('DELETE FROM menu_items WHERE id = ?').run(id);
    res.json({ success: true, message: 'تم حذف الصنف بنجاح' });
  } catch (err) {
    // If foreign key constraint triggered because orders reference this item
    db.prepare(`UPDATE menu_items SET is_available = 0, updated_at = datetime('now') WHERE id = ?`).run(id);
    res.json({
      success: true,
      message: 'تم إخفاء الصنف وتعطيله لأن هناك طلبات سابقة مرتبطة به في السجل'
    });
  }
});

// ==========================================
// 2. TABLES & QR CODE MANAGEMENT
// ==========================================

router.get('/admin/tables', (req, res) => {
  try {
    const tables = db.prepare(`
      SELECT t.*,
        (SELECT COUNT(*) FROM orders o WHERE o.table_id = t.id AND o.status IN ('new', 'preparing', 'ready', 'served')) as active_orders_count
      FROM tables t
      ORDER BY t.table_number ASC
    `).all();

    res.json({ success: true, data: tables });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب بيانات الطاولات' });
  }
});

router.post('/admin/tables', async (req, res) => {
  try {
    // Determine next table number or use requested
    let tableNumber = req.body.table_number ? parseInt(req.body.table_number, 10) : null;
    if (!tableNumber) {
      const maxRow = db.prepare('SELECT MAX(table_number) as max_num FROM tables').get();
      tableNumber = (maxRow.max_num || 0) + 1;
    }

    // Generate random non-sequential UUID
    const tableId = crypto.randomUUID();
    const tableUrl = `${config.clientUrl}/table/${tableId}`;

    // Generate high-resolution QR code data URL
    const qrDataUrl = await QRCode.toDataURL(tableUrl, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 400,
      color: {
        dark: '#1e293b',
        light: '#ffffff'
      }
    });

    db.prepare(`
      INSERT INTO tables (id, table_number, qr_code_url, is_active, created_at)
      VALUES (?, ?, ?, 1, datetime('now'))
    `).run(tableId, tableNumber, qrDataUrl);

    res.status(201).json({
      success: true,
      message: `تم إنشاء الطاولة رقم ${tableNumber} بنجاح وتوليد رمز الـ QR الخاص بها`,
      data: {
        id: tableId,
        table_number: tableNumber,
        qr_code_url: qrDataUrl,
        table_url: tableUrl,
        is_active: 1
      }
    });
  } catch (err) {
    console.error('[CREATE TABLE ERROR]', err);
    res.status(500).json({ success: false, error: 'حدث خطأ أثناء إضافة الطاولة (قد يكون رقم الطاولة مكرراً)' });
  }
});

router.patch('/admin/tables/:id/toggle', (req, res) => {
  const id = req.params.id;
  const table = db.prepare('SELECT id, is_active, table_number FROM tables WHERE id = ?').get(id);

  if (!table) {
    return res.status(404).json({ success: false, error: 'الطاولة غير موجودة' });
  }

  const newStatus = table.is_active ? 0 : 1;
  db.prepare('UPDATE tables SET is_active = ? WHERE id = ?').run(newStatus, id);

  res.json({
    success: true,
    message: `تم ${newStatus ? 'تفعيل' : 'تعطيل'} الطاولة رقم ${table.table_number}`,
    data: { id, is_active: newStatus }
  });
});

router.delete('/admin/tables/:id', (req, res) => {
  const id = req.params.id;
  try {
    db.prepare('DELETE FROM tables WHERE id = ?').run(id);
    res.json({ success: true, message: 'تم حذف الطاولة بنجاح' });
  } catch (err) {
    res.status(400).json({ success: false, error: 'لا يمكن حذف الطاولة لوجود طلبات سابقة مرتبطة بها. يمكنك تعطيلها بدلاً من ذلك.' });
  }
});

// ==========================================
// 3. REPORTS & ANALYTICS
// ==========================================

router.get('/admin/reports/sales', (req, res) => {
  try {
    // Total stats
    const totalStats = db.prepare(`
      SELECT 
        COUNT(*) as total_orders,
        COALESCE(SUM(total_amount), 0) as total_revenue,
        COALESCE(AVG(total_amount), 0) as avg_order_value
      FROM orders
      WHERE status = 'paid'
    `).get();

    // Today's stats
    const todayStats = db.prepare(`
      SELECT 
        COUNT(*) as today_orders,
        COALESCE(SUM(total_amount), 0) as today_revenue
      FROM orders
      WHERE status = 'paid' AND date(created_at) = date('now')
    `).get();

    // Last 7 days breakdown
    const dailyBreakdown = db.prepare(`
      SELECT 
        date(created_at) as order_date,
        COUNT(*) as orders_count,
        COALESCE(SUM(total_amount), 0) as revenue
      FROM orders
      WHERE status = 'paid' AND created_at >= datetime('now', '-7 days')
      GROUP BY date(created_at)
      ORDER BY order_date ASC
    `).all();

    res.json({
      success: true,
      data: {
        total: totalStats,
        today: todayStats,
        last7Days: dailyBreakdown
      }
    });
  } catch (err) {
    console.error('[SALES REPORT ERROR]', err);
    res.status(500).json({ success: false, error: 'فشل في استخراج تقارير المبيعات' });
  }
});

/**
 * GET /api/admin/reports/advanced
 * Advanced real-time interconnected analytics:
 * - Live Today Orders (Active in kitchen + Paid)
 * - Live Revenue (Real-time active value + Settled)
 * - Real 7-day trend chart
 * - Table live occupancy rate
 * - Category performance breakdown
 * - Live activity feed of latest orders
 */
router.get('/admin/reports/advanced', (req, res) => {
  try {
    // 1. Live Today KPIs (Connected with active and paid orders)
    const todayLiveStats = db.prepare(`
      SELECT 
        COUNT(*) as today_total_orders,
        COALESCE(SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END), 0) as today_paid_revenue,
        COALESCE(SUM(CASE WHEN status != 'paid' AND status != 'cancelled' THEN total_amount ELSE 0 END), 0) as today_active_revenue,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END), 0) as today_total_volume,
        COUNT(CASE WHEN status != 'paid' AND status != 'cancelled' THEN 1 END) as today_active_orders_count,
        COUNT(CASE WHEN status = 'paid' THEN 1 END) as today_paid_orders_count
      FROM orders
      WHERE date(created_at) = date('now')
    `).get();

    // 2. All-Time Cumulative KPIs
    const allTimeStats = db.prepare(`
      SELECT 
        COUNT(*) as total_orders_all_time,
        COALESCE(SUM(total_amount), 0) as total_revenue_all_time,
        COALESCE(AVG(total_amount), 0) as avg_order_value
      FROM orders
      WHERE status = 'paid'
    `).get();

    // 3. Live Table Occupancy
    const totalTablesRow = db.prepare(`SELECT COUNT(*) as count FROM tables WHERE is_active = 1`).get();
    const occupiedTablesRow = db.prepare(`
      SELECT COUNT(DISTINCT table_id) as count 
      FROM orders 
      WHERE status NOT IN ('paid', 'cancelled')
    `).get();

    const totalTables = totalTablesRow?.count || 0;
    const occupiedTables = occupiedTablesRow?.count || 0;
    const occupancyRate = totalTables > 0 ? Math.round((occupiedTables / totalTables) * 100) : 0;

    // 4. Real 7-Day Performance Chart (Generated accurately from DB)
    const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const last7DaysData = [];

    for (let i = 6; i >= 0; i--) {
      const dayRow = db.prepare(`
        SELECT 
          date('now', '-' || ? || ' days') as day_date,
          COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END), 0) as total_revenue,
          COUNT(CASE WHEN status != 'cancelled' THEN 1 END) as orders_count
        FROM orders
        WHERE date(created_at) = date('now', '-' || ? || ' days')
      `).get(i, i);

      const d = new Date();
      d.setDate(d.getDate() - i);
      const dayName = dayNames[d.getDay()];

      last7DaysData.push({
        date: dayRow?.day_date || '',
        day: dayName,
        revenue: Number(dayRow?.total_revenue || 0),
        orders: Number(dayRow?.orders_count || 0)
      });
    }

    // 5. Category Breakdown (Share of revenue per food category)
    const categoryStats = db.prepare(`
      SELECT 
        c.id as category_id,
        c.name_ar as category_name,
        COALESCE(SUM(oi.quantity), 0) as total_quantity,
        COALESCE(SUM(oi.quantity * oi.price_at_order), 0) as total_revenue
      FROM categories c
      LEFT JOIN menu_items mi ON c.id = mi.category_id
      LEFT JOIN order_items oi ON mi.id = oi.menu_item_id
      LEFT JOIN orders o ON oi.order_id = o.id AND o.status != 'cancelled'
      GROUP BY c.id
      ORDER BY total_revenue DESC
    `).all();

    const totalCategoryRevenue = categoryStats.reduce((sum, c) => sum + Number(c.total_revenue), 0);
    const categoryBreakdown = categoryStats.map(c => ({
      ...c,
      percentage: totalCategoryRevenue > 0 ? Math.round((c.total_revenue / totalCategoryRevenue) * 100) : 0
    }));

    // 6. Live Activity Feed (Recent 12 orders placed in real-time)
    const recentActivity = db.prepare(`
      SELECT 
        o.id, o.table_id, t.table_number, o.status, o.total_amount, o.created_at,
        (
          SELECT GROUP_CONCAT(oi.quantity || 'x ' || mi.name_ar, '، ')
          FROM order_items oi
          JOIN menu_items mi ON oi.menu_item_id = mi.id
          WHERE oi.order_id = o.id
        ) as items_summary
      FROM orders o
      JOIN tables t ON o.table_id = t.id
      ORDER BY o.created_at DESC
      LIMIT 12
    `).all();

    res.json({
      success: true,
      data: {
        live_kpis: {
          today_total_orders: todayLiveStats.today_total_orders,
          today_paid_revenue: todayLiveStats.today_paid_revenue,
          today_active_revenue: todayLiveStats.today_active_revenue,
          today_total_volume: todayLiveStats.today_total_volume,
          today_active_orders_count: todayLiveStats.today_active_orders_count,
          today_paid_orders_count: todayLiveStats.today_paid_orders_count,
          total_revenue_all_time: allTimeStats.total_revenue_all_time,
          total_orders_all_time: allTimeStats.total_orders_all_time,
          avg_order_value: allTimeStats.avg_order_value,
          total_tables: totalTables,
          occupied_tables: occupiedTables,
          occupancy_rate: occupancyRate
        },
        chart_data: last7DaysData,
        category_breakdown: categoryBreakdown,
        recent_activity: recentActivity
      }
    });
  } catch (err) {
    console.error('[ADVANCED REPORT ERROR]', err);
    res.status(500).json({ success: false, error: 'فشل في جلب التحليلات المتقدمة' });
  }
});

router.get('/admin/reports/top-items', (req, res) => {
  try {
    const topItems = db.prepare(`
      SELECT 
        mi.id, mi.name_ar, mi.name_en, mi.price, mi.image_url,
        SUM(oi.quantity) as total_quantity_sold,
        SUM(oi.quantity * oi.price_at_order) as total_sales_volume
      FROM order_items oi
      JOIN menu_items mi ON oi.menu_item_id = mi.id
      JOIN orders o ON oi.order_id = o.id
      WHERE o.status != 'cancelled'
      GROUP BY mi.id
      ORDER BY total_quantity_sold DESC
      LIMIT 10
    `).all();

    res.json({ success: true, data: topItems });
  } catch (err) {
    console.error('[TOP ITEMS REPORT ERROR]', err);
    res.status(500).json({ success: false, error: 'فشل في استخراج الأصناف الأكثر طلباً' });
  }
});

router.get('/admin/reports/peak-hours', (req, res) => {
  try {
    const peakHours = db.prepare(`
      SELECT 
        strftime('%H', created_at) as hour,
        COUNT(*) as orders_count,
        SUM(total_amount) as total_amount
      FROM orders
      WHERE status != 'cancelled'
      GROUP BY strftime('%H', created_at)
      ORDER BY hour ASC
    `).all();

    res.json({ success: true, data: peakHours });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب أوقات الذروة' });
  }
});

// ==========================================
// 4. RESTAURANT SETTINGS & SECURITY
// ==========================================

router.get('/admin/settings', (req, res) => {
  try {
    // Return all settings EXCEPT password hashes
    const rows = db.prepare(`
      SELECT key, value FROM restaurant_settings 
      WHERE key NOT LIKE '%password_hash%'
    `).all();

    const settings = {};
    for (const r of rows) {
      settings[r.key] = r.value;
    }

    res.json({ success: true, data: settings });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب الإعدادات' });
  }
});

router.put('/admin/settings', sanitizeBody, (req, res) => {
  const { restaurant_name_ar, restaurant_name_en, currency, logo_url, cover_image_url } = req.body;

  const setSetting = db.prepare(`
    INSERT INTO restaurant_settings (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
  `);

  if (restaurant_name_ar !== undefined) setSetting.run('restaurant_name_ar', restaurant_name_ar.trim());
  if (restaurant_name_en !== undefined) setSetting.run('restaurant_name_en', restaurant_name_en.trim());
  if (currency !== undefined) setSetting.run('currency', currency.trim());
  if (logo_url !== undefined) setSetting.run('logo_url', (logo_url || '').trim());
  if (cover_image_url !== undefined) setSetting.run('cover_image_url', (cover_image_url || '').trim());

  res.json({ success: true, message: 'تم حفظ إعدادات وهوية المطعم بنجاح' });
});

router.post('/admin/change-password', (req, res) => {
  const { targetRole, currentPassword, newPassword } = req.body;
  const clientIp = req.ip || req.connection.remoteAddress;

  if (!['admin', 'staff'].includes(targetRole) || !newPassword || newPassword.trim().length < 6) {
    return res.status(400).json({
      success: false,
      error: 'البيانات غير مكتملة، كلمة المرور الجديدة يجب أن تكون 6 خانات على الأقل'
    });
  }

  // Verify current admin password before allowing changes
  const currentAdminHashRow = db.prepare("SELECT value FROM restaurant_settings WHERE key = 'admin_password_hash'").get();
  const currentAdminHash = currentAdminHashRow ? currentAdminHashRow.value : bcrypt.hashSync(config.defaultAdminPassword, config.bcryptSaltRounds);

  if (!currentPassword || !bcrypt.compareSync(currentPassword, currentAdminHash)) {
    return res.status(401).json({
      success: false,
      error: 'كلمة مرور الأدمن الحالية غير صحيحة'
    });
  }

  const newHash = bcrypt.hashSync(newPassword.trim(), config.bcryptSaltRounds);
  const targetKey = targetRole === 'admin' ? 'admin_password_hash' : 'staff_password_hash';

  db.prepare(`
    INSERT INTO restaurant_settings (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
  `).run(targetKey, newHash);

  logAuditEvent({
    eventType: `PASSWORD_CHANGED_${targetRole.toUpperCase()}`,
    role: 'admin',
    ipAddress: clientIp,
    userAgent: req.get('User-Agent'),
    details: `Admin changed password for role: ${targetRole}`
  });

  res.json({
    success: true,
    message: `تم تغيير كلمة مرور ${targetRole === 'admin' ? 'الأدمن' : 'الموظفين'} بنجاح`
  });
});

router.get('/admin/audit-logs', (req, res) => {
  try {
    const logs = db.prepare(`
      SELECT id, event_type, role, ip_address, user_agent, details, created_at
      FROM audit_logs
      ORDER BY created_at DESC
      LIMIT 100
    `).all();

    res.json({ success: true, data: logs });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب سجلات التدقيق' });
  }
});

// ==========================================
// 5. STAFF DIRECTORY MANAGEMENT (ADMIN)
// ==========================================

router.get('/admin/staff-members', (req, res) => {
  try {
    const members = db.prepare(`
      SELECT id, name, role, phone, shift, is_active, created_at
      FROM staff_members
      ORDER BY created_at DESC
    `).all();
    res.json({ success: true, data: members });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل جلب قائمة الموظفين' });
  }
});

router.post('/admin/staff-members', sanitizeBody, (req, res) => {
  const { name, role, phone, shift } = req.body;
  if (!name || !role) {
    return res.status(400).json({ success: false, error: 'اسم الموظف والمسمى الوظيفي مطلوبان' });
  }

  const id = 'staff-' + crypto.randomUUID().substring(0, 8);
  db.prepare(`
    INSERT INTO staff_members (id, name, role, phone, shift, is_active, created_at)
    VALUES (?, ?, ?, ?, ?, 1, datetime('now'))
  `).run(id, name.trim(), role.trim(), phone ? phone.trim() : null, shift || 'صباحي');

  res.status(201).json({
    success: true,
    message: 'تم تسجيل الموظف بنجاح',
    data: { id, name, role, phone, shift, is_active: 1 }
  });
});

router.put('/admin/staff-members/:id', sanitizeBody, (req, res) => {
  const id = req.params.id;
  const { name, role, phone, shift } = req.body;

  db.prepare(`
    UPDATE staff_members
    SET name = ?, role = ?, phone = ?, shift = ?
    WHERE id = ?
  `).run(name.trim(), role.trim(), phone ? phone.trim() : null, shift || 'صباحي', id);

  res.json({ success: true, message: 'تم تحديث بيانات الموظف بنجاح' });
});

router.patch('/admin/staff-members/:id/toggle', (req, res) => {
  const id = req.params.id;
  const member = db.prepare('SELECT id, is_active, name FROM staff_members WHERE id = ?').get(id);
  if (!member) return res.status(404).json({ success: false, error: 'الموظف غير موجود' });

  const newStatus = member.is_active ? 0 : 1;
  db.prepare('UPDATE staff_members SET is_active = ? WHERE id = ?').run(newStatus, id);

  res.json({
    success: true,
    message: `تم ${newStatus ? 'تفعيل' : 'تعطيل'} حساب الموظف ${member.name}`,
    data: { id, is_active: newStatus }
  });
});

router.delete('/admin/staff-members/:id', (req, res) => {
  const id = req.params.id;
  db.prepare('DELETE FROM staff_members WHERE id = ?').run(id);
  res.json({ success: true, message: 'تم حذف الموظف من السجل' });
});

// ==========================================
// 6. INCIDENTS & ISSUES MANAGEMENT (ADMIN)
// ==========================================

router.get('/admin/incidents', (req, res) => {
  try {
    const incidents = db.prepare(`
      SELECT id, table_number, reported_by, issue_type, description, priority, status, created_at, resolved_at
      FROM incident_reports
      ORDER BY 
        CASE status 
          WHEN 'open' THEN 1 
          WHEN 'in_progress' THEN 2 
          ELSE 3 
        END,
        created_at DESC
    `).all();
    res.json({ success: true, data: incidents });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل جلب قائمة البلاغات' });
  }
});

router.patch('/admin/incidents/:id/status', (req, res) => {
  const id = req.params.id;
  const { status } = req.body;

  if (!['open', 'in_progress', 'resolved'].includes(status)) {
    return res.status(400).json({ success: false, error: 'الحالة غير صالحة' });
  }

  db.prepare(`
    UPDATE incident_reports
    SET status = ?, resolved_at = ${status === 'resolved' ? "datetime('now')" : "NULL"}
    WHERE id = ?
  `).run(status, id);

  res.json({ success: true, message: 'تم تحديث حالة البلاغ بنجاح' });
});

router.delete('/admin/incidents/:id', (req, res) => {
  const id = req.params.id;
  db.prepare('DELETE FROM incident_reports WHERE id = ?').run(id);
  res.json({ success: true, message: 'تم مسح البلاغ من السجل' });
});

module.exports = router;
