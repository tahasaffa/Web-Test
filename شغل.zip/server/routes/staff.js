const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireStaff } = require('../middleware/auth');
const {
  notifyOrderStatusUpdated,
  notifyStaffCallAcknowledged,
  notifyTableSettled
} = require('../socket');

// Apply Staff authentication middleware strictly to /staff routes
router.use('/staff', requireStaff);

/**
 * GET /api/staff/orders
 * Returns all active orders for KDS and Cashier views.
 */
router.get('/staff/orders', (req, res) => {
  try {
    const orders = db.prepare(`
      SELECT o.id, o.table_id, o.status, o.total_amount, o.created_at, o.updated_at,
             t.table_number
      FROM orders o
      JOIN tables t ON o.table_id = t.id
      WHERE o.status IN ('new', 'preparing', 'ready', 'served')
      ORDER BY o.created_at ASC
    `).all();

    const getItemsStmt = db.prepare(`
      SELECT oi.id, oi.menu_item_id, oi.quantity, oi.notes, oi.price_at_order,
             mi.name_ar, mi.name_en
      FROM order_items oi
      JOIN menu_items mi ON oi.menu_item_id = mi.id
      WHERE oi.order_id = ?
    `);

    const result = orders.map(order => ({
      ...order,
      items: getItemsStmt.all(order.id)
    }));

    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    console.error('[STAFF ORDERS ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء جلب طلبات المطبخ'
    });
  }
});

/**
 * PATCH /api/staff/orders/:id/status
 * Updates status of an order ('preparing' | 'ready' | 'served' | 'cancelled')
 */
router.patch('/staff/orders/:id/status', (req, res) => {
  const orderId = req.params.id;
  const { status } = req.body;

  const validStatuses = ['new', 'preparing', 'ready', 'served', 'cancelled'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({
      success: false,
      error: `الحالة غير صالحة. الحالات المقبولة: ${validStatuses.join(', ')}`
    });
  }

  try {
    const order = db.prepare(`
      SELECT o.id, o.table_id, o.status, o.total_amount, o.created_at, t.table_number
      FROM orders o
      JOIN tables t ON o.table_id = t.id
      WHERE o.id = ?
    `).get(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        error: 'الطلب غير موجود'
      });
    }

    db.prepare(`
      UPDATE orders
      SET status = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(status, orderId);

    const updatedOrder = {
      ...order,
      status,
      updated_at: new Date().toISOString()
    };

    // Real-time broadcast to both staff and customer table
    notifyOrderStatusUpdated(updatedOrder);

    res.json({
      success: true,
      message: `تم تحديث حالة الطلب إلى "${status}" بنجاح`,
      data: updatedOrder
    });
  } catch (err) {
    console.error('[UPDATE ORDER STATUS ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء تحديث حالة الطلب'
    });
  }
});

/**
 * POST /api/staff/orders/:id/close
 * Cashier marks a single order as paid.
 */
router.post('/staff/orders/:id/close', (req, res) => {
  const orderId = req.params.id;

  try {
    const order = db.prepare(`
      SELECT o.id, o.table_id, o.status, o.total_amount, t.table_number
      FROM orders o
      JOIN tables t ON o.table_id = t.id
      WHERE o.id = ?
    `).get(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        error: 'الطلب غير موجود'
      });
    }

    db.prepare(`
      UPDATE orders
      SET status = 'paid', updated_at = datetime('now')
      WHERE id = ?
    `).run(orderId);

    const closedOrder = { ...order, status: 'paid' };
    notifyOrderStatusUpdated(closedOrder);

    res.json({
      success: true,
      message: 'تم إغلاق الطلب وتسجيل الدفع بنجاح',
      data: closedOrder
    });
  } catch (err) {
    console.error('[CLOSE ORDER ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء إغلاق الطلب'
    });
  }
});

/**
 * POST /api/staff/tables/:tableId/settle
 * Cashier closes and settles all active orders for a table at once.
 */
router.post('/staff/tables/:tableId/settle', (req, res) => {
  const tableId = req.params.tableId;

  try {
    const table = db.prepare('SELECT id, table_number FROM tables WHERE id = ?').get(tableId);
    if (!table) {
      return res.status(404).json({
        success: false,
        error: 'الطاولة غير موجودة'
      });
    }

    const activeOrders = db.prepare(`
      SELECT id, total_amount
      FROM orders
      WHERE table_id = ? AND status IN ('new', 'preparing', 'ready', 'served')
    `).all(tableId);

    if (activeOrders.length === 0) {
      return res.json({
        success: true,
        message: 'لا توجد طلبات معلقة لهذه الطاولة للدفع',
        data: { settledCount: 0, totalAmount: 0 }
      });
    }

    const totalAmount = activeOrders.reduce((sum, o) => sum + o.total_amount, 0);

    const settleTx = db.transaction(() => {
      const updateStmt = db.prepare(`
        UPDATE orders
        SET status = 'paid', updated_at = datetime('now')
        WHERE table_id = ? AND status IN ('new', 'preparing', 'ready', 'served')
      `);
      updateStmt.run(tableId);
    });

    settleTx();

    const summary = {
      table_id: table.id,
      table_number: table.table_number,
      settled_orders_count: activeOrders.length,
      total_paid: totalAmount
    };

    notifyTableSettled(tableId, summary);

    res.json({
      success: true,
      message: `تم إغلاق حساب الطاولة رقم ${table.table_number} بمبلغ إجمالي ${totalAmount} بنجاح`,
      data: summary
    });
  } catch (err) {
    console.error('[SETTLE TABLE ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء تسوية حساب الطاولة'
    });
  }
});

/**
 * GET /api/staff/calls
 * Get pending waiter calls.
 */
router.get('/staff/calls', (req, res) => {
  try {
    const calls = db.prepare(`
      SELECT sc.id, sc.table_id, sc.call_type, sc.status, sc.created_at,
             t.table_number
      FROM staff_calls sc
      JOIN tables t ON sc.table_id = t.id
      WHERE sc.status = 'pending'
      ORDER BY sc.created_at ASC
    `).all();

    res.json({
      success: true,
      data: calls
    });
  } catch (err) {
    console.error('[STAFF CALLS ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء جلب نداءات الويتر'
    });
  }
});

/**
 * PATCH /api/staff/calls/:id/acknowledge
 * Acknowledge / dismiss a waiter call.
 */
router.patch('/staff/calls/:id/acknowledge', (req, res) => {
  const callId = req.params.id;

  try {
    const call = db.prepare(`
      SELECT sc.id, sc.table_id, sc.status, t.table_number
      FROM staff_calls sc
      JOIN tables t ON sc.table_id = t.id
      WHERE sc.id = ?
    `).get(callId);

    if (!call) {
      return res.status(404).json({
        success: false,
        error: 'نداء الويتر غير موجود'
      });
    }

    db.prepare(`
      UPDATE staff_calls
      SET status = 'acknowledged', acknowledged_at = datetime('now')
      WHERE id = ?
    `).run(callId);

    const updatedCall = {
      ...call,
      status: 'acknowledged',
      acknowledged_at: new Date().toISOString()
    };

    notifyStaffCallAcknowledged(updatedCall);

    res.json({
      success: true,
      message: 'تم تأكيد تلبية نداء الويتر',
      data: updatedCall
    });
  } catch (err) {
    console.error('[ACKNOWLEDGE CALL ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء تأكيد النداء'
    });
  }
});

/**
 * GET /api/staff/incidents
 * Get all logged incident reports.
 */
router.get('/staff/incidents', (req, res) => {
  try {
    const incidents = db.prepare(`
      SELECT id, table_number, reported_by, issue_type, description, priority, status, created_at, resolved_at
      FROM incident_reports
      ORDER BY created_at DESC
      LIMIT 50
    `).all();

    res.json({ success: true, data: incidents });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل جلب سجل البلاغات' });
  }
});

/**
 * POST /api/staff/incidents
 * Log a new incident or complaint.
 */
router.post('/staff/incidents', (req, res) => {
  const { table_number, reported_by, issue_type, description, priority } = req.body;
  const crypto = require('crypto');

  if (!reported_by || !issue_type || !description) {
    return res.status(400).json({ success: false, error: 'اسم المبلغ ونوع المشكلة وتفاصيلها حقول مطلوبة' });
  }

  try {
    const id = 'inc-' + crypto.randomUUID().substring(0, 8);
    db.prepare(`
      INSERT INTO incident_reports (id, table_number, reported_by, issue_type, description, priority, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'open', datetime('now'))
    `).run(
      id,
      table_number ? parseInt(table_number, 10) : null,
      reported_by.trim(),
      issue_type.trim(),
      description.trim(),
      ['low', 'normal', 'high', 'urgent'].includes(priority) ? priority : 'normal'
    );

    res.status(201).json({
      success: true,
      message: 'تم تسجيل البلاغ بنجاح',
      data: { id, table_number, reported_by, issue_type, description, status: 'open' }
    });
  } catch (err) {
    console.error('[LOG INCIDENT ERROR]', err);
    res.status(500).json({ success: false, error: 'فشل في حفظ البلاغ' });
  }
});

/**
 * PATCH /api/staff/incidents/:id/status
 * Update status of an incident report ('in_progress' | 'resolved').
 */
router.patch('/staff/incidents/:id/status', (req, res) => {
  const id = req.params.id;
  const { status } = req.body;

  if (!['open', 'in_progress', 'resolved'].includes(status)) {
    return res.status(400).json({ success: false, error: 'الحالة غير صالحة' });
  }

  try {
    db.prepare(`
      UPDATE incident_reports
      SET status = ?, resolved_at = ${status === 'resolved' ? "datetime('now')" : "NULL"}
      WHERE id = ?
    `).run(status, id);

    res.json({ success: true, message: 'تم تحديث حالة البلاغ بنجاح' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل تحديث حالة البلاغ' });
  }
});

/**
 * GET /api/staff/members
 * Get active staff directory list.
 */
router.get('/staff/members', (req, res) => {
  try {
    const members = db.prepare(`
      SELECT id, name, role, phone, shift, is_active
      FROM staff_members
      WHERE is_active = 1
      ORDER BY name ASC
    `).all();
    res.json({ success: true, data: members });
  } catch (err) {
    res.status(500).json({ success: false, error: 'فشل في جلب قائمة الموظفين' });
  }
});

module.exports = router;
