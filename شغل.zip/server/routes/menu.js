const express = require('express');
const router = express.Router();
const db = require('../db');

/**
 * GET /api/menu
 * Public endpoint: Returns all categories and active menu items.
 * Uses parameterized queries.
 */
router.get('/menu', (req, res) => {
  try {
    const categories = db.prepare(`
      SELECT id, name_ar, name_en, sort_order
      FROM categories
      ORDER BY sort_order ASC, name_ar ASC
    `).all();

    const items = db.prepare(`
      SELECT id, category_id, name_ar, name_en, description_ar, description_en, price, image_url, is_available
      FROM menu_items
      WHERE is_available = 1
      ORDER BY name_ar ASC
    `).all();

    // Fetch restaurant metadata
    const settingsRows = db.prepare('SELECT key, value FROM restaurant_settings WHERE key IN (?, ?, ?, ?, ?)').all(
      'restaurant_name_ar',
      'restaurant_name_en',
      'currency',
      'logo_url',
      'cover_image_url'
    );

    const settings = {};
    for (const row of settingsRows) {
      settings[row.key] = row.value;
    }

    // Group items by category
    const categoriesWithItems = categories.map(cat => ({
      ...cat,
      items: items.filter(item => item.category_id === cat.id)
    }));

    res.json({
      success: true,
      data: {
        restaurant: {
          name_ar: settings.restaurant_name_ar || 'مطعم اللذة الذكية',
          name_en: settings.restaurant_name_en || 'Smart Gourmet Restaurant',
          currency: settings.currency || 'IQD',
          logo_url: settings.logo_url || '',
          cover_image_url: settings.cover_image_url || ''
        },
        categories: categoriesWithItems,
        allItems: items
      }
    });
  } catch (err) {
    console.error('[MENU ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء جلب قائمة الطعام (Failed to fetch menu)'
    });
  }
});

module.exports = router;
