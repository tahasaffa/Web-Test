const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const db = require('../db');
const { sanitizeBody } = require('../middleware/sanitize');
const { tableOrderRateLimiter } = require('../middleware/rateLimit');
const { notifyNewOrder } = require('../socket');

/**
 * POST /api/orders
 * Public endpoint: Place a new order from customer mobile.
 * Features:
 * - Sanitizes notes/inputs to prevent XSS.
 * - Rate limits by table_id (1 order per 30s) to prevent spam.
 * - Validates table exists and is active.
 * - Fetches current item prices strictly from DB (never trusts client price).
 * - Executes within a database transaction.
 * - Emits real-time WebSocket event to kitchen display.
 */
router.post('/orders', sanitizeBody, tableOrderRateLimiter, (req, res) => {
  const { table_id, items } = req.body;

  if (!table_id || typeof table_id !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'معرف الطاولة مطلوب (table_id is required)'
    });
  }

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      success: false,
      error: 'السلة فارغة، يرجى إضافة أصناف للطلب (Items list cannot be empty)'
    });
  }

  try {
    // 1. Verify table exists and is active
    const table = db.prepare('SELECT id, table_number, is_active FROM tables WHERE id = ?').get(table_id);
    if (!table) {
      return res.status(404).json({
        success: false,
        error: 'الطاولة غير موجودة في النظام (Table not found)'
      });
    }
    if (!table.is_active) {
      return res.status(403).json({
        success: false,
        error: 'هذه الطاولة معطلة حالياً (Table is inactive)'
      });
    }

    // 2. Validate items and prepare order calculation
    let calculatedTotal = 0;
    const validatedItems = [];

    const getItemStmt = db.prepare(`
      SELECT id, name_ar, name_en, price, is_available
      FROM menu_items
      WHERE id = ?
    `);

    for (const item of items) {
      const quantity = parseInt(item.quantity, 10);
      if (isNaN(quantity) || quantity <= 0) {
        return res.status(400).json({
          success: false,
          error: `الكمية غير صالحة للصنف (${item.menu_item_id || 'صنف غير معروف'})`
        });
      }

      const menuItem = getItemStmt.get(item.menu_item_id);
      if (!menuItem) {
        return res.status(404).json({
          success: false,
          error: `الصنف المطلوب غير موجود (${item.menu_item_id})`
        });
      }

      if (!menuItem.is_available) {
        return res.status(400).json({
          success: false,
          error: `عذراً، الصنف "${menuItem.name_ar}" غير متوفر حالياً بسبب نفاد المخزون`
        });
      }

      const itemTotal = menuItem.price * quantity;
      calculatedTotal += itemTotal;

      validatedItems.push({
        id: crypto.randomUUID(),
        menu_item_id: menuItem.id,
        name_ar: menuItem.name_ar,
        name_en: menuItem.name_en,
        quantity,
        notes: item.notes ? String(item.notes).trim() : '',
        price_at_order: menuItem.price
      });
    }

    const orderId = crypto.randomUUID();

    // 3. Execute insertion within a safe transaction
    const insertOrderTx = db.transaction(() => {
      const insertOrderStmt = db.prepare(`
        INSERT INTO orders (id, table_id, status, total_amount, created_at, updated_at)
        VALUES (?, ?, 'new', ?, datetime('now'), datetime('now'))
      `);
      insertOrderStmt.run(orderId, table.id, calculatedTotal);

      const insertOrderItemStmt = db.prepare(`
        INSERT INTO order_items (id, order_id, menu_item_id, quantity, notes, price_at_order)
        VALUES (?, ?, ?, ?, ?, ?)
      `);

      for (const vi of validatedItems) {
        insertOrderItemStmt.run(
          vi.id,
          orderId,
          vi.menu_item_id,
          vi.quantity,
          vi.notes,
          vi.price_at_order
        );
      }
    });

    insertOrderTx();

    const createdOrder = {
      id: orderId,
      table_id: table.id,
      table_number: table.table_number,
      status: 'new',
      total_amount: calculatedTotal,
      created_at: new Date().toISOString(),
      items: validatedItems
    };

    // 4. Notify staff and table in real-time via WebSockets
    notifyNewOrder(createdOrder);

    return res.status(201).json({
      success: true,
      message: 'تم استلام طلبك بنجاح وجاري إرساله للمطبخ',
      data: createdOrder
    });
  } catch (err) {
    console.error('[CREATE ORDER ERROR]', err);
    return res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء معالجة الطلب، يرجى المحاولة لاحقاً'
    });
  }
});

/**
 * GET /api/orders/table/:tableId/active
 * Public endpoint: Get active orders and bill summary for a table.
 */
router.get('/orders/table/:tableId/active', (req, res) => {
  const tableId = req.params.tableId;

  try {
    const table = db.prepare('SELECT id, table_number FROM tables WHERE id = ?').get(tableId);
    if (!table) {
      return res.status(404).json({
        success: false,
        error: 'الطاولة غير موجودة (Table not found)'
      });
    }

    // Fetch active (unpaid) orders for this table
    const activeOrders = db.prepare(`
      SELECT id, table_id, status, total_amount, created_at, updated_at
      FROM orders
      WHERE table_id = ? AND status IN ('new', 'preparing', 'ready', 'served')
      ORDER BY created_at ASC
    `).all(tableId);

    const getItemsStmt = db.prepare(`
      SELECT oi.id, oi.menu_item_id, oi.quantity, oi.notes, oi.price_at_order,
             mi.name_ar, mi.name_en, mi.image_url
      FROM order_items oi
      JOIN menu_items mi ON oi.menu_item_id = mi.id
      WHERE oi.order_id = ?
    `);

    let totalBillAmount = 0;
    const ordersWithItems = activeOrders.map(order => {
      totalBillAmount += order.total_amount;
      const items = getItemsStmt.all(order.id);
      return {
        ...order,
        items
      };
    });

    res.json({
      success: true,
      data: {
        table_number: table.table_number,
        table_id: table.id,
        activeOrders: ordersWithItems,
        total_bill_amount: totalBillAmount,
        active_orders_count: activeOrders.length
      }
    });
  } catch (err) {
    console.error('[GET ACTIVE ORDERS ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء جلب تفاصيل طلبات الطاولة'
    });
  }
});

/**
 * GET /api/orders/:id/status
 * Public endpoint: Real-time status lookup for a single order.
 */
router.get('/orders/:id/status', (req, res) => {
  const orderId = req.params.id;

  try {
    const order = db.prepare(`
      SELECT o.id, o.table_id, o.status, o.total_amount, o.created_at, o.updated_at,
             t.table_number
      FROM orders o
      JOIN tables t ON o.table_id = t.id
      WHERE o.id = ?
    `).get(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        error: 'الطلب غير موجود (Order not found)'
      });
    }

    const items = db.prepare(`
      SELECT oi.id, oi.quantity, oi.notes, oi.price_at_order,
             mi.name_ar, mi.name_en
      FROM order_items oi
      JOIN menu_items mi ON oi.menu_item_id = mi.id
      WHERE oi.order_id = ?
    `).all(orderId);

    res.json({
      success: true,
      data: {
        ...order,
        items
      }
    });
  } catch (err) {
    console.error('[ORDER STATUS ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء جلب حالة الطلب'
    });
  }
});

module.exports = router;
