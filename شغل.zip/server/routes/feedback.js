const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { sanitizeBody } = require('../middleware/sanitize');
const { notifyNewIncident } = require('../socket');

const router = express.Router();

/**
 * POST /api/customer/feedback
 * Submit customer table evaluation:
 * - Order / Food rating (1-5)
 * - Service & Staff rating (1-5)
 * - Customer custom message / notes
 * - Quick tags
 */
router.post('/customer/feedback', sanitizeBody, (req, res) => {
  const {
    table_id,
    table_number: directTableNumber,
    customer_name,
    order_rating,
    service_rating,
    message,
    quick_tags,
    description: legacyDescription,
    rating: legacyRating
  } = req.body;

  const finalMessage = (message || legacyDescription || '').trim();

  let tableNumber = directTableNumber ? parseInt(directTableNumber, 10) : null;
  if (table_id && !tableNumber) {
    try {
      const tbl = db.prepare('SELECT table_number FROM tables WHERE id = ?').get(table_id);
      if (tbl) tableNumber = tbl.table_number;
    } catch (e) {
      // Ignore
    }
  }

  const foodRatingNum = order_rating ? parseInt(order_rating, 10) : (legacyRating ? parseInt(legacyRating, 10) : 5);
  const serviceRatingNum = service_rating ? parseInt(service_rating, 10) : 5;

  const foodStars = '★'.repeat(Math.max(1, Math.min(5, foodRatingNum))) + '☆'.repeat(5 - Math.max(1, Math.min(5, foodRatingNum)));
  const serviceStars = '★'.repeat(Math.max(1, Math.min(5, serviceRatingNum))) + '☆'.repeat(5 - Math.max(1, Math.min(5, serviceRatingNum)));

  const reporter = customer_name && customer_name.trim()
    ? customer_name.trim()
    : (tableNumber ? `زبون طاولة #${tableNumber}` : 'زبون غير محدد');

  const tagsStr = Array.isArray(quick_tags) && quick_tags.length > 0
    ? `\nالموضوع: ${quick_tags.join('، ')}`
    : '';

  const fullDescription = [
    `🍲 تقييم جودة الطلب والأكل: ${foodStars} (${foodRatingNum}/5)`,
    `🛎️ تقييم الخدمة وسرعة الطاقم: ${serviceStars} (${serviceRatingNum}/5)`,
    tagsStr,
    finalMessage ? `\n💬 رسالة الزبون:\n"${finalMessage}"` : '\n(لم يترك الزبون رسالة نصية إضافية)'
  ].filter(Boolean).join('\n');

  const isLowRating = foodRatingNum <= 2 || serviceRatingNum <= 2;
  const issueType = isLowRating
    ? `🚨 ملاحظة / شكوى طاولة #${tableNumber || '؟'}`
    : `⭐ تقييم طلب وخدمة طاولة #${tableNumber || '؟'}`;

  const priority = isLowRating ? 'urgent' : 'normal';
  const id = 'fb-' + crypto.randomUUID().substring(0, 8);

  try {
    db.prepare(`
      INSERT INTO incident_reports (id, table_number, reported_by, issue_type, description, priority, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'open', datetime('now'))
    `).run(
      id,
      tableNumber,
      reporter,
      issueType,
      fullDescription,
      priority
    );

    const report = {
      id,
      table_number: tableNumber,
      reported_by: reporter,
      issue_type: issueType,
      description: fullDescription,
      priority,
      status: 'open',
      created_at: new Date().toISOString()
    };

    notifyNewIncident(report);

    res.status(201).json({
      success: true,
      message: 'شكراً لمشاركتنا رأيك! تم استلام تقييم الطلب والخدمة ورسالتك وستتم متابعتها من الإدارة باهتمام.',
      data: report
    });
  } catch (err) {
    console.error('[CUSTOMER FEEDBACK ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'فشل إرسال التقييم، يرجى المحاولة مرة أخرى'
    });
  }
});

module.exports = router;
