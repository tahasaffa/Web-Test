const express = require('express');
const router = express.Router();
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const config = require('../config');
const { requireAdmin } = require('../middleware/auth');

// Setup secure Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, config.paths.imagesDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const uniqueName = crypto.randomUUID() + ext;
    cb(null, uniqueName);
  }
});

// Strict file filter
const fileFilter = (req, file, cb) => {
  if (config.security.allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('نوع الملف غير مدعوم. يسمح فقط بصور JPEG و PNG و WebP.'), false);
  }
};

const upload = multer({
  storage,
  limits: {
    fileSize: config.security.maxUploadSize // 5MB
  },
  fileFilter
});

/**
 * POST /api/admin/upload
 * Protected endpoint for uploading dish images.
 */
router.post('/admin/upload', requireAdmin, (req, res) => {
  upload.single('image')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          success: false,
          error: 'حجم الصورة كبير جداً، الحد الأقصى المسموح به هو 5 ميجابايت'
        });
      }
      return res.status(400).json({ success: false, error: `خطأ في رفع الملف: ${err.message}` });
    } else if (err) {
      return res.status(400).json({ success: false, error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ success: false, error: 'لم يتم اختيار أي صورة للرفع' });
    }

    const publicUrl = `/uploads/images/${req.file.filename}`;

    res.json({
      success: true,
      message: 'تم رفع الصورة بنجاح',
      data: {
        filename: req.file.filename,
        url: publicUrl,
        size: req.file.size,
        mimetype: req.file.mimetype
      }
    });
  });
});

module.exports = router;
