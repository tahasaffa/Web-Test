const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const config = require('../config');
const { generateToken, verifyToken } = require('../middleware/auth');
const { loginRateLimiter } = require('../middleware/rateLimit');
const { logAuditEvent } = require('../middleware/auditLog');

/**
 * Helper to fetch a stored password hash from restaurant_settings
 */
function getPasswordHash(key, defaultPassword) {
  const row = db.prepare('SELECT value FROM restaurant_settings WHERE key = ?').get(key);
  if (row && row.value) {
    return row.value;
  }
  // Fallback: hash the env default password
  return bcrypt.hashSync(defaultPassword, config.bcryptSaltRounds);
}

/**
 * POST /api/staff/login
 * Rate limited by IP. Authenticates staff password with bcrypt.
 */
router.post('/staff/login', loginRateLimiter, (req, res) => {
  const { password } = req.body;
  const clientIp = req.ip || req.connection.remoteAddress;
  const userAgent = req.get('User-Agent');

  if (!password || typeof password !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'كلمة المرور مطلوبة (Password is required)'
    });
  }

  const staffHash = getPasswordHash('staff_password_hash', config.defaultStaffPassword);
  const isMatch = bcrypt.compareSync(password.trim(), staffHash);

  if (!isMatch) {
    logAuditEvent({
      eventType: 'STAFF_LOGIN_FAILED',
      role: 'staff',
      ipAddress: clientIp,
      userAgent: userAgent,
      details: 'Incorrect staff password attempt'
    });

    return res.status(401).json({
      success: false,
      error: 'كلمة المرور غير صحيحة (Invalid staff password)'
    });
  }

  // Generate signed JWT with role: 'staff' (tamper-evident, no sensitive data in payload)
  const token = generateToken('staff');

  logAuditEvent({
    eventType: 'STAFF_LOGIN_SUCCESS',
    role: 'staff',
    ipAddress: clientIp,
    userAgent: userAgent,
    details: 'Staff logged in successfully'
  });

  return res.json({
    success: true,
    token,
    role: 'staff',
    expiresIn: config.jwtExpiresIn,
    message: 'تم تسجيل دخول الموظف بنجاح'
  });
});

/**
 * POST /api/admin/login
 * Rate limited by IP. Authenticates admin password with bcrypt.
 */
router.post('/admin/login', loginRateLimiter, (req, res) => {
  const { password } = req.body;
  const clientIp = req.ip || req.connection.remoteAddress;
  const userAgent = req.get('User-Agent');

  if (!password || typeof password !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'كلمة المرور مطلوبة (Password is required)'
    });
  }

  const adminHash = getPasswordHash('admin_password_hash', config.defaultAdminPassword);
  const isMatch = bcrypt.compareSync(password.trim(), adminHash);

  if (!isMatch) {
    logAuditEvent({
      eventType: 'ADMIN_LOGIN_FAILED',
      role: 'admin',
      ipAddress: clientIp,
      userAgent: userAgent,
      details: 'Incorrect admin password attempt'
    });

    return res.status(401).json({
      success: false,
      error: 'كلمة مرور الأدمن غير صحيحة (Invalid admin password)'
    });
  }

  // Generate signed JWT with role: 'admin'
  const token = generateToken('admin');

  logAuditEvent({
    eventType: 'ADMIN_LOGIN_SUCCESS',
    role: 'admin',
    ipAddress: clientIp,
    userAgent: userAgent,
    details: 'Admin logged in successfully'
  });

  return res.json({
    success: true,
    token,
    role: 'admin',
    expiresIn: config.jwtExpiresIn,
    message: 'تم تسجيل دخول الأدمن بنجاح'
  });
});

/**
 * GET /api/auth/me
 * Validates active token and returns user role.
 */
router.get('/auth/me', verifyToken, (req, res) => {
  res.json({
    success: true,
    user: {
      role: req.user.role
    }
  });
});

module.exports = router;
