const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const db = require('../db');
const { sanitizeBody } = require('../middleware/sanitize');
const { tableCallRateLimiter } = require('../middleware/rateLimit');
const { notifyStaffCall } = require('../socket');

/**
 * POST /api/staff-calls
 * Public endpoint: Customer calls waiter.
 * Rate limited to 1 call every 45s per table.
 */
router.post('/staff-calls', sanitizeBody, tableCallRateLimiter, (req, res) => {
  const { table_id, call_type } = req.body;

  if (!table_id || typeof table_id !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'معرف الطاولة مطلوب (table_id is required)'
    });
  }

  try {
    const table = db.prepare('SELECT id, table_number, is_active FROM tables WHERE id = ?').get(table_id);
    if (!table) {
      return res.status(404).json({
        success: false,
        error: 'الطاولة غير موجودة في النظام'
      });
    }

    if (!table.is_active) {
      return res.status(403).json({
        success: false,
        error: 'الطاولة غير مفعلة'
      });
    }

    const finalCallType = call_type === 'payment' ? 'payment' : 'general';
    const callId = crypto.randomUUID();

    db.prepare(`
      INSERT INTO staff_calls (id, table_id, call_type, status, created_at)
      VALUES (?, ?, ?, 'pending', datetime('now'))
    `).run(callId, table.id, finalCallType);

    const callData = {
      id: callId,
      table_id: table.id,
      table_number: table.table_number,
      call_type: finalCallType,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    // Emit real-time notification to staff
    notifyStaffCall(callData);

    const successMsg = finalCallType === 'payment'
      ? 'تم طلب الويتر لإحضار الفاتورة والدفع، سيصلكم الموظف فوراً'
      : 'تم إرسال نداء الويتر، سيصل الموظف إلى طاولتكم في أقرب وقت';

    res.status(201).json({
      success: true,
      message: successMsg,
      data: callData
    });
  } catch (err) {
    console.error('[STAFF CALL ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء إرسال نداء الويتر'
    });
  }
});

module.exports = router;
