const express = require('express');
const router = express.Router();
const db = require('../db');

/**
 * GET /api/tables/:id/validate
 * Public endpoint: Validates table UUID before accepting orders or showing customer interface.
 * Uses 100% parameterized query.
 */
router.get('/tables/:id/validate', (req, res) => {
  const tableId = req.params.id;

  if (!tableId || typeof tableId !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'معرف الطاولة غير صالح (Invalid table ID format)'
    });
  }

  try {
    const table = db.prepare(`
      SELECT id, table_number, is_active, created_at
      FROM tables
      WHERE id = ?
    `).get(tableId);

    if (!table) {
      return res.status(404).json({
        success: false,
        error: 'الطاولة المطلوبة غير موجودة في النظام (Table not found)'
      });
    }

    if (!table.is_active) {
      return res.status(403).json({
        success: false,
        error: 'هذه الطاولة غير مفعلة حالياً للطلب (Table is currently inactive)'
      });
    }

    // Get restaurant settings
    const settingsRows = db.prepare('SELECT key, value FROM restaurant_settings WHERE key IN (?, ?, ?)').all(
      'restaurant_name_ar',
      'restaurant_name_en',
      'currency'
    );
    const settings = {};
    for (const row of settingsRows) {
      settings[row.key] = row.value;
    }

    res.json({
      success: true,
      data: {
        table: {
          id: table.id,
          table_number: table.table_number
        },
        restaurant: {
          name_ar: settings.restaurant_name_ar || 'مطعم اللذة الذكية',
          name_en: settings.restaurant_name_en || 'Smart Gourmet Restaurant',
          currency: settings.currency || 'SAR'
        }
      }
    });
  } catch (err) {
    console.error('[TABLE VALIDATE ERROR]', err);
    res.status(500).json({
      success: false,
      error: 'حدث خطأ أثناء التحقق من الطاولة'
    });
  }
});

module.exports = router;
