const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('./config');

// Ensure database and backup directories exist
if (!fs.existsSync(config.paths.dataDir)) {
  fs.mkdirSync(config.paths.dataDir, { recursive: true });
}
if (!fs.existsSync(config.paths.backupsDir)) {
  fs.mkdirSync(config.paths.backupsDir, { recursive: true });
}

// Initialize SQLite connection
const db = new Database(config.paths.dbFile);

// Enable WAL mode for high concurrency (concurrent reads and writes without locks)
db.pragma('journal_mode = WAL');
// Enforce foreign key constraints
db.pragma('foreign_keys = ON');

/**
 * Initialize database schema
 * Strictly uses relational schema, constraints, and indexes.
 */
function initSchema() {
  db.exec(`
    -- Tables
    CREATE TABLE IF NOT EXISTS tables (
      id TEXT PRIMARY KEY,
      table_number INTEGER NOT NULL UNIQUE,
      qr_code_url TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Menu Categories
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name_ar TEXT NOT NULL,
      name_en TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Menu Items
    CREATE TABLE IF NOT EXISTS menu_items (
      id TEXT PRIMARY KEY,
      category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
      name_ar TEXT NOT NULL,
      name_en TEXT NOT NULL,
      description_ar TEXT,
      description_en TEXT,
      price REAL NOT NULL CHECK(price >= 0),
      image_url TEXT,
      is_available INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Orders
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      table_id TEXT NOT NULL REFERENCES tables(id) ON DELETE RESTRICT,
      status TEXT NOT NULL CHECK(status IN ('new', 'preparing', 'ready', 'served', 'paid', 'cancelled')),
      total_amount REAL NOT NULL CHECK(total_amount >= 0),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Order Items (Snapshot of price at time of order)
    CREATE TABLE IF NOT EXISTS order_items (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      menu_item_id TEXT NOT NULL REFERENCES menu_items(id) ON DELETE RESTRICT,
      quantity INTEGER NOT NULL CHECK(quantity > 0),
      notes TEXT,
      price_at_order REAL NOT NULL CHECK(price_at_order >= 0)
    );

    -- Staff Calls (Call Waiter)
    CREATE TABLE IF NOT EXISTS staff_calls (
      id TEXT PRIMARY KEY,
      table_id TEXT NOT NULL REFERENCES tables(id) ON DELETE CASCADE,
      status TEXT NOT NULL CHECK(status IN ('pending', 'acknowledged')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      acknowledged_at TEXT
    );

    -- Restaurant Settings & Password Hashes
    CREATE TABLE IF NOT EXISTS restaurant_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Security Audit Logs (Logins, Admin password changes, Sensitive Actions)
    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      event_type TEXT NOT NULL,
      role TEXT,
      ip_address TEXT,
      user_agent TEXT,
      details TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Staff Members Directory (Registry)
    CREATE TABLE IF NOT EXISTS staff_members (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      role TEXT NOT NULL,
      phone TEXT,
      shift TEXT DEFAULT 'morning',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Incident & Issue Reports (Guest complaints, kitchen delays, operational notes)
    CREATE TABLE IF NOT EXISTS incident_reports (
      id TEXT PRIMARY KEY,
      table_number INTEGER,
      reported_by TEXT NOT NULL,
      issue_type TEXT NOT NULL,
      description TEXT NOT NULL,
      priority TEXT DEFAULT 'normal' CHECK(priority IN ('low', 'normal', 'high', 'urgent')),
      status TEXT DEFAULT 'open' CHECK(status IN ('open', 'in_progress', 'resolved')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_at TEXT
    );

    -- Performance Indexes
    CREATE INDEX IF NOT EXISTS idx_tables_active ON tables(is_active);
    CREATE INDEX IF NOT EXISTS idx_orders_table_status ON orders(table_id, status);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
    CREATE INDEX IF NOT EXISTS idx_staff_calls_status ON staff_calls(status);
    CREATE INDEX IF NOT EXISTS idx_menu_category ON menu_items(category_id);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_event ON audit_logs(event_type, created_at);
    CREATE INDEX IF NOT EXISTS idx_incidents_status ON incident_reports(status);
  `);

  // Safe schema migrations for existing databases
  try {
    db.exec(`ALTER TABLE staff_calls ADD COLUMN call_type TEXT DEFAULT 'general'`);
  } catch (e) {
    // Column already exists
  }
}

initSchema();

module.exports = db;
