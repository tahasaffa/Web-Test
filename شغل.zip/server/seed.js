const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const QRCode = require('qrcode');
const db = require('./db');
const config = require('./config');

async function seed() {
  console.log('[SEED] Seeding database with initial data...');

  // 1. Seed Restaurant Settings & Password Hashes
  const adminHash = bcrypt.hashSync(config.defaultAdminPassword, config.bcryptSaltRounds);
  const staffHash = bcrypt.hashSync(config.defaultStaffPassword, config.bcryptSaltRounds);

  const setSetting = db.prepare(`
    INSERT INTO restaurant_settings (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
  `);

  setSetting.run('restaurant_name_ar', config.defaults.restaurantNameAr);
  setSetting.run('restaurant_name_en', config.defaults.restaurantNameEn);
  setSetting.run('currency', config.defaults.currency);
  setSetting.run('admin_password_hash', adminHash);
  setSetting.run('staff_password_hash', staffHash);

  // 2. Seed Categories
  const categories = [
    { id: 'cat-appetizers', name_ar: 'المقبلات والسلطات', name_en: 'Appetizers & Salads', sort_order: 1 },
    { id: 'cat-mains', name_ar: 'الأطباق الرئيسية', name_en: 'Main Courses', sort_order: 2 },
    { id: 'cat-drinks', name_ar: 'المشروبات والعصائر', name_en: 'Beverages & Juices', sort_order: 3 },
    { id: 'cat-desserts', name_ar: 'الحلويات الشرقية والغربية', name_en: 'Desserts', sort_order: 4 },
  ];

  const insertCategory = db.prepare(`
    INSERT INTO categories (id, name_ar, name_en, sort_order)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      name_ar = excluded.name_ar,
      name_en = excluded.name_en,
      sort_order = excluded.sort_order
  `);

  for (const cat of categories) {
    insertCategory.run(cat.id, cat.name_ar, cat.name_en, cat.sort_order);
  }

  // 3. Seed Menu Items
  const menuItems = [
    // Appetizers
    {
      id: 'item-hummus',
      category_id: 'cat-appetizers',
      name_ar: 'حمص بيروتي فاخر',
      name_en: 'Premium Beiruti Hummus',
      description_ar: 'حمص ناعم بزيت الزيتون البكر، بقدونس، ثوم، ورشة كمون مع الخبز الساخن.',
      description_en: 'Silky smooth chickpea puree with virgin olive oil, garlic, parsley, and warm pita.',
      price: 5000,
      image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    {
      id: 'item-batata-harra',
      category_id: 'cat-appetizers',
      name_ar: 'بطاطا حارة مقرمشة',
      name_en: 'Crispy Batata Harra',
      description_ar: 'مكعبات بطاطا ذهبية مقلية متبلة بالكزبرة الطازجة، الثوم، الفلفل الحار والليمون.',
      description_en: 'Golden crispy potato cubes tossed in fresh coriander, garlic, chili, and lemon.',
      price: 6000,
      image_url: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    // Mains
    {
      id: 'item-mixed-grill',
      category_id: 'cat-mains',
      name_ar: 'صحن مشاوي مشكل مشوي على الفحم',
      name_en: 'Charcoal Mixed Grill Platter',
      description_ar: 'سيخ كباب لحم، سيخ شيش طاووق، وسيخ أوصال لحم نعيمي يقدم مع الخضار المشوية والأرز البسمتي.',
      description_en: 'Tender lamb kebab, chicken shish tawook, and lamb cubes grilled over charcoal with rice.',
      price: 24000,
      image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    {
      id: 'item-shawarma-plate',
      category_id: 'cat-mains',
      name_ar: 'طبق شاورما عربي دجاج مع الصوصات',
      name_en: 'Arabic Chicken Shawarma Plate',
      description_ar: 'شاورما دجاج متبلة ومقطعة في خبز الصاج مع بطاطس مقلية، ثومية، ومخللات خاصة.',
      description_en: 'Marinated roasted chicken shawarma sliced in saj bread with garlic dip and crispy fries.',
      price: 9000,
      image_url: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    {
      id: 'item-burger',
      category_id: 'cat-mains',
      name_ar: 'برجر أنجوس بيف مدخن بجبنة الشيدر',
      name_en: 'Smoked Angus Beef Burger',
      description_ar: 'قطعة لحم أنجوس مشوية مع جبن الشيدر الذائب، بصل مكرمل، وصوص الشيف الخاص.',
      description_en: 'Char-grilled Angus beef patty, melted cheddar, caramelized onions, and chef special sauce.',
      price: 12000,
      image_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    // Beverages
    {
      id: 'item-mojito',
      category_id: 'cat-drinks',
      name_ar: 'موهيتو ليمون ونعناع مثلج',
      name_en: 'Iced Lemon Mint Mojito',
      description_ar: 'عصير منعش من الليمون والنعناع الطازج مع الصودا الفوارة والثلج المجروش.',
      description_en: 'Refreshing blend of crushed mint, zesty lime, sparkling soda, and crushed ice.',
      price: 4000,
      image_url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    {
      id: 'item-orange-juice',
      category_id: 'cat-drinks',
      name_ar: 'عصير برتقال طبيعي 100%',
      name_en: '100% Fresh Orange Juice',
      description_ar: 'برتقال طازج معصور مباشرة عند الطلب بدون إضافة سكر.',
      description_en: 'Freshly squeezed premium oranges with no added sugar.',
      price: 4000,
      image_url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    // Desserts
    {
      id: 'item-kunafa',
      category_id: 'cat-desserts',
      name_ar: 'كنافة نابلسية بالجبن الفاخر',
      name_en: 'Traditional Cheese Nabulsi Kunafa',
      description_ar: 'كنافة ذهبية مقرمشة محشوة بالجبن النابلسي الطازج مع الشيرة ورشة فستق حلبي.',
      description_en: 'Crispy spun pastry layered with sweet melted cheese, sugar syrup, and crushed pistachios.',
      price: 7000,
      image_url: 'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    },
    {
      id: 'item-umm-ali',
      category_id: 'cat-desserts',
      name_ar: 'أم علي ملكية بالمكسرات والكريمة',
      name_en: 'Royal Umm Ali with Mixed Nuts',
      description_ar: 'حلوى أم علي الساخنة المخبوزة بالحليب الطازج والكريمة الغنية مع الفستق واللوز والزبيب.',
      description_en: 'Traditional warm bread pudding baked with rich cream, milk, raisins, and roasted nuts.',
      price: 6000,
      image_url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=600&auto=format&fit=crop&q=80',
      is_available: 1
    }
  ];

  const insertMenuItem = db.prepare(`
    INSERT INTO menu_items (id, category_id, name_ar, name_en, description_ar, description_en, price, image_url, is_available)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      category_id = excluded.category_id,
      name_ar = excluded.name_ar,
      name_en = excluded.name_en,
      description_ar = excluded.description_ar,
      description_en = excluded.description_en,
      price = excluded.price,
      image_url = excluded.image_url,
      is_available = excluded.is_available,
      updated_at = datetime('now')
  `);

  for (const item of menuItems) {
    insertMenuItem.run(
      item.id,
      item.category_id,
      item.name_ar,
      item.name_en,
      item.description_ar,
      item.description_en,
      item.price,
      item.image_url,
      item.is_available
    );
  }

  // 4. Seed Tables with non-sequential UUIDs and QR Codes
  const initialTables = [
    { number: 1, id: 'a1b2c3d4-e5f6-4a1b-8c2d-3e4f5a6b7c8d' },
    { number: 2, id: 'b2c3d4e5-f6a1-4b2c-9d3e-4f5a6b7c8d9e' },
    { number: 3, id: 'c3d4e5f6-a1b2-4c3d-ae4f-5a6b7c8d9e0f' },
    { number: 4, id: 'd4e5f6a1-b2c3-4d4e-bf5a-6b7c8d9e0f1a' },
    { number: 5, id: 'e5f6a1b2-c3d4-4e5f-c06b-7c8d9e0f1a2b' },
  ];

  const insertTable = db.prepare(`
    INSERT INTO tables (id, table_number, qr_code_url, is_active)
    VALUES (?, ?, ?, 1)
    ON CONFLICT(id) DO UPDATE SET
      table_number = excluded.table_number,
      qr_code_url = excluded.qr_code_url,
      is_active = excluded.is_active
  `);

  for (const tbl of initialTables) {
    const tableUrl = `${config.clientUrl}/table/${tbl.id}`;
    // Generate QR code Data URL
    const qrDataUrl = await QRCode.toDataURL(tableUrl, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 320,
      color: {
        dark: '#1e293b',
        light: '#ffffff'
      }
    });

    insertTable.run(tbl.id, tbl.number, qrDataUrl);
  }

  // 5. Seed Staff Members Directory
  const staffMembers = [
    { id: 'staff-1', name: 'أحمد المنصور', role: 'كاشير رئيسي (Cashier)', phone: '0551234567', shift: 'مسائي' },
    { id: 'staff-2', name: 'الشيف فهد العمري', role: 'شيف أول (Head Chef)', phone: '0559876543', shift: 'صباحي' },
    { id: 'staff-3', name: 'سامي القحطاني', role: 'ويتر صالة (Head Waiter)', phone: '0554433221', shift: 'مسائي' },
    { id: 'staff-4', name: 'ريم السالم', role: 'مشرفة خدمة عملاء (Supervisor)', phone: '0556677889', shift: 'صباحي' }
  ];

  const insertStaffMember = db.prepare(`
    INSERT INTO staff_members (id, name, role, phone, shift, is_active)
    VALUES (?, ?, ?, ?, ?, 1)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      role = excluded.role,
      phone = excluded.phone,
      shift = excluded.shift
  `);

  for (const sm of staffMembers) {
    insertStaffMember.run(sm.id, sm.name, sm.role, sm.phone, sm.shift);
  }

  // 6. Seed Sample Incident Report
  const incidentCount = db.prepare('SELECT COUNT(*) as c FROM incident_reports').get().c;
  if (incidentCount === 0) {
    db.prepare(`
      INSERT INTO incident_reports (id, table_number, reported_by, issue_type, description, priority, status)
      VALUES (?, 2, 'سامي القحطاني (ويتر)', 'تكييف الصالة', 'طلب العميل تخفيض درجة برودة التكييف وتم تعديلها فوراً', 'low', 'resolved')
    `).run('inc-demo-1');
  }

  console.log('[SEED SUCCESS] Seeding completed:');
  console.log(`- Categories: ${categories.length}`);
  console.log(`- Menu Items: ${menuItems.length}`);
  console.log(`- Tables: ${initialTables.length}`);
  console.log(`- Staff Members: ${staffMembers.length}`);
  console.log(`- Admin default password: ${config.defaultAdminPassword}`);
  console.log(`- Staff default password: ${config.defaultStaffPassword}`);
}

if (require.main === module) {
  seed().then(() => process.exit(0)).catch(err => {
    console.error('[SEED ERROR]', err);
    process.exit(1);
  });
}

module.exports = seed;
