const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const config = require('./config');

let io = null;

function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: '*', // Allow all origins in dev, or config.clientUrl
      methods: ['GET', 'POST', 'PATCH']
    }
  });

  io.on('connection', (socket) => {
    // 1. Customer joins room for their specific table
    socket.on('join_table', (tableId) => {
      if (typeof tableId === 'string' && tableId.trim()) {
        const room = `table:${tableId.trim()}`;
        socket.join(room);
        socket.emit('joined_room', { room, success: true });
      }
    });

    // 2. Staff joins staff room after validating token
    socket.on('join_staff', (token) => {
      try {
        if (!token) throw new Error('No token');
        const decoded = jwt.verify(token, config.jwtSecret);
        if (decoded.role === 'staff' || decoded.role === 'admin') {
          socket.join('staff');
          socket.emit('joined_staff', { success: true, role: decoded.role });
        }
      } catch (err) {
        socket.emit('staff_auth_error', { message: 'Unauthorized staff socket connection' });
      }
    });

    socket.on('disconnect', () => {
      // Handled automatically by socket.io
    });
  });

  return io;
}

function getIO() {
  return io;
}

// Broadcasting helpers
function notifyNewOrder(order) {
  if (!io) return;
  // Broadcast to staff/kitchen display
  io.to('staff').emit('new_order', order);
  // Broadcast to specific table room
  io.to(`table:${order.table_id}`).emit('order_placed', order);
}

function notifyOrderStatusUpdated(order) {
  if (!io) return;
  io.to('staff').emit('order_status_updated', order);
  io.to(`table:${order.table_id}`).emit('order_status_updated', order);
}

function notifyStaffCall(call) {
  if (!io) return;
  io.to('staff').emit('new_staff_call', call);
  io.to(`table:${call.table_id}`).emit('call_submitted', call);
}

function notifyStaffCallAcknowledged(call) {
  if (!io) return;
  io.to('staff').emit('staff_call_acknowledged', call);
  io.to(`table:${call.table_id}`).emit('staff_call_acknowledged', call);
}

function notifyTableSettled(tableId, summary) {
  if (!io) return;
  io.to('staff').emit('table_settled', { tableId, summary });
  io.to(`table:${tableId}`).emit('table_settled', { tableId, summary });
}

function notifyNewIncident(incident) {
  if (!io) return;
  io.to('staff').emit('new_incident', incident);
}

module.exports = {
  initSocket,
  getIO,
  notifyNewOrder,
  notifyOrderStatusUpdated,
  notifyStaffCall,
  notifyStaffCallAcknowledged,
  notifyTableSettled,
  notifyNewIncident
};

