const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const config = {
  port: parseInt(process.env.PORT, 10) || 4000,
  nodeEnv: process.env.NODE_ENV || 'development',
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',

  // Authentication & Cryptography
  // JWT tokens are digitally signed with HMAC-SHA256 (not encrypted; payloads must not contain sensitive data)
  jwtSecret: process.env.JWT_SECRET || 'fallback_secret_min_32_chars_random_string_xyz',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  bcryptSaltRounds: 10,

  // Default Passwords (fallback if not yet seeded)
  defaultAdminPassword: process.env.ADMIN_PASSWORD || '',
  defaultStaffPassword: process.env.STAFF_PASSWORD || '',

  // Storage Paths
  paths: {
    root: path.join(__dirname, '..'),
    dataDir: path.join(__dirname, 'data'),
    dbFile: path.join(__dirname, 'data', 'restaurant.db'),
    backupsDir: path.join(__dirname, '..', 'backups'),
    uploadsDir: path.join(__dirname, 'uploads'),
    imagesDir: path.join(__dirname, 'uploads', 'images'),
  },

  // Security & Rate Limiting Configurations
  security: {
    orderRateLimitMs: 30 * 1000, // 30 seconds per table
    callRateLimitMs: 45 * 1000,  // 45 seconds per table
    loginWindowMs: 15 * 60 * 1000, // 15 minutes window
    loginMaxAttempts: 5,         // Max 5 failed attempts per window
    maxUploadSize: 5 * 1024 * 1024, // 5MB image limit
    allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
  },

  // Restaurant defaults
  defaults: {
    restaurantNameAr: process.env.RESTAURANT_NAME_AR || 'مطعم اللذة الذكية',
    restaurantNameEn: process.env.RESTAURANT_NAME_EN || 'Smart Gourmet Restaurant',
    currency: process.env.CURRENCY || 'IQD',
  }
};

module.exports = config;
