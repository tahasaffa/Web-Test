/**
 * CLI Admin Password Reset Script (npm run reset-admin -- --password "MyNewPass123")
 * Allows server administrator to directly reset the Admin password from the terminal.
 */

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../db');
const config = require('../config');

function resetAdminPassword() {
  const args = process.argv.slice(2);
  let newPassword = null;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--password' && args[i + 1]) {
      newPassword = args[i + 1];
      break;
    } else if (!args[i].startsWith('--')) {
      newPassword = args[i];
      break;
    }
  }

  if (!newPassword || newPassword.trim().length < 6) {
    console.error('Usage: npm run reset-admin -- --password "NewPassword123"');
    console.error('Password must be at least 6 characters long.');
    process.exit(1);
  }

  try {
    const passwordHash = bcrypt.hashSync(newPassword.trim(), config.bcryptSaltRounds);

    const upsertStmt = db.prepare(`
      INSERT INTO restaurant_settings (key, value, updated_at)
      VALUES ('admin_password_hash', ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET
        value = excluded.value,
        updated_at = excluded.updated_at
    `);
    upsertStmt.run(passwordHash);

    // Audit log
    const auditStmt = db.prepare(`
      INSERT INTO audit_logs (id, event_type, role, ip_address, user_agent, details, created_at)
      VALUES (?, 'ADMIN_PASSWORD_RESET_CLI', 'admin', '127.0.0.1', 'CLI-TOOL', 'Admin password was reset via CLI script', datetime('now'))
    `);
    auditStmt.run(crypto.randomUUID());

    console.log('----------------------------------------------------');
    console.log('[SUCCESS] Admin password has been successfully reset!');
    console.log(`[LOGIN] You can now log in at /admin using your new password.`);
    console.log('----------------------------------------------------');
  } catch (err) {
    console.error('[ERROR] Failed to reset admin password:', err);
    process.exit(1);
  }
}

if (require.main === module) {
  resetAdminPassword();
}

module.exports = resetAdminPassword;
