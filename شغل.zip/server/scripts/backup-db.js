/**
 * Database Backup Script (npm run backup-db)
 * Safely creates a timestamped point-in-time snapshot of restaurant.db in the backups/ directory.
 * 
 * Manual Restore Instructions:
 * 1. Stop the application server (Ctrl+C / PM2 stop).
 * 2. Locate the desired backup file in the "backups/" folder, e.g.:
 *    backups/restaurant-backup-2026-09-03T10-30-00.db
 * 3. Copy/rename the file to overwrite:
 *    server/data/restaurant.db
 * 4. Restart the server:
 *    npm start
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');
const db = require('../db');

async function runBackup() {
  try {
    if (!fs.existsSync(config.paths.backupsDir)) {
      fs.mkdirSync(config.paths.backupsDir, { recursive: true });
    }

    // Format ISO timestamp without colons for Windows filename compatibility
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupFileName = `restaurant-backup-${timestamp}.db`;
    const backupFilePath = path.join(config.paths.backupsDir, backupFileName);

    console.log(`[BACKUP] Starting database snapshot to: ${backupFilePath}...`);
    
    // SQLite safe online backup API
    await db.backup(backupFilePath);
    
    const stats = fs.statSync(backupFilePath);
    console.log(`[BACKUP SUCCESS] Backup completed successfully!`);
    console.log(`[BACKUP INFO] File: ${backupFileName} (${(stats.size / 1024).toFixed(2)} KB)`);
    console.log(`[BACKUP PATH] ${backupFilePath}`);
  } catch (err) {
    console.error(`[BACKUP ERROR] Failed to backup database:`, err);
    process.exit(1);
  }
}

if (require.main === module) {
  runBackup().then(() => process.exit(0));
}

module.exports = runBackup;
