const http = require('http');
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');

const config = require('./config');
const db = require('./db');
const { initSocket } = require('./socket');

// Route handlers
const authRoutes = require('./routes/auth');
const menuRoutes = require('./routes/menu');
const tablesRoutes = require('./routes/tables');
const ordersRoutes = require('./routes/orders');
const staffCallsRoutes = require('./routes/staffCalls');
const staffRoutes = require('./routes/staff');
const adminRoutes = require('./routes/admin');
const uploadRoutes = require('./routes/upload');
const feedbackRoutes = require('./routes/feedback');

const app = express();
const httpServer = http.createServer(app);

// 1. Initialize Real-Time WebSockets
initSocket(httpServer);

// 2. Global Middlewares
app.use(cors({
  origin: '*', // Allows local dev and cross-device network testing
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// 3. Static Assets: Serve uploaded images
if (!fs.existsSync(config.paths.imagesDir)) {
  fs.mkdirSync(config.paths.imagesDir, { recursive: true });
}
app.use('/uploads', express.static(config.paths.uploadsDir));

// 4. API Endpoints
app.use('/api', authRoutes);
app.use('/api', menuRoutes);
app.use('/api', tablesRoutes);
app.use('/api', ordersRoutes);
app.use('/api', staffCallsRoutes);
app.use('/api', staffRoutes);
app.use('/api', adminRoutes);
app.use('/api', uploadRoutes);
app.use('/api', feedbackRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    time: new Date().toISOString(),
    version: '1.0.0',
    db: 'connected'
  });
});

// 5. Production Static Frontend Serving (When client/dist exists)
const clientDistPath = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(clientDistPath)) {
  app.use(express.static(clientDistPath));
  // Single Page Application (SPA) fallback
  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api') && !req.path.startsWith('/uploads')) {
      return res.sendFile(path.join(clientDistPath, 'index.html'));
    }
    next();
  });
}

// 6. 404 handler for unmatched API routes
app.use('/api', (req, res) => {
  res.status(404).json({
    success: false,
    error: `المسار المطلوب غير موجود (${req.method} ${req.originalUrl})`
  });
});

// 7. Global Error Handler
app.use((err, req, res, next) => {
  console.error('[UNHANDLED SERVER ERROR]', err);
  res.status(500).json({
    success: false,
    error: 'حدث خطأ غير متوقع في الخادم'
  });
});

// 8. Start HTTP & WebSocket Server
if (require.main === module) {
  httpServer.listen(config.port, '0.0.0.0', () => {
    console.log('====================================================');
    console.log(`[SERVER RUNNING] Smart Restaurant Server is active!`);
    console.log(`[URL] http://localhost:${config.port}`);
    console.log(`[SOCKET.IO] WebSocket server attached & ready`);
    console.log(`[DATABASE] SQLite WAL Mode connected (${config.paths.dbFile})`);
    console.log('====================================================');
  });
}

module.exports = { app, httpServer };
