const crypto = require('crypto');
const db = require('../db');

/**
 * Record a security or administrative audit event.
 * Uses 100% parameterized queries.
 */
function logAuditEvent({ eventType, role = null, ipAddress = null, userAgent = null, details = null }) {
  try {
    const stmt = db.prepare(`
      INSERT INTO audit_logs (id, event_type, role, ip_address, user_agent, details, created_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    `);

    stmt.run(
      crypto.randomUUID(),
      eventType,
      role,
      ipAddress,
      userAgent,
      typeof details === 'object' ? JSON.stringify(details) : details
    );
  } catch (err) {
    console.error('[AUDIT LOG ERROR] Failed to record audit log:', err);
  }
}

module.exports = {
  logAuditEvent
};
