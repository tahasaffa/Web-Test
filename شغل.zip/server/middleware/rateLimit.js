const rateLimit = require('express-rate-limit');
const config = require('../config');

// In-memory timestamps for table-level rate limiting
const tableOrderTimestamps = new Map();
const tableCallTimestamps = new Map();

/**
 * Cleanup expired in-memory map entries periodically (every 10 minutes)
 */
setInterval(() => {
  const now = Date.now();
  for (const [tableId, lastTime] of tableOrderTimestamps.entries()) {
    if (now - lastTime > config.security.orderRateLimitMs * 2) {
      tableOrderTimestamps.delete(tableId);
    }
  }
  for (const [tableId, lastTime] of tableCallTimestamps.entries()) {
    if (now - lastTime > config.security.callRateLimitMs * 2) {
      tableCallTimestamps.delete(tableId);
    }
  }
}, 10 * 60 * 1000);

/**
 * Rate limiter for order placement:
 * Enforces a minimum interval between orders for the same table_id (30 seconds)
 */
function tableOrderRateLimiter(req, res, next) {
  const tableId = req.body.table_id || req.body.tableId;
  if (!tableId) {
    return res.status(400).json({
      success: false,
      error: 'معرف الطاولة مطلوب (table_id is required)'
    });
  }

  const now = Date.now();
  const lastOrderTime = tableOrderTimestamps.get(tableId);

  if (lastOrderTime) {
    const elapsed = now - lastOrderTime;
    if (elapsed < config.security.orderRateLimitMs) {
      const remainingSeconds = Math.ceil((config.security.orderRateLimitMs - elapsed) / 1000);
      return res.status(429).json({
        success: false,
        error: `يرجى الانتظار ${remainingSeconds} ثانية قبل إرسال طلب جديد لهذه الطاولة (Anti-spam rate limit).`,
        retryAfter: remainingSeconds
      });
    }
  }

  // Record this order attempt
  tableOrderTimestamps.set(tableId, now);
  next();
}

/**
 * Rate limiter for waiter calls:
 * Enforces a minimum interval between calls for the same table_id (45 seconds)
 */
function tableCallRateLimiter(req, res, next) {
  const tableId = req.body.table_id || req.body.tableId;
  if (!tableId) {
    return res.status(400).json({
      success: false,
      error: 'معرف الطاولة مطلوب (table_id is required)'
    });
  }

  const now = Date.now();
  const lastCallTime = tableCallTimestamps.get(tableId);

  if (lastCallTime) {
    const elapsed = now - lastCallTime;
    if (elapsed < config.security.callRateLimitMs) {
      const remainingSeconds = Math.ceil((config.security.callRateLimitMs - elapsed) / 1000);
      return res.status(429).json({
        success: false,
        error: `تم إرسال نداء الويتر مسبقاً، يرجى الانتظار ${remainingSeconds} ثانية قبل إعادة الإرسال.`,
        retryAfter: remainingSeconds
      });
    }
  }

  tableCallTimestamps.set(tableId, now);
  next();
}

/**
 * Login Rate Limiter — Disabled (unlimited attempts allowed)
 * Pass-through middleware: always calls next()
 */
function loginRateLimiter(req, res, next) {
  next();
}

module.exports = {
  tableOrderRateLimiter,
  tableCallRateLimiter,
  loginRateLimiter
};
