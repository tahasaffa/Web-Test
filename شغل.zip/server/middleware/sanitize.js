/**
 * Input Sanitization Middleware to prevent Cross-Site Scripting (XSS)
 * and malicious payload injection into notes or fields.
 */

function sanitizeString(str, maxLength = 500) {
  if (typeof str !== 'string') return str;
  // 1. Strip HTML tags
  let cleaned = str.replace(/<[^>]*>?/gm, '');
  // 2. Remove null bytes and control chars
  cleaned = cleaned.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  // 3. Trim whitespace
  cleaned = cleaned.trim();
  // 4. Enforce max length
  if (cleaned.length > maxLength) {
    cleaned = cleaned.substring(0, maxLength);
  }
  return cleaned;
}

function sanitizeObject(obj) {
  if (!obj || typeof obj !== 'object') return obj;

  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeObject(item));
  }

  const sanitized = {};
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string') {
      sanitized[key] = sanitizeString(value);
    } else if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeObject(value);
    } else {
      sanitized[key] = value;
    }
  }
  return sanitized;
}

function sanitizeBody(req, res, next) {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeObject(req.body);
  }
  next();
}

module.exports = {
  sanitizeString,
  sanitizeObject,
  sanitizeBody
};
