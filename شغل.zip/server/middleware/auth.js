const jwt = require('jsonwebtoken');
const config = require('../config');

/**
 * Generate a digitally signed JWT token.
 * 
 * IMPORTANT ARCHITECTURAL NOTE:
 * JWT tokens are DIGITALLY SIGNED with HMAC-SHA256, NOT ENCRYPTED.
 * The payload is tamper-evident (cannot be forged or modified without knowing JWT_SECRET),
 * but is base64-encoded and readable by anyone who holds it.
 * Therefore, NEVER store passwords, secrets, or sensitive personal data in this payload.
 */
function generateToken(role) {
  const payload = {
    role: role, // 'staff' or 'admin'
    sub: role,
    type: 'access_token'
  };

  return jwt.sign(payload, config.jwtSecret, {
    expiresIn: config.jwtExpiresIn,
    algorithm: 'HS256'
  });
}

/**
 * Middleware: Verify JWT signature and expiration
 */
function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'لم يتم توفير رمز التوثيق (Authorization token missing or invalid)'
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    req.user = decoded;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        error: 'انتهت صلاحية جلسة الدخول، يرجى تسجيل الدخول مجدداً (Token expired)'
      });
    }
    return res.status(401).json({
      success: false,
      error: 'رمز التوثيق غير صالح أو تم التلاعب به (Invalid token signature)'
    });
  }
}

/**
 * Middleware: Enforce Role-Based Access Control (RBAC)
 * Strictly verifies role claim on the backend before executing any controller action.
 */
function requireRole(allowedRoles) {
  const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];

  return (req, res, next) => {
    verifyToken(req, res, () => {
      if (!req.user || !roles.includes(req.user.role)) {
        return res.status(403).json({
          success: false,
          error: 'ليس لديك الصلاحية الكافية لتنفيذ هذا الإجراء (Forbidden: Insufficient permissions)'
        });
      }
      next();
    });
  };
}

module.exports = {
  generateToken,
  verifyToken,
  requireRole,
  requireStaff: requireRole(['staff', 'admin']), // Admin can also perform staff tasks
  requireAdmin: requireRole(['admin']),          // Only Admin can perform admin tasks
};
