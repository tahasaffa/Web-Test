/**
 * Automated Verification & Test Suite for Smart Restaurant System (Phase 1)
 * Tests all endpoints, security guards, role separation, rate limiters, transactions, and audit logging.
 */

const http = require('http');
const { app, httpServer } = require('./server');
const config = require('./config');
const db = require('./db');
const seed = require('./seed');

const PORT = 4099; // Isolated test port
let BASE_URL = `http://127.0.0.1:${PORT}`;

// Helper to make HTTP requests
function request(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: method.toUpperCase(),
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(data);
        } catch (e) {
          json = data;
        }
        resolve({ status: res.statusCode, headers: res.headers, body: json });
      });
    });

    req.on('error', reject);
    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(`[ASSERTION FAILED] ${message}`);
  }
}

async function runTests() {
  console.log('====================================================');
  console.log('STARTING PHASE 1 AUTOMATED VERIFICATION SUITE');
  console.log('====================================================');

  // Start test server
  await new Promise(resolve => httpServer.listen(PORT, '127.0.0.1', resolve));
  console.log(`[TEST SERVER] Running on port ${PORT}`);

  try {
    // 0. Ensure seeded state
    await seed();

    // 1. Health Check
    console.log('\n[TEST 1] Checking API Health...');
    const health = await request('GET', '/api/health');
    assert(health.status === 200, `Health check returned ${health.status}`);
    assert(health.body.status === 'healthy', 'Health status should be healthy');
    console.log('✓ PASS: Health check endpoint working.');

    // 2. Public Menu
    console.log('\n[TEST 2] Testing Public Menu Endpoint (GET /api/menu)...');
    const menuRes = await request('GET', '/api/menu');
    assert(menuRes.status === 200, `Menu returned ${menuRes.status}`);
    assert(menuRes.body.data.categories.length > 0, 'Categories should not be empty');
    assert(menuRes.body.data.allItems.length > 0, 'Menu items should not be empty');
    const sampleItem = menuRes.body.data.allItems[0];
    assert(sampleItem.price > 0, 'Item must have a valid price');
    console.log(`✓ PASS: Menu returned ${menuRes.body.data.categories.length} categories and ${menuRes.body.data.allItems.length} items.`);

    // 3. Table Validation
    console.log('\n[TEST 3] Testing Table Validation (GET /api/tables/:id/validate)...');
    const validTableId = 'a1b2c3d4-e5f6-4a1b-8c2d-3e4f5a6b7c8d';
    const invalidTableId = '00000000-0000-0000-0000-000000000000';

    const validTableRes = await request('GET', `/api/tables/${validTableId}/validate`);
    assert(validTableRes.status === 200, `Valid table check failed: ${validTableRes.status}`);
    assert(validTableRes.body.data.table.table_number === 1, 'Table number should be 1');

    const invalidTableRes = await request('GET', `/api/tables/${invalidTableId}/validate`);
    assert(invalidTableRes.status === 404, `Invalid table should return 404, got ${invalidTableRes.status}`);
    console.log('✓ PASS: Table validation correctly verifies valid table and rejects invalid UUID.');

    // 4. Authentication & Role Separation (RBAC)
    console.log('\n[TEST 4] Testing Authentication and Strict Role Separation...');
    // Failed staff login
    const badStaffLogin = await request('POST', '/api/staff/login', { password: 'WrongPassword' });
    assert(badStaffLogin.status === 401, 'Wrong staff password should return 401');

    // Success staff login
    const goodStaffLogin = await request('POST', '/api/staff/login', { password: config.defaultStaffPassword });
    assert(goodStaffLogin.status === 200, 'Staff login should succeed');
    assert(goodStaffLogin.body.token, 'Token must be present');
    assert(goodStaffLogin.body.role === 'staff', 'Role must be staff');
    const staffToken = goodStaffLogin.body.token;

    // Success admin login
    const goodAdminLogin = await request('POST', '/api/admin/login', { password: config.defaultAdminPassword });
    assert(goodAdminLogin.status === 200, 'Admin login should succeed');
    assert(goodAdminLogin.body.role === 'admin', 'Role must be admin');
    const adminToken = goodAdminLogin.body.token;

    // Check staff access to staff endpoints
    const staffOrdersRes = await request('GET', '/api/staff/orders', null, {
      'Authorization': `Bearer ${staffToken}`
    });
    assert(staffOrdersRes.status === 200, 'Staff should access staff orders');

    // CRITICAL SECURITY TEST: Staff attempting to access Admin endpoint must be REJECTED with 403 Forbidden!
    const unauthorizedAdminAccess = await request('GET', '/api/admin/tables', null, {
      'Authorization': `Bearer ${staffToken}`
    });
    assert(unauthorizedAdminAccess.status === 403, `Staff token accessing admin route must return 403, got ${unauthorizedAdminAccess.status}`);

    // Admin accessing admin endpoint
    const authorizedAdminAccess = await request('GET', '/api/admin/tables', null, {
      'Authorization': `Bearer ${adminToken}`
    });
    assert(authorizedAdminAccess.status === 200, 'Admin should access admin tables');
    console.log('✓ PASS: Strict RBAC enforced: Staff token correctly rejected (403) from Admin routes.');

    // 5. Order Placement & Pricing Calculation
    console.log('\n[TEST 5] Testing Order Creation (POST /api/orders)...');
    const orderPayload = {
      table_id: validTableId,
      items: [
        { menu_item_id: 'item-hummus', quantity: 2, notes: 'بدون بصل <script>alert(1)</script>' }, // XSS test
        { menu_item_id: 'item-burger', quantity: 1, notes: 'مستوي جيداً' }
      ]
    };

    const orderRes = await request('POST', '/api/orders', orderPayload);
    assert(orderRes.status === 201, `Order creation failed: ${orderRes.status}`);
    const createdOrder = orderRes.body.data;
    assert(createdOrder.status === 'new', 'Initial status must be new');
    // Hummus = 22 * 2 = 44, Burger = 45 * 1 = 45 -> Total = 89
    assert(createdOrder.total_amount === 89, `Total should be 89, got ${createdOrder.total_amount}`);
    
    // Check XSS sanitization
    const hummusItem = createdOrder.items.find(i => i.menu_item_id === 'item-hummus');
    assert(!hummusItem.notes.includes('<script>'), `Notes must be sanitized: ${hummusItem.notes}`);
    console.log(`✓ PASS: Order created with accurate pricing (89 SAR) and sanitized customer notes: "${hummusItem.notes}".`);

    // 6. Anti-Spam Rate Limiting on Orders
    console.log('\n[TEST 6] Testing Anti-Spam Rate Limiting on Orders (30s cooldown)...');
    const rapidOrderRes = await request('POST', '/api/orders', orderPayload);
    assert(rapidOrderRes.status === 429, `Rapid order should be rate limited (429), got ${rapidOrderRes.status}`);
    console.log(`✓ PASS: Rapid consecutive order rejected with HTTP 429 (Rate limited).`);

    // 7. Active Table Orders and Bill Total
    console.log('\n[TEST 7] Testing Table Active Orders & Bill Summary...');
    const activeOrdersRes = await request('GET', `/api/orders/table/${validTableId}/active`);
    assert(activeOrdersRes.status === 200, 'Active orders query failed');
    assert(activeOrdersRes.body.data.total_bill_amount === 89, `Total bill should be 89, got ${activeOrdersRes.body.data.total_bill_amount}`);
    console.log(`✓ PASS: Active table bill calculated correctly: ${activeOrdersRes.body.data.total_bill_amount} SAR.`);

    // 8. Waiter Call & Rate Limit
    console.log('\n[TEST 8] Testing Waiter Call & Cooldown...');
    const callRes = await request('POST', '/api/staff-calls', { table_id: validTableId });
    assert(callRes.status === 201, 'Waiter call failed');
    const rapidCallRes = await request('POST', '/api/staff-calls', { table_id: validTableId });
    assert(rapidCallRes.status === 429, 'Rapid call should be rate limited (429)');
    console.log('✓ PASS: Waiter call submitted and anti-spam cooldown triggered.');

    // Staff acknowledges call
    const pendingCalls = await request('GET', '/api/staff/calls', null, { 'Authorization': `Bearer ${staffToken}` });
    assert(pendingCalls.body.data.length > 0, 'Pending calls should exist');
    const callToAck = pendingCalls.body.data[0];
    const ackRes = await request('PATCH', `/api/staff/calls/${callToAck.id}/acknowledge`, {}, { 'Authorization': `Bearer ${staffToken}` });
    assert(ackRes.status === 200, 'Acknowledge call failed');
    console.log('✓ PASS: Staff successfully acknowledged waiter call.');

    // 9. Order Lifecycle & Cashier Settlement
    console.log('\n[TEST 9] Testing Order Lifecycle Transitions & Cashier Settlement...');
    // Update status to preparing
    const prepRes = await request('PATCH', `/api/staff/orders/${createdOrder.id}/status`, { status: 'preparing' }, { 'Authorization': `Bearer ${staffToken}` });
    assert(prepRes.body.data.status === 'preparing', 'Status should be preparing');
    // Update status to ready
    const readyRes = await request('PATCH', `/api/staff/orders/${createdOrder.id}/status`, { status: 'ready' }, { 'Authorization': `Bearer ${staffToken}` });
    assert(readyRes.body.data.status === 'ready', 'Status should be ready');

    // Settle table bill at cashier
    const settleRes = await request('POST', `/api/staff/tables/${validTableId}/settle`, {}, { 'Authorization': `Bearer ${staffToken}` });
    assert(settleRes.status === 200, 'Table settlement failed');
    assert(settleRes.body.data.total_paid === 89, 'Settled amount should match total');

    // Check table has 0 active orders now
    const afterSettleRes = await request('GET', `/api/orders/table/${validTableId}/active`);
    assert(afterSettleRes.body.data.active_orders_count === 0, 'Table should have 0 active orders after payment');
    console.log('✓ PASS: Order lifecycle completed and cashier bill settled.');

    // 10. Admin Table & QR Code Creation
    console.log('\n[TEST 10] Testing Admin Table Management & QR Code Generation...');
    const createTableRes = await request('POST', '/api/admin/tables', { table_number: 99 }, { 'Authorization': `Bearer ${adminToken}` });
    assert(createTableRes.status === 201, 'Table creation failed');
    assert(createTableRes.body.data.qr_code_url.startsWith('data:image/png;base64,'), 'QR code must be a valid PNG Data URL');
    console.log('✓ PASS: New table created with auto-generated high-resolution QR Code Data URL.');

    // 11. Admin Reports & Audit Logs
    console.log('\n[TEST 11] Testing Admin Sales Reports & Audit Logs...');
    const salesReportRes = await request('GET', '/api/admin/reports/sales', null, { 'Authorization': `Bearer ${adminToken}` });
    assert(salesReportRes.status === 200, 'Sales report failed');
    assert(salesReportRes.body.data.total.total_revenue >= 89, 'Total revenue should reflect paid orders');

    const auditRes = await request('GET', '/api/admin/audit-logs', null, { 'Authorization': `Bearer ${adminToken}` });
    assert(auditRes.status === 200, 'Audit logs fetch failed');
    assert(auditRes.body.data.length > 0, 'Audit logs must contain login events');
    console.log(`✓ PASS: Sales report retrieved (Revenue: ${salesReportRes.body.data.total.total_revenue} SAR) and ${auditRes.body.data.length} audit log entries verified.`);

    console.log('\n====================================================');
    console.log('🎉 ALL PHASE 1 VERIFICATION TESTS PASSED SUCCESSFULLY!');
    console.log('====================================================\n');
  } finally {
    await new Promise(resolve => httpServer.close(resolve));
  }
}

runTests()
  .then(() => {
    process.exit(0);
  })
  .catch(err => {
    console.error('\n❌ TEST FAILED:', err);
    process.exit(1);
  });
