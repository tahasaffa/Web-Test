require('dotenv').config();
const bcrypt = require('./node_modules/bcryptjs');
const Database = require('./node_modules/better-sqlite3');

const db = new Database('./server/data/restaurant.db');
const staffPw = process.env.STAFF_PASSWORD || 'Staff@1234';
const hash = bcrypt.hashSync(staffPw, 10);

db.prepare(`
  INSERT INTO restaurant_settings (key, value, updated_at)
  VALUES ('staff_password_hash', ?, datetime('now'))
  ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`).run(hash);

const row = db.prepare(`SELECT value FROM restaurant_settings WHERE key = 'staff_password_hash'`).get();
const valid = bcrypt.compareSync(staffPw, row.value);
console.log('Staff password updated:', valid ? 'SUCCESS' : 'FAILED');
db.close();
