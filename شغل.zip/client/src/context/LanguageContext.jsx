import React, { createContext, useContext, useState, useEffect } from 'react';

const translations = {
  ar: {
    // General
    appName: 'نظام الطلب الذكي',
    currency: 'د.ع',
    loading: 'جاري التحميل...',
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تعديل',
    add: 'إضافة',
    confirm: 'تأكيد',
    back: 'رجوع',
    close: 'إغلاق',
    status: 'الحالة',
    total: 'المجموع',
    notes: 'ملاحظات خاصة',
    actions: 'إجراءات',
    active: 'مفعل',
    inactive: 'معطل',

    // Customer Menu
    table: 'طاولة',
    scanRequired: 'يرجى مسح رمز الطاولة لبدء الطلب',
    searchPlaceholder: 'ابحث عن وجبتك المفضلة...',
    allCategories: 'الكل',
    viewCart: 'عرض السلة',
    cartEmpty: 'سلتك فارغة حالياً',
    addToCart: 'إضافة للسلة',
    sendOrder: 'إرسال الطلب للمطبخ',
    orderSent: 'تم استلام طلبك بنجاح!',
    callWaiter: 'نداء الويتر',
    waiterCalled: 'تم استدعاء الويتر، الموظف في طريقه إليك',
    callWaiterCooldown: 'يرجى الانتظار قليلاً قبل معاودة النداء',
    specialNotesHint: 'مثال: بدون بصل، صوص إضافي، درجة الاستواء...',
    orderStatus: 'حالة طلبك',
    billSummary: 'فاتورة الطاولة',
    unpaidTotal: 'الحساب غير المدفوع',
    outOfStock: 'غير متوفر حالياً',
    statusNew: 'تم الاستلام',
    statusPreparing: 'قيد التحضير في المطبخ',
    statusReady: 'جاهز للتقديم',
    statusServed: 'تم التقديم بالهناء والعافية',
    statusPaid: 'تم سداد الحساب',
    statusCancelled: 'ملغي',

    // Staff
    staffLogin: 'دخول الموظفين',
    passwordPlaceholder: 'أدخل كلمة مرور الموظفين',
    loginBtn: 'تسجيل الدخول',
    kdsTitle: 'شاشة المطبخ (KDS)',
    cashierTitle: 'شاشة الكاشير',
    activeOrders: 'الطلبات النشطة',
    startPreparing: 'بدء التحضير',
    markReady: 'جاهز للتقديم',
    markServed: 'تم التقديم',
    settleBill: 'تأكيد الدفع وإغلاق الحساب',
    pendingCalls: 'نداءات الويتر المعلقة',
    acknowledgeCall: 'تمت التلبية',
    soundEnabled: 'التنبيه الصوتي مفعّل',
    logout: 'تسجيل الخروج',

    // Admin
    adminLogin: 'لوحة تحكم الأدمن',
    adminPasswordPlaceholder: 'أدخل كلمة مرور الأدمن',
    menuManagement: 'إدارة المنيو',
    tablesManagement: 'إدارة الطاولات و الـ QR',
    reports: 'التقارير والإحصائيات',
    settings: 'إعدادات المطعم والأمان',
    addItem: 'إضافة صنف جديد',
    addTable: 'إضافة طاولة جديدة',
    generateQr: 'توليد وطباعة QR',
    printQrCard: 'طباعة بطاقة الطاولة',
    salesToday: 'مبيعات اليوم',
    totalRevenue: 'إجمالي المبيعات',
    topSelling: 'الأصناف الأكثر طلباً',
    auditLogs: 'سجل التدقيق الأمني',
    changePassword: 'تغيير كلمات المرور'
  },
  en: {
    // General
    appName: 'Smart Restaurant',
    currency: 'IQD',
    loading: 'Loading...',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    confirm: 'Confirm',
    back: 'Back',
    close: 'Close',
    status: 'Status',
    total: 'Total',
    notes: 'Special Notes',
    actions: 'Actions',
    active: 'Active',
    inactive: 'Inactive',

    // Customer Menu
    table: 'Table',
    scanRequired: 'Please scan table QR code to begin',
    searchPlaceholder: 'Search for your favorite dish...',
    allCategories: 'All',
    viewCart: 'View Cart',
    cartEmpty: 'Your cart is currently empty',
    addToCart: 'Add to Cart',
    sendOrder: 'Send Order to Kitchen',
    orderSent: 'Your order was sent successfully!',
    callWaiter: 'Call Waiter',
    waiterCalled: 'Waiter called! Staff will assist you shortly',
    callWaiterCooldown: 'Please wait before calling again',
    specialNotesHint: 'e.g., No onions, extra sauce...',
    orderStatus: 'Your Order Status',
    billSummary: 'Table Bill Summary',
    unpaidTotal: 'Unpaid Total',
    outOfStock: 'Out of Stock',
    statusNew: 'Received',
    statusPreparing: 'Preparing in Kitchen',
    statusReady: 'Ready to Serve',
    statusServed: 'Served - Enjoy your meal!',
    statusPaid: 'Paid & Settled',
    statusCancelled: 'Cancelled',

    // Staff
    staffLogin: 'Staff Login',
    passwordPlaceholder: 'Enter staff password',
    loginBtn: 'Log In',
    kdsTitle: 'Kitchen Display (KDS)',
    cashierTitle: 'Cashier Overview',
    activeOrders: 'Active Orders',
    startPreparing: 'Start Prep',
    markReady: 'Mark Ready',
    markServed: 'Mark Served',
    settleBill: 'Settle & Close Bill',
    pendingCalls: 'Pending Waiter Calls',
    acknowledgeCall: 'Acknowledge',
    soundEnabled: 'Audio Chime Enabled',
    logout: 'Log Out',

    // Admin
    adminLogin: 'Admin Dashboard',
    adminPasswordPlaceholder: 'Enter admin password',
    menuManagement: 'Menu Management',
    tablesManagement: 'Tables & QR Codes',
    reports: 'Reports & Analytics',
    settings: 'Settings & Security',
    addItem: 'Add New Dish',
    addTable: 'Add New Table',
    generateQr: 'Generate & Print QR',
    printQrCard: 'Print Table Card',
    salesToday: "Today's Sales",
    totalRevenue: 'Total Revenue',
    topSelling: 'Top Selling Dishes',
    auditLogs: 'Security Audit Logs',
    changePassword: 'Change Passwords'
  }
};

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState(() => localStorage.getItem('app_lang') || 'ar');

  useEffect(() => {
    localStorage.setItem('app_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const toggleLanguage = () => {
    setLang(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const t = (key) => {
    return translations[lang]?.[key] || translations['ar']?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLanguage, t, isRtl: lang === 'ar' }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
