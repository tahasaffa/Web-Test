import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/formatCurrency';
import { Plus } from 'lucide-react';

export default function DishCard({ item, onClick, currency = 'IQD' }) {
  const { lang, t } = useLanguage();

  const name = lang === 'ar' ? item.name_ar : (item.name_en || item.name_ar);
  const description = lang === 'ar' ? item.description_ar : (item.description_en || item.description_ar);
  const isAvailable = Boolean(item.is_available);

  return (
    <div
      onClick={() => isAvailable && onClick(item)}
      className={`group relative flex flex-col bg-white rounded-2xl border border-stone-200/90 shadow-xs overflow-hidden transition-all duration-200 ${
        isAvailable
          ? 'cursor-pointer hover:shadow-md hover:border-orange-300 hover:-translate-y-1'
          : 'opacity-65 cursor-not-allowed bg-stone-50'
      }`}
    >
      {/* Large Picture at Top */}
      <div className="relative h-44 sm:h-48 w-full bg-stone-100 overflow-hidden">
        {item.image_url ? (
          <img
            src={item.image_url}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-stone-300 font-black text-2xl">
            {name.charAt(0)}
          </div>
        )}

        {!isAvailable && (
          <div className="absolute inset-0 bg-stone-900/65 backdrop-blur-[2px] flex items-center justify-center p-2 text-center">
            <span className="text-white text-xs font-black tracking-wide leading-tight bg-stone-950/80 px-3 py-1.5 rounded-full border border-stone-700">
              {t('outOfStock')}
            </span>
          </div>
        )}
      </div>

      {/* Dish Details */}
      <div className="p-4 flex flex-col justify-between flex-1 space-y-3">
        <div>
          <h3 className="font-black text-stone-900 text-base leading-snug tracking-tight">
            {name}
          </h3>
          {description && (
            <p className="text-xs text-stone-500 line-clamp-2 mt-1.5 leading-relaxed font-medium">
              {description}
            </p>
          )}
        </div>

        {/* Bottom Bar: Price & Add Button */}
        <div className="flex items-center justify-between pt-2 border-t border-stone-100 mt-auto">
          <div>
            <span className="text-[11px] text-stone-400 font-bold block">السعر</span>
            <span className="font-black text-orange-700 text-base sm:text-lg tracking-tight">
              {formatCurrency(item.price, currency, lang)}
            </span>
          </div>

          {isAvailable && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClick(item);
              }}
              className="w-9 h-9 rounded-full bg-gradient-to-r from-orange-600 to-amber-700 text-white flex items-center justify-center shadow-md shadow-orange-950/20 hover:scale-105 active:scale-95 transition"
              title={t('addToCart')}
            >
              <Plus size={18} strokeWidth={2.5} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
