import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import { useLanguage } from '../context/LanguageContext';
import CustomerHeader from './CustomerHeader';
import CategoryBar from './CategoryBar';
import DishCard from './DishCard';
import DishModal from './DishModal';
import CartDrawer from './CartDrawer';
import OrderStatusTracker from './OrderStatusTracker';
import BillSummaryModal from './BillSummaryModal';
import CallWaiterButton from './CallWaiterButton';
import CustomerFeedbackModal from './CustomerFeedbackModal';
import { AlertCircle, QrCode, MessageSquareHeart, CreditCard, Receipt, Loader2, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function CustomerView() {
  const { tableId: paramTableId } = useParams();
  const [searchParams] = useSearchParams();
  const queryTableId = searchParams.get('table');
  const tableId = paramTableId || queryTableId;

  const { joinTable, socket } = useSocket();
  const { lang, t } = useLanguage();

  const [loading, setLoading] = useState(true);
  const [table, setTable] = useState(null);
  const [tableError, setTableError] = useState(null);
  const [restaurant, setRestaurant] = useState(null);
  const [categories, setCategories] = useState([]);
  const [allItems, setAllItems] = useState([]);

  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Cart & Modals
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedDish, setSelectedDish] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Active Orders & Bill
  const [activeOrders, setActiveOrders] = useState([]);
  const [latestOrder, setLatestOrder] = useState(null);
  const [isBillOpen, setIsBillOpen] = useState(false);
  const [billData, setBillData] = useState(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);

  // Call Waiter for Payment State
  const [isCallingPayment, setIsCallingPayment] = useState(false);
  const [paymentCalled, setPaymentCalled] = useState(false);
  const [paymentCooldown, setPaymentCooldown] = useState(0);

  const activeCurrency = restaurant?.currency || 'IQD';

  useEffect(() => {
    let timer = null;
    if (paymentCooldown > 0) {
      timer = setInterval(() => {
        setPaymentCooldown(prev => prev - 1);
      }, 1000);
    } else {
      setPaymentCalled(false);
    }
    return () => clearInterval(timer);
  }, [paymentCooldown]);

  // 1. Validate Table & Fetch Menu
  useEffect(() => {
    async function loadInitialData() {
      setLoading(true);
      try {
        const menuRes = await fetch('/api/menu');
        const menuData = await menuRes.json();
        if (menuData.success) {
          setCategories(menuData.data.categories);
          setAllItems(menuData.data.allItems);
          setRestaurant(menuData.data.restaurant);
        }

        if (tableId) {
          const tableRes = await fetch(`/api/tables/${tableId}/validate`);
          const tableData = await tableRes.json();
          if (tableData.success) {
            setTable(tableData.data.table);
            joinTable(tableId);
            fetchActiveOrders(tableId);
          } else {
            setTableError(tableData.error || 'الطاولة غير صالحة');
          }
        }
      } catch (err) {
        console.error('Failed to load menu or table data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadInitialData();
  }, [tableId]);

  const fetchActiveOrders = async (tblId) => {
    try {
      const res = await fetch(`/api/orders/table/${tblId}/active`);
      const data = await res.json();
      if (data.success) {
        setActiveOrders(data.data.activeOrders);
        setBillData(data.data);
        if (data.data.activeOrders.length > 0) {
          setLatestOrder(data.data.activeOrders[data.data.activeOrders.length - 1]);
        }
      }
    } catch (e) {
      // Ignore
    }
  };

  useEffect(() => {
    if (!socket || !tableId) return;

    const handleOrderPlaced = () => fetchActiveOrders(tableId);
    const handleStatusUpdate = () => fetchActiveOrders(tableId);
    const handleTableSettled = () => {
      setActiveOrders([]);
      setLatestOrder(null);
      setBillData(null);
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    };

    socket.on('order_placed', handleOrderPlaced);
    socket.on('order_status_updated', handleStatusUpdate);
    socket.on('table_settled', handleTableSettled);

    return () => {
      socket.off('order_placed', handleOrderPlaced);
      socket.off('order_status_updated', handleStatusUpdate);
      socket.off('table_settled', handleTableSettled);
    };
  }, [socket, tableId]);

  // Cart operations
  const handleAddToCart = (itemWithQty) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(
        i => i.menu_item_id === itemWithQty.menu_item_id && (i.notes || '') === (itemWithQty.notes || '')
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += itemWithQty.quantity;
        return updated;
      }
      return [...prev, itemWithQty];
    });
  };

  const handleUpdateQuantity = (index, newQuantity) => {
    if (newQuantity <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCart(prev => {
      const updated = [...prev];
      updated[index].quantity = newQuantity;
      return updated;
    });
  };

  const handleRemoveItem = (index) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  // Submit Order
  const handleSubmitOrder = async () => {
    if (!table) {
      alert('يجب مسح رمز QR الخاص بالطاولة أولاً لإرسال الطلب!');
      return;
    }
    if (cart.length === 0) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          table_id: table.id,
          items: cart.map(c => ({
            menu_item_id: c.menu_item_id,
            quantity: c.quantity,
            notes: c.notes
          }))
        })
      });

      const data = await res.json();
      if (data.success) {
        setCart([]);
        setIsCartOpen(false);
        setLatestOrder(data.data);
        fetchActiveOrders(table.id);
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      } else {
        alert(data.error || 'فشل في إرسال الطلب');
      }
    } catch (e) {
      alert('حدث خطأ في الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filtered dishes
  const filteredItems = useMemo(() => {
    return allItems.filter(item => {
      const matchesCategory = activeCategory === 'all' || item.category_id === activeCategory;
      const itemName = lang === 'ar' ? item.name_ar : (item.name_en || item.name_ar);
      const matchesSearch = !searchQuery.trim() || itemName.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [allItems, activeCategory, searchQuery, lang]);

  const handleCallWaiterForPayment = async () => {
    if (!table || isCallingPayment || paymentCooldown > 0) return;

    setIsCallingPayment(true);
    try {
      const res = await fetch('/api/staff-calls', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          table_id: table.id,
          call_type: 'payment'
        })
      });
      const data = await res.json();
      if (data.success) {
        setPaymentCalled(true);
        setPaymentCooldown(45);
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
      } else if (data.retryAfter) {
        setPaymentCooldown(data.retryAfter);
      } else {
        alert(data.error || 'فشل في إرسال طلب الدفع');
      }
    } catch (e) {
      alert('خطأ في الاتصال بالسيرفر');
    } finally {
      setIsCallingPayment(false);
    }
  };

  if (loading) {
    return (
      <div className="mobile-container flex items-center justify-center min-h-screen bg-[#FAF7F2]">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-full border-4 border-orange-700 border-t-transparent animate-spin mx-auto" />
          <p className="font-black text-stone-700 text-sm">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-container pb-28 bg-[#FAF7F2]">
      {/* Header */}
      <CustomerHeader
        restaurant={restaurant}
        table={table}
        onOpenBill={() => {
          if (table) fetchActiveOrders(table.id);
          setIsBillOpen(true);
        }}
        onOpenFeedback={() => setIsFeedbackOpen(true)}
        activeOrdersCount={activeOrders.length}
      />

      {/* Table Warning Banner */}
      {!table && (
        <div className="m-4 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3 shadow-xs">
          <QrCode className="text-amber-700 flex-shrink-0 mt-0.5" size={20} />
          <div className="text-xs">
            <h4 className="font-black mb-1">
              {tableError || 'أنت تتصفح المنيو بدون تحديد طاولة'}
            </h4>
            <p className="text-amber-800 leading-relaxed font-medium">
              يمكنك تصفح الأصناف بحرية، ولإرسال الطلب مباشرة للمطبخ، يرجى مسح رمز الـ QR الموجود على طاولتك.
            </p>
          </div>
        </div>
      )}

      {/* Category Pills & Search */}
      <CategoryBar
        categories={categories}
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Dishes Grid */}
      <main className="p-4 space-y-4 max-w-lg mx-auto w-full">
        {/* Live Order Tracker Banner */}
        {latestOrder && (
          <OrderStatusTracker
            order={latestOrder}
            onClose={() => setLatestOrder(null)}
            currency={activeCurrency}
            onCallPayment={handleCallWaiterForPayment}
            paymentCalled={paymentCalled}
          />
        )}

        {/* Dishes Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredItems.length === 0 ? (
            <div className="col-span-full py-16 text-center text-stone-400 space-y-2">
              <AlertCircle size={42} className="mx-auto text-stone-300 stroke-1" />
              <p className="font-bold text-sm">لا توجد أطباق مطابقة للبحث</p>
            </div>
          ) : (
            filteredItems.map(item => (
              <DishCard
                key={item.id}
                item={item}
                onClick={setSelectedDish}
                currency={activeCurrency}
              />
            ))
          )}
        </div>

        {/* بعد انتهاء الطعام: كارت طلب ويتر للدفع والحساب */}
        {table && (
          <div className="mt-6 p-5 rounded-3xl bg-gradient-to-br from-[#FFFDF8] via-white to-amber-50/80 border-2 border-amber-300 shadow-sm space-y-3.5 animate-fade">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-orange-600 to-amber-700 text-white flex items-center justify-center font-bold shadow-md shadow-orange-950/20 flex-shrink-0">
                  <CreditCard size={22} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-black text-stone-900 text-sm sm:text-base">
                      انتهيت من طعامك؟ طلب ويتر للدفع
                    </h4>
                    <span className="badge badge-served text-[10px] font-black">
                      طاولة #{table.table_number}
                    </span>
                  </div>
                  <p className="text-xs text-stone-600 font-medium mt-0.5">
                    سيصل الويتر مباشرة إلى طاولتكم ومعه الفاتورة وجهاز الدفع
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleCallWaiterForPayment}
                disabled={isCallingPayment || paymentCooldown > 0}
                className={`btn flex-1 py-3 text-xs font-black flex items-center justify-center gap-2 shadow-sm transition ${
                  paymentCalled
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'btn-primary'
                }`}
              >
                {isCallingPayment ? (
                  <>
                    <Loader2 size={15} className="animate-spin" />
                    <span>جاري إرسال الطلب...</span>
                  </>
                ) : paymentCalled ? (
                  <>
                    <CheckCircle2 size={15} />
                    <span>تم إشعار الويتر، سيصلكم فوراً ومعه الفاتورة</span>
                  </>
                ) : paymentCooldown > 0 ? (
                  <span>تم الطلب (انتظر {paymentCooldown} ث)</span>
                ) : (
                  <>
                    <CreditCard size={16} />
                    <span>طلب ويتر لإحضار الفاتورة والدفع</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  if (table) fetchActiveOrders(table.id);
                  setIsBillOpen(true);
                }}
                className="btn btn-secondary py-3 px-3.5 text-xs font-black flex items-center gap-1.5 flex-shrink-0"
                title="معاينة تفاصيل الفاتورة"
              >
                <Receipt size={15} />
                <span>عرض الحساب</span>
              </button>
            </div>
          </div>
        )}

        {/* Customer Feedback & Complaints Section Card */}
        <div className="mt-6 p-4.5 rounded-2xl bg-white border border-stone-200 shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center font-bold border border-amber-200/80 flex-shrink-0">
              <MessageSquareHeart size={20} />
            </div>
            <div>
              <h4 className="font-black text-stone-900 text-xs sm:text-sm">لديك ملاحظة أو تقييم أو شكوى؟</h4>
              <p className="text-[11px] text-stone-500 font-medium">رأيك يصل مباشرة لمدير الصالة لخدمتك فوراً</p>
            </div>
          </div>

          <button
            onClick={() => setIsFeedbackOpen(true)}
            className="btn btn-secondary py-2 px-3.5 text-xs font-black flex-shrink-0"
          >
            شاركنا رأيك
          </button>
        </div>
      </main>

      {/* Call Waiter Floating Button */}
      {table && <CallWaiterButton tableId={table.id} />}

      {/* Customer Feedback Modal */}
      <CustomerFeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        table={table}
      />

      {/* Dish Customization Modal */}
      {selectedDish && (
        <DishModal
          item={selectedDish}
          onClose={() => setSelectedDish(null)}
          onAddToCart={handleAddToCart}
          currency={activeCurrency}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        cart={cart}
        isOpen={isCartOpen}
        onOpen={() => setIsCartOpen(true)}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onSubmitOrder={handleSubmitOrder}
        isSubmitting={isSubmitting}
        currency={activeCurrency}
      />

      {/* Table Bill Summary Modal */}
      <BillSummaryModal
        isOpen={isBillOpen}
        onClose={() => setIsBillOpen(false)}
        billData={billData}
        currency={activeCurrency}
      />
    </div>
  );
}
