import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import {
  MessageSquareHeart, Star, Utensils, Bell, X, Send,
  CheckCircle2, Sparkles, MessageCircle, AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function CustomerFeedbackModal({ isOpen, onClose, table }) {
  const { lang, t } = useLanguage();

  // 1. Order & Food Rating
  const [orderRating, setOrderRating] = useState(5);
  const [hoverOrderRating, setHoverOrderRating] = useState(0);

  // 2. Service Rating
  const [serviceRating, setServiceRating] = useState(5);
  const [hoverServiceRating, setHoverServiceRating] = useState(0);

  // 3. Quick Tags
  const [selectedTags, setSelectedTags] = useState([]);

  // 4. Message & Name
  const [customerName, setCustomerName] = useState('');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const foodTags = [
    'الأكل ساخن وطازج',
    'طعم خيالي ومميز',
    'تقديم ونظافة راقية',
    'الأكل كان بارداً',
    'صنف غير مطابق للطلب'
  ];

  const serviceTags = [
    'الويتر سريع وبشوش',
    'استقبال وضيافة محترمة',
    'خدمة بطيئة وتأخير',
    'نظافة الطاولة والجلسة'
  ];

  const toggleTag = (tag) => {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/customer/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          table_id: table?.id || null,
          table_number: table?.table_number || null,
          customer_name: customerName.trim() || undefined,
          order_rating: orderRating,
          service_rating: serviceRating,
          quick_tags: selectedTags,
          message: message.trim()
        })
      });

      const data = await res.json();
      if (data.success) {
        setIsSuccess(true);
        confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
        setTimeout(() => {
          setIsSuccess(false);
          onClose();
        }, 2800);
      } else {
        alert(data.error || 'فشل في إرسال التقييم');
      }
    } catch (e) {
      alert('تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRatingLabel = (val) => {
    if (val === 5) return 'ممتاز جداً 🌟';
    if (val === 4) return 'جيد جداً 👍';
    if (val === 3) return 'مقبول 😐';
    if (val === 2) return 'أقل من المتوقع ⚠️';
    return 'غير راضٍ ❌';
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl animate-fade flex flex-col max-h-[90vh] border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4.5 border-b border-stone-100 flex items-center justify-between bg-[#FAF7F2]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-600 to-amber-700 text-white flex items-center justify-center shadow-sm">
              <MessageSquareHeart size={20} />
            </div>
            <div>
              <h3 className="font-black text-stone-900 text-base leading-tight">
                تقييم الطلب والخدمة
              </h3>
              <span className="text-xs text-stone-500 font-bold">
                {table ? `طاولة رقم #${table.table_number}` : 'ملاحظات الزبائن'}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center font-bold transition"
          >
            <X size={17} />
          </button>
        </div>

        {/* Modal Body */}
        {isSuccess ? (
          <div className="p-10 text-center space-y-4 my-auto animate-fade">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 size={36} />
            </div>
            <h4 className="font-black text-stone-900 text-lg">شكراً جزيلاً لتقييمك!</h4>
            <p className="text-xs text-stone-600 leading-relaxed font-medium">
              تم إرسال تقييم الطلب والخدمة ورسالتك مباشرة إلى إدارة المطعم. نقدّر ملاحظاتك ونسعى دائماً لنيل رضاك.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
            {/* 1. تقييم الطلب والأكل */}
            <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-stone-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-black text-stone-900 text-xs sm:text-sm">
                  <Utensils size={16} className="text-orange-700" />
                  <span>1. تقييم الطلب وجودة الأكل</span>
                </div>
                <span className="text-xs font-black text-orange-800">
                  {getRatingLabel(hoverOrderRating || orderRating)}
                </span>
              </div>

              {/* Stars */}
              <div className="flex items-center justify-center gap-2.5 py-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setHoverOrderRating(star)}
                    onMouseLeave={() => setHoverOrderRating(0)}
                    onClick={() => setOrderRating(star)}
                    className="p-1 hover:scale-115 active:scale-95 transition"
                  >
                    <Star
                      size={28}
                      className={`transition-colors ${
                        (hoverOrderRating || orderRating) >= star
                          ? 'text-amber-500 fill-amber-500'
                          : 'text-stone-300'
                      }`}
                    />
                  </button>
                ))}
              </div>

              {/* Quick Food Badges */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {foodTags.map((tag, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition ${
                      selectedTags.includes(tag)
                        ? 'bg-orange-800 text-white shadow-xs'
                        : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. تقييم الخدمة وطاقم العمل */}
            <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-stone-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-black text-stone-900 text-xs sm:text-sm">
                  <Bell size={16} className="text-amber-700" />
                  <span>2. تقييم الخدمة وسرعة الويتر</span>
                </div>
                <span className="text-xs font-black text-amber-800">
                  {getRatingLabel(hoverServiceRating || serviceRating)}
                </span>
              </div>

              {/* Stars */}
              <div className="flex items-center justify-center gap-2.5 py-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setHoverServiceRating(star)}
                    onMouseLeave={() => setHoverServiceRating(0)}
                    onClick={() => setServiceRating(star)}
                    className="p-1 hover:scale-115 active:scale-95 transition"
                  >
                    <Star
                      size={28}
                      className={`transition-colors ${
                        (hoverServiceRating || serviceRating) >= star
                          ? 'text-amber-500 fill-amber-500'
                          : 'text-stone-300'
                      }`}
                    />
                  </button>
                ))}
              </div>

              {/* Quick Service Badges */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {serviceTags.map((tag, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition ${
                      selectedTags.includes(tag)
                        ? 'bg-amber-800 text-white shadow-xs'
                        : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. كتابة رسالة أو ملاحظات */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 font-black text-stone-900 text-xs sm:text-sm">
                <MessageCircle size={16} className="text-stone-700" />
                <span>3. رسالتك وملاحظاتك للإدارة</span>
              </div>

              <div>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="اسمك الكريم (اختياري)"
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-2.5 text-xs outline-none font-bold focus:border-orange-600 focus:bg-white mb-2"
                />

                <textarea
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="اكتب هنا أي تفاصيل أو ملاحظة إضافية عن تجربتك، اقتراح لتحسين المنيو، أو كلمة شكر..."
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs outline-none resize-none font-medium focus:border-orange-600 focus:bg-white"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full btn btn-primary py-3.5 text-xs font-black shadow-md flex items-center justify-center gap-2"
            >
              <Send size={15} />
              <span>{isSubmitting ? 'جاري إرسال التقييم...' : 'إرسال التقييم والرسالة'}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
