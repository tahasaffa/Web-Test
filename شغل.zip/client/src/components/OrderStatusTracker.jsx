import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useSocket } from '../context/SocketContext';
import { formatCurrency } from '../utils/formatCurrency';
import { CheckCircle2, Clock, ChefHat, Sparkles, X, ChevronDown, ChevronUp, CreditCard } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function OrderStatusTracker({ order, onClose, currency = 'IQD', onCallPayment, paymentCalled }) {
  const { lang, t } = useLanguage();
  const { socket, isConnected } = useSocket();
  const [currentOrder, setCurrentOrder] = useState(order);
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    setCurrentOrder(order);
  }, [order]);

  useEffect(() => {
    if (!socket || !currentOrder?.id) return;

    const handleStatusUpdate = (updatedOrder) => {
      if (updatedOrder.id === currentOrder.id) {
        setCurrentOrder(prev => ({
          ...prev,
          ...updatedOrder
        }));

        if (updatedOrder.status === 'ready' || updatedOrder.status === 'served') {
          confetti({
            particleCount: 60,
            spread: 50,
            origin: { y: 0.7 }
          });
        }
      }
    };

    socket.on('order_status_updated', handleStatusUpdate);

    return () => {
      socket.off('order_status_updated', handleStatusUpdate);
    };
  }, [socket, currentOrder?.id]);

  useEffect(() => {
    if (!currentOrder?.id) return;

    const fetchLatestStatus = async () => {
      try {
        const res = await fetch(`/api/orders/${currentOrder.id}/status`);
        const data = await res.json();
        if (data.success && data.data) {
          setCurrentOrder(data.data);
        }
      } catch (e) {
        // Silent error
      }
    };

    const interval = setInterval(() => {
      if (!isConnected) {
        fetchLatestStatus();
      }
    }, 15000);

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        fetchLatestStatus();
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [currentOrder?.id, isConnected]);

  if (!currentOrder) return null;

  const steps = [
    { key: 'new', label: t('statusNew'), icon: Clock },
    { key: 'preparing', label: t('statusPreparing'), icon: ChefHat },
    { key: 'ready', label: t('statusReady'), icon: Sparkles },
    { key: 'served', label: t('statusServed'), icon: CheckCircle2 }
  ];

  const statusOrder = ['new', 'preparing', 'ready', 'served', 'paid'];
  const currentIndex = statusOrder.indexOf(currentOrder.status);

  return (
    <div className="card p-4.5 border border-amber-300/80 bg-gradient-to-b from-[#FFFDF9] to-white shadow-sm mb-4 animate-fade">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-3 h-3 rounded-full bg-orange-700 animate-ping" />
          <h3 className="font-black text-stone-900 text-sm">
            {t('orderStatus')} (#{currentOrder.id.substring(0, 6)})
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-stone-400 hover:text-stone-600 p-1"
          >
            {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </button>
          {onClose && (
            <button onClick={onClose} className="text-stone-400 hover:text-stone-600 p-1">
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Stepper Progress Bar */}
      <div className="mt-4 pt-2">
        <div className="relative flex items-center justify-between">
          <div className="absolute top-1/2 left-4 right-4 -translate-y-1/2 h-1 bg-stone-200 z-0">
            <div
              className="h-full bg-orange-700 transition-all duration-500"
              style={{
                width: `${Math.min(100, Math.max(0, (currentIndex / 3) * 100))}%`
              }}
            />
          </div>

          {steps.map((step, idx) => {
            const Icon = step.icon;
            const isCompleted = currentIndex >= idx;
            const isCurrent = currentOrder.status === step.key;

            return (
              <div key={step.key} className="relative z-10 flex flex-col items-center">
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                    isCurrent
                      ? 'bg-orange-700 text-white ring-4 ring-orange-200 scale-110 shadow-md'
                      : isCompleted
                      ? 'bg-orange-700 text-white'
                      : 'bg-stone-200 text-stone-400'
                  }`}
                >
                  <Icon size={16} />
                </div>
                <span
                  className={`text-[10px] font-bold mt-1.5 text-center whitespace-nowrap ${
                    isCurrent
                      ? 'text-orange-800 font-black'
                      : isCompleted
                      ? 'text-stone-800'
                      : 'text-stone-400'
                  }`}
                >
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Expanded Order Items Detail */}
      {isExpanded && currentOrder.items && (
        <div className="mt-4 pt-3 border-t border-stone-100 text-xs space-y-2">
          <div className="font-bold text-stone-700 mb-1">الأصناف المطلوبة:</div>
          {currentOrder.items.map((item, i) => {
            const name = lang === 'ar' ? item.name_ar : (item.name_en || item.name_ar);
            return (
              <div key={i} className="flex justify-between text-stone-600">
                <span>
                  {item.quantity}x {name} {item.notes && <span className="text-stone-400 font-medium">({item.notes})</span>}
                </span>
                <span className="font-bold text-stone-800">
                  {formatCurrency(item.price_at_order * item.quantity, currency, lang)}
                </span>
              </div>
            );
          })}
          <div className="flex justify-between pt-2 border-t border-stone-100 font-black text-stone-900 text-sm">
            <span>{t('total')}</span>
            <span className="text-orange-800">
              {formatCurrency(currentOrder.total_amount, currency, lang)}
            </span>
          </div>
        </div>
      )}

      {/* بعد انتهاء الطعام: زر طلب ويتر للدفع عند تقديم الوجبة */}
      {currentOrder.status === 'served' && onCallPayment && (
        <div className="mt-4 p-3.5 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-300 text-stone-900 flex items-center justify-between gap-2 shadow-xs">
          <div>
            <div className="font-black text-xs text-amber-900 flex items-center gap-1.5">
              <span>🍽️ بالعافية وصحة وهنا!</span>
            </div>
            <div className="text-[11px] text-stone-600 font-medium mt-0.5">
              انتهيت من وجبتك؟ اطلب الويتر لإحضار الفاتورة والدفع
            </div>
          </div>

          <button
            onClick={onCallPayment}
            className={`btn py-2 px-3 text-xs font-black flex items-center gap-1.5 flex-shrink-0 shadow-xs ${
              paymentCalled ? 'bg-emerald-600 text-white' : 'btn-primary'
            }`}
          >
            <CreditCard size={14} />
            <span>{paymentCalled ? 'تم طلب الويتر' : 'طلب ويتر للدفع'}</span>
          </button>
        </div>
      )}
    </div>
  );
}
