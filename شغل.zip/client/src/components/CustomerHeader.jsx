import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useSocket } from '../context/SocketContext';
import { Globe, Receipt, Utensils, Wifi, WifiOff, MessageSquareHeart } from 'lucide-react';

export default function CustomerHeader({ restaurant, table, onOpenBill, onOpenFeedback, activeOrdersCount }) {
  const { lang, toggleLanguage, t } = useLanguage();
  const { isConnected } = useSocket();

  const displayName = lang === 'ar' ? restaurant?.name_ar : (restaurant?.name_en || restaurant?.name_ar);

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-stone-200/90 px-4 py-3 shadow-xs">
      <div className="flex items-center justify-between max-w-lg mx-auto">
        {/* Left: Branding & Table */}
        <div className="flex items-center gap-3">
          {restaurant?.logo_url ? (
            <img
              src={restaurant.logo_url}
              alt={displayName || 'Logo'}
              className="w-11 h-11 rounded-2xl object-cover shadow-md shadow-orange-950/10 border border-stone-200 flex-shrink-0 bg-white"
            />
          ) : (
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-orange-700 to-amber-700 text-white flex items-center justify-center shadow-md shadow-orange-950/15 border border-orange-600/30 flex-shrink-0">
              <Utensils size={20} strokeWidth={2.2} />
            </div>
          )}
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-black text-stone-900 text-base leading-tight tracking-tight">
                {displayName || t('appName')}
              </h1>
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              {table ? (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-100/90 text-amber-900 border border-amber-300/80">
                  {t('table')} #{table.table_number}
                </span>
              ) : (
                <span className="text-xs text-stone-500 font-bold">{t('scanRequired')}</span>
              )}

              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-stone-400">
                {isConnected ? (
                  <span className="flex items-center gap-1 text-emerald-700">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <Wifi size={12} />
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-amber-700">
                    <WifiOff size={12} />
                  </span>
                )}
              </span>
            </div>
          </div>
        </div>

        {/* Right Actions: Feedback, Bill & Language Toggle */}
        <div className="flex items-center gap-2">
          {/* Customer Feedback / Complaint Button */}
          <button
            onClick={onOpenFeedback}
            className="p-2.5 rounded-xl bg-white hover:bg-stone-100 text-orange-800 border border-stone-200 shadow-xs active:scale-95 transition"
            title="رأيك وملاحظاتك أو تقديم شكوى"
          >
            <MessageSquareHeart size={18} />
          </button>

          {table && (
            <button
              onClick={onOpenBill}
              className="relative p-2.5 rounded-xl bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 shadow-xs active:scale-95 transition"
              title={t('billSummary')}
            >
              <Receipt size={18} />
              {activeOrdersCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-orange-700 text-white text-[10px] font-black flex items-center justify-center shadow-xs">
                  {activeOrdersCount}
                </span>
              )}
            </button>
          )}

          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-stone-100 text-stone-800 border border-stone-200 font-bold text-xs shadow-xs active:scale-95 transition"
          >
            <Globe size={14} className="text-orange-700" />
            <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
