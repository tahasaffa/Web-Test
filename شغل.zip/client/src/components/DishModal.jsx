import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/formatCurrency';
import { X, Plus, Minus, ShoppingBag } from 'lucide-react';

export default function DishModal({ item, onClose, onAddToCart, currency = 'IQD' }) {
  const { lang, t } = useLanguage();
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');

  if (!item) return null;

  const name = lang === 'ar' ? item.name_ar : (item.name_en || item.name_ar);
  const description = lang === 'ar' ? item.description_ar : (item.description_en || item.description_ar);
  const totalItemPrice = Number(item.price) * quantity;

  const handleAdd = () => {
    onAddToCart({
      menu_item_id: item.id,
      name_ar: item.name_ar,
      name_en: item.name_en,
      price: item.price,
      image_url: item.image_url,
      quantity,
      notes: notes.trim()
    });
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl animate-fade max-h-[90vh] flex flex-col border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Image Header */}
        <div className="relative h-52 sm:h-60 bg-stone-100 flex-shrink-0">
          {item.image_url ? (
            <img src={item.image_url} alt={name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-stone-300 font-black text-3xl">
              {name.charAt(0)}
            </div>
          )}
          <button
            onClick={onClose}
            className="absolute top-3 rtl:left-3 ltr:right-3 w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center backdrop-blur-md hover:bg-black/80 transition"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          <div>
            <div className="flex items-start justify-between gap-3">
              <h2 className="text-lg sm:text-xl font-black text-stone-900 leading-snug">{name}</h2>
              <span className="text-base sm:text-lg font-black text-orange-700 whitespace-nowrap">
                {formatCurrency(item.price, currency, lang)}
              </span>
            </div>
            {description && (
              <p className="text-xs sm:text-sm text-stone-500 mt-1.5 leading-relaxed font-medium">
                {description}
              </p>
            )}
          </div>

          {/* Notes Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-700 flex items-center justify-between">
              <span>{t('notes')}</span>
              <span className="text-[11px] text-stone-400 font-normal">اختياري</span>
            </label>
            <textarea
              rows={2}
              maxLength={200}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={t('specialNotesHint')}
              className="w-full text-xs sm:text-sm rounded-xl border border-stone-200 p-3 outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-600/10 transition resize-none bg-stone-50 focus:bg-white"
            />
          </div>

          {/* Quantity Controls */}
          <div className="flex items-center justify-between pt-3 border-t border-stone-100">
            <span className="text-xs font-bold text-stone-700">الكمية المطلوبة</span>
            <div className="flex items-center gap-3 bg-stone-100 px-3.5 py-2 rounded-full border border-stone-200">
              <button
                type="button"
                onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                className="w-7 h-7 rounded-full bg-white text-stone-700 flex items-center justify-center shadow-xs disabled:opacity-40"
                disabled={quantity <= 1}
              >
                <Minus size={14} />
              </button>
              <span className="font-black text-sm min-w-[20px] text-center text-stone-900">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(prev => prev + 1)}
                className="w-7 h-7 rounded-full bg-white text-stone-700 flex items-center justify-center shadow-xs"
              >
                <Plus size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer Button */}
        <div className="p-4 border-t border-stone-100 bg-[#FAF7F2]">
          <button
            onClick={handleAdd}
            className="w-full btn btn-primary py-3.5 text-sm flex items-center justify-between shadow-md shadow-orange-950/20"
          >
            <div className="flex items-center gap-2">
              <ShoppingBag size={18} />
              <span>{t('addToCart')}</span>
            </div>
            <span className="font-black text-base">
              {formatCurrency(totalItemPrice, currency, lang)}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
