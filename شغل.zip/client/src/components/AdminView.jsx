import React, { useState, useEffect } from 'react';
import { useSocket } from '../context/SocketContext';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/formatCurrency';
import {
  TrendingUp, Utensils, QrCode, Users, MessageSquareWarning, Settings,
  LogOut, Plus, Edit2, Trash2, Printer, Download, Eye, EyeOff, ShieldCheck,
  Globe, Upload, Lock, ChevronRight, BarChart3, ArrowUpRight, DollarSign,
  ShoppingBag, CheckCircle2, Clock, RefreshCw, Activity, Layers, Flame,
  Store, Camera, Image as ImageIcon
} from 'lucide-react';

export default function AdminView() {
  const { lang, toggleLanguage, t } = useLanguage();

  const { socket, joinStaff } = useSocket();
  const [token, setToken] = useState(() => localStorage.getItem('admin_token') || '');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Active Tab: 'reports' | 'menu' | 'tables' | 'staff' | 'incidents' | 'settings'
  const [activeTab, setActiveTab] = useState('reports');

  // Restaurant Profile & Identity State
  const [restaurantForm, setRestaurantForm] = useState({
    restaurant_name_ar: '',
    restaurant_name_en: '',
    logo_url: '',
    currency: 'IQD'
  });
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [settingsSavedMessage, setSettingsSavedMessage] = useState('');

  // Data States
  const [menuItems, setMenuItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [tables, setTables] = useState([]);
  const [salesReport, setSalesReport] = useState(null);
  const [advancedReports, setAdvancedReports] = useState(null);
  const [isRefreshingReports, setIsRefreshingReports] = useState(false);
  const [topItems, setTopItems] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [restaurantSettings, setRestaurantSettings] = useState({});
  const [staffMembers, setStaffMembers] = useState([]);
  const [incidents, setIncidents] = useState([]);

  // Dish Modal State
  const [isDishModalOpen, setIsDishModalOpen] = useState(false);
  const [editingDish, setEditingDish] = useState(null);
  const [dishFormData, setDishFormData] = useState({
    name_ar: '', name_en: '', category_id: '', description_ar: '', description_en: '',
    price: '', image_url: '', is_available: 1
  });
  const [uploadingImage, setUploadingImage] = useState(false);

  // Staff Modal State
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState(null);
  const [staffFormData, setStaffFormData] = useState({
    name: '', role: 'ويتر صالة (Waiter)', phone: '', shift: 'صباحي'
  });

  // QR Print Modal
  const [printingTable, setPrintingTable] = useState(null);

  // Password change state
  const [pwTarget, setPwTarget] = useState('admin');
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [pwMessage, setPwMessage] = useState('');

  const currentCurrency = restaurantSettings.currency || 'IQD';

  useEffect(() => {
    if (token) {
      joinStaff(token);
      loadAllAdminData();
    }
  }, [token]);

  // Real-Time Socket Connection: Updates Admin Reports & Incidents instantly on live order events
  useEffect(() => {
    if (!socket || !token) return;

    const handleRealtimeUpdate = () => {
      loadAdvancedReportsOnly();
    };

    const handleIncidentUpdate = (inc) => {
      setIncidents(prev => [inc, ...prev.filter(i => i.id !== inc.id)]);
    };

    socket.on('new_order', handleRealtimeUpdate);
    socket.on('order_status_updated', handleRealtimeUpdate);
    socket.on('table_settled', handleRealtimeUpdate);
    socket.on('new_incident', handleIncidentUpdate);

    return () => {
      socket.off('new_order', handleRealtimeUpdate);
      socket.off('order_status_updated', handleRealtimeUpdate);
      socket.off('table_settled', handleRealtimeUpdate);
      socket.off('new_incident', handleIncidentUpdate);
    };
  }, [socket, token]);

  const loadAdvancedReportsOnly = async () => {
    if (!token) return;
    try {
      setIsRefreshingReports(true);
      const res = await fetch('/api/admin/reports/advanced', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setAdvancedReports(data.data);
      }
    } catch (e) {
      // Ignore
    } finally {
      setIsRefreshingReports(false);
    }
  };

  const loadAllAdminData = async () => {
    try {
      const headers = { 'Authorization': `Bearer ${token}` };
      const [menuRes, catRes, tablesRes, salesRes, advRes, topRes, setRes, auditRes, staffRes, incRes] = await Promise.all([
        fetch('/api/admin/menu-items', { headers }),
        fetch('/api/admin/categories', { headers }),
        fetch('/api/admin/tables', { headers }),
        fetch('/api/admin/reports/sales', { headers }),
        fetch('/api/admin/reports/advanced', { headers }),
        fetch('/api/admin/reports/top-items', { headers }),
        fetch('/api/admin/settings', { headers }),
        fetch('/api/admin/audit-logs', { headers }),
        fetch('/api/admin/staff-members', { headers }),
        fetch('/api/admin/incidents', { headers })
      ]);

      if (menuRes.status === 401 || menuRes.status === 403) {
        handleLogout();
        return;
      }

      const [menuData, catData, tablesData, salesData, advData, topData, setData, auditData, staffData, incData] = await Promise.all([
        menuRes.json(), catRes.json(), tablesRes.json(), salesRes.json(),
        advRes.json(), topRes.json(), setRes.json(), auditRes.json(), staffRes.json(), incRes.json()
      ]);

      if (menuData.success) setMenuItems(menuData.data);
      if (catData.success) setCategories(catData.data);
      if (tablesData.success) setTables(tablesData.data);
      if (salesData.success) setSalesReport(salesData.data);
      if (advData.success) setAdvancedReports(advData.data);
      if (setData.success) {
        setRestaurantSettings(setData.data);
        setRestaurantForm({
          restaurant_name_ar: setData.data.restaurant_name_ar || 'مطعم اللذة الذكية',
          restaurant_name_en: setData.data.restaurant_name_en || 'Smart Gourmet Restaurant',
          logo_url: setData.data.logo_url || '',
          currency: setData.data.currency || 'IQD'
        });
      }
      if (auditData.success) setAuditLogs(auditData.data);
      if (staffData.success) setStaffMembers(staffData.data);
      if (incData.success) setIncidents(incData.data);
    } catch (e) {
      console.error('Failed loading admin data:', e);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!password) return;
    setIsLoggingIn(true);
    setLoginError('');
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (data.success) {
        localStorage.setItem('admin_token', data.token);
        setToken(data.token);
        setPassword('');
      } else {
        setLoginError(data.error || 'كلمة المرور غير صحيحة');
      }
    } catch (err) {
      setLoginError('تعذر الاتصال بالخادم');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    setToken('');
  };

  // Dish Operations
  const handleSaveDish = async (e) => {
    e.preventDefault();
    const url = editingDish ? `/api/admin/menu-items/${editingDish.id}` : '/api/admin/menu-items';
    const method = editingDish ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify(dishFormData)
      });
      const data = await res.json();
      if (data.success) {
        setIsDishModalOpen(false);
        setEditingDish(null);
        loadAllAdminData();
      } else {
        alert(data.error);
      }
    } catch (err) {
      alert('خطأ في حفظ الصنف');
    }
  };

  const handleToggleAvailability = async (id) => {
    try {
      const res = await fetch(`/api/admin/menu-items/${id}/availability`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setMenuItems(prev =>
          prev.map(item => (item.id === id ? { ...item, is_available: data.data.is_available } : item))
        );
      }
    } catch (e) {
      alert('فشل تعديل حالة التوفر');
    }
  };

  const handleDeleteDish = async (id, name) => {
    if (!confirm(`هل أنت متأكد من حذف صنف "${name}"؟`)) return;
    try {
      const res = await fetch(`/api/admin/menu-items/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      alert(data.message);
      loadAllAdminData();
    } catch (e) {
      alert('فشل في حذف الصنف');
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('image', file);
    setUploadingImage(true);
    try {
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        setDishFormData(prev => ({ ...prev, image_url: data.data.url }));
      } else {
        alert(data.error || 'فشل رفع الصورة');
      }
    } catch (err) {
      alert('خطأ أثناء رفع الصورة');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('image', file);
    setUploadingLogo(true);
    try {
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        setRestaurantForm(prev => ({ ...prev, logo_url: data.data.url }));
      } else {
        alert(data.error || 'فشل رفع صورة الشعار');
      }
    } catch (err) {
      alert('خطأ أثناء رفع صورة الشعار');
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSaveRestaurantBranding = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(restaurantForm)
      });
      const data = await res.json();
      if (data.success) {
        setRestaurantSettings(prev => ({ ...prev, ...restaurantForm }));
        setSettingsSavedMessage('تم حفظ اسم وشعار المطعم بنجاح ✅');
        setTimeout(() => setSettingsSavedMessage(''), 4000);
      } else {
        alert(data.error || 'فشل في حفظ البيانات');
      }
    } catch (err) {
      alert('خطأ أثناء الاتصال بالخادم');
    }
  };

  // Staff Operations
  const handleSaveStaff = async (e) => {
    e.preventDefault();
    const url = editingStaff ? `/api/admin/staff-members/${editingStaff.id}` : '/api/admin/staff-members';
    const method = editingStaff ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify(staffFormData)
      });
      const data = await res.json();
      if (data.success) {
        setIsStaffModalOpen(false);
        setEditingStaff(null);
        setStaffFormData({ name: '', role: 'ويتر صالة (Waiter)', phone: '', shift: 'صباحي' });
        loadAllAdminData();
      } else {
        alert(data.error);
      }
    } catch (e) {
      alert('فشل حفظ بيانات الموظف');
    }
  };

  const handleToggleStaff = async (id) => {
    try {
      const res = await fetch(`/api/admin/staff-members/${id}/toggle`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setStaffMembers(prev => prev.map(m => (m.id === id ? { ...m, is_active: data.data.is_active } : m)));
      }
    } catch (e) {
      alert('فشل تعديل حالة الموظف');
    }
  };

  const handleDeleteStaff = async (id, name) => {
    if (!confirm(`هل أنت متأكد من حذف الموظف "${name}" من السجل؟`)) return;
    try {
      const res = await fetch(`/api/admin/staff-members/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) loadAllAdminData();
    } catch (e) {
      alert('فشل حذف الموظف');
    }
  };

  // Incident Operations
  const handleUpdateIncident = async (id, status) => {
    try {
      const res = await fetch(`/api/admin/incidents/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ status })
      });
      const data = await res.json();
      if (data.success) {
        setIncidents(prev => prev.map(i => (i.id === id ? { ...i, status } : i)));
      }
    } catch (e) {
      alert('فشل تحديث حالة البلاغ');
    }
  };

  const handleDeleteIncident = async (id) => {
    if (!confirm('هل أنت متأكد من مسح هذا البلاغ؟')) return;
    try {
      const res = await fetch(`/api/admin/incidents/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setIncidents(prev => prev.filter(i => i.id !== id));
      }
    } catch (e) {
      alert('فشل مسح البلاغ');
    }
  };

  // Table Operations
  const handleAddTable = async () => {
    try {
      const res = await fetch('/api/admin/tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({})
      });
      const data = await res.json();
      if (data.success) loadAllAdminData();
      else alert(data.error);
    } catch (e) {
      alert('فشل إضافة طاولة');
    }
  };

  const handleToggleTable = async (id) => {
    try {
      const res = await fetch(`/api/admin/tables/${id}/toggle`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setTables(prev => prev.map(t => (t.id === id ? { ...t, is_active: data.data.is_active } : t)));
      }
    } catch (e) {
      alert('فشل تعديل حالة الطاولة');
    }
  };

  const handleDeleteTable = async (id, number) => {
    if (!confirm(`هل أنت متأكد من حذف طاولة رقم #${number}؟`)) return;
    try {
      const res = await fetch(`/api/admin/tables/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) loadAllAdminData();
      else alert(data.error);
    } catch (e) {
      alert('فشل حذف الطاولة');
    }
  };

  // Password Change
  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPwMessage('');
    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ targetRole: pwTarget, currentPassword: currentPw, newPassword: newPw })
      });
      const data = await res.json();
      if (data.success) {
        setPwMessage('✓ ' + data.message);
        setCurrentPw('');
        setNewPw('');
      } else {
        setPwMessage('❌ ' + data.error);
      }
    } catch (err) {
      setPwMessage('❌ خطأ في الاتصال بالخادم');
    }
  };

  // 1. Password-only Login Screen (CONFIDENTIAL - ZERO DEFAULT PASSWORDS ON SCREEN)
  if (!token) {
    return (
      <div className="min-h-screen bg-[#141210] flex items-center justify-center p-4">
        <div className="card w-full max-w-sm p-8 bg-[#201D1A] border-[#38332E] text-white animate-fade shadow-2xl">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-700 to-orange-800 text-white flex items-center justify-center mx-auto mb-4 shadow-xl shadow-black/60 border border-amber-600/40">
            <Lock size={28} />
          </div>
          <h2 className="text-xl font-black text-center mb-1 tracking-tight">لوحة تحكم الإدارة | Admin</h2>
          <p className="text-xs text-[#A8A29E] text-center mb-6 font-medium">
            يرجى إدخال كلمة مرور المشرف العام للمتابعة
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && (
              <div className="p-3 rounded-xl bg-red-950/70 border border-red-800 text-red-300 text-xs font-bold text-center">
                {loginError}
              </div>
            )}

            <div>
              <input
                type="password"
                required
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="كلمة مرور المشرف"
                className="w-full bg-[#141210] text-white placeholder:text-[#78716C] rounded-xl px-4 py-3.5 border border-[#38332E] focus:border-amber-500 outline-none text-sm transition"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full btn btn-primary py-3.5 text-sm font-black shadow-md shadow-orange-950/50"
            >
              {isLoggingIn ? 'جاري التحقق...' : 'تسجيل الدخول'}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-[#38332E] flex justify-end items-center text-xs text-[#A8A29E]">
            <button onClick={toggleLanguage} className="hover:text-white flex items-center gap-1.5 font-bold">
              <Globe size={14} />
              <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const navItems = [
    { id: 'reports', label: 'التقارير والمبيعات', icon: TrendingUp },
    { id: 'menu', label: 'إدارة المنيو والأصناف', icon: Utensils },
    { id: 'tables', label: 'الطاولات ورموز QR', icon: QrCode },
    { id: 'staff', label: 'سجل وأسماء الموظفين', icon: Users, badge: staffMembers.length },
    { id: 'incidents', label: 'متابعة المشاكل والبلاغات', icon: MessageSquareWarning, badge: incidents.filter(i => i.status === 'open').length },
    { id: 'settings', label: 'الإعدادات العامة والأمان', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#FAF7F2] flex flex-col md:flex-row">
      {/* SIDEBAR (Desktop Fixed & Mobile Responsive) */}
      <aside className="w-full md:w-64 bg-[#1C1917] text-white flex-shrink-0 flex flex-col justify-between border-b md:border-b-0 md:border-l md:border-stone-800 shadow-xl z-30">
        <div>
          {/* Logo Branding */}
          <div className="p-5 border-b border-stone-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {restaurantSettings?.logo_url ? (
                <img
                  src={restaurantSettings.logo_url}
                  alt="Logo"
                  className="w-10 h-10 rounded-2xl object-cover shadow-md shadow-orange-950/30 border border-stone-700 bg-white"
                />
              ) : (
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center font-bold shadow-md shadow-orange-950/30">
                  <ShieldCheck size={22} />
                </div>
              )}
              <div>
                <h1 className="font-black text-sm leading-tight tracking-tight">لوحة الإدارة العامة</h1>
                <span className="text-[11px] text-stone-400 font-medium truncate block max-w-[140px]">
                  {restaurantSettings.restaurant_name_ar || 'مطعم اللذة الذكية'}
                </span>
              </div>
            </div>
          </div>

          {/* Nav List */}
          <nav className="p-3 space-y-1.5">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-black transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-orange-600 to-amber-700 text-white shadow-md shadow-orange-950/40'
                      : 'text-stone-300 hover:bg-stone-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon size={17} className={isActive ? 'text-white' : 'text-stone-400'} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                      isActive ? 'bg-white text-orange-800' : 'bg-orange-700 text-white'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar Controls */}
        <div className="p-3 border-t border-stone-800 flex items-center justify-between text-xs">
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-stone-300 hover:bg-stone-800 transition font-bold"
          >
            <Globe size={15} />
            <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-stone-400 hover:bg-red-950/50 hover:text-red-300 transition font-bold"
            title="تسجيل الخروج"
          >
            <LogOut size={15} />
            <span>خروج</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
        {/* ================================================= */}
        {/* TAB 1: ADVANCED REAL-TIME REPORTS & ANALYTICS */}
        {/* ================================================= */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            {/* Header with Live Real-Time Indicator & Refresh */}
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-black text-stone-900 tracking-tight">التقارير والمؤشرات المالية</h2>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
                    <span>مباشر باللحظة (Real-Time Live)</span>
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-stone-500 font-medium mt-0.5">
                  متصل مباشرة مع شاشات الزبائن والمطبخ والكاشير بالدينار العراقي (IQD)
                </p>
              </div>

              <button
                onClick={loadAdvancedReportsOnly}
                disabled={isRefreshingReports}
                className="btn btn-secondary py-2 px-3.5 text-xs font-black flex items-center gap-2"
                title="تحديث البيانات"
              >
                <RefreshCw size={14} className={isRefreshingReports ? 'animate-spin' : ''} />
                <span>{isRefreshingReports ? 'جاري التحديث...' : 'تحديث لحظي'}</span>
              </button>
            </div>

            {/* 6 Advanced Real-Time KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
              {/* Card 1: Settled / Paid Revenue Today */}
              <div className="card p-4.5 bg-white border-stone-200 shadow-xs flex flex-col justify-between space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-500">مسدد اليوم</span>
                  <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                    <DollarSign size={17} />
                  </div>
                </div>
                <div>
                  <span className="text-xl font-black text-emerald-700 tracking-tight block">
                    {formatCurrency(advancedReports?.live_kpis?.today_paid_revenue || salesReport?.today?.today_revenue || 0, 'IQD', lang)}
                  </span>
                  <span className="text-[10px] text-stone-400 font-medium mt-0.5 block">
                    {advancedReports?.live_kpis?.today_paid_orders_count || salesReport?.today?.today_orders || 0} فواتير مسددة بالكاشير
                  </span>
                </div>
              </div>

              {/* Card 2: Active In-Kitchen Revenue */}
              <div className="card p-4.5 bg-[#FFFDF8] border-amber-300 shadow-xs flex flex-col justify-between space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-800">قيد التحضير بالصالة</span>
                  <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                    <Clock size={17} className="animate-pulse" />
                  </div>
                </div>
                <div>
                  <span className="text-xl font-black text-amber-800 tracking-tight block">
                    {formatCurrency(advancedReports?.live_kpis?.today_active_revenue || 0, 'IQD', lang)}
                  </span>
                  <span className="text-[10px] text-amber-700 font-bold mt-0.5 block">
                    {advancedReports?.live_kpis?.today_active_orders_count || 0} طلبات جارية بالمطبخ
                  </span>
                </div>
              </div>

              {/* Card 3: Total Live Volume Today (Paid + Cooking) */}
              <div className="card p-4.5 bg-white border-orange-200 shadow-xs flex flex-col justify-between space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-500">إجمالي حجم مبيعات اليوم</span>
                  <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-700 flex items-center justify-center font-bold">
                    <Flame size={17} />
                  </div>
                </div>
                <div>
                  <span className="text-xl font-black text-orange-800 tracking-tight block">
                    {formatCurrency(advancedReports?.live_kpis?.today_total_volume || 0, 'IQD', lang)}
                  </span>
                  <span className="text-[10px] text-stone-400 font-medium mt-0.5 block">
                    المسدد + النشط
                  </span>
                </div>
              </div>

              {/* Card 4: Total Orders Today */}
              <div className="card p-4.5 bg-white border-stone-200 shadow-xs flex flex-col justify-between space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-500">طلبات اليوم الكلية</span>
                  <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
                    <ShoppingBag size={17} />
                  </div>
                </div>
                <div>
                  <span className="text-xl font-black text-stone-900 tracking-tight block">
                    {advancedReports?.live_kpis?.today_total_orders || 0} طلب
                  </span>
                  <span className="text-[10px] text-stone-400 font-medium mt-0.5 block">
                    تم استلامها من الطاولات
                  </span>
                </div>
              </div>

              {/* Card 5: Live Table Occupancy */}
              <div className="card p-4.5 bg-white border-stone-200 shadow-xs flex flex-col justify-between space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-500">إشغال الطاولات المباشر</span>
                  <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
                    <Activity size={17} />
                  </div>
                </div>
                <div>
                  <span className="text-xl font-black text-purple-900 tracking-tight block">
                    {advancedReports?.live_kpis?.occupancy_rate || 0}%
                  </span>
                  <span className="text-[10px] text-stone-400 font-medium mt-0.5 block">
                    {advancedReports?.live_kpis?.occupied_tables || 0} من {advancedReports?.live_kpis?.total_tables || tables.length} طاولات مشغولة
                  </span>
                </div>
              </div>

              {/* Card 6: Total All-Time Revenue */}
              <div className="card p-4.5 bg-white border-stone-200 shadow-xs flex flex-col justify-between space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-500">المبيعات الكلية</span>
                  <div className="w-10 h-10 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center font-bold">
                    <TrendingUp size={17} />
                  </div>
                </div>
                <div>
                  <span className="text-xl font-black text-stone-900 tracking-tight block">
                    {formatCurrency(advancedReports?.live_kpis?.total_revenue_all_time || salesReport?.total?.total_revenue || 0, 'IQD', lang)}
                  </span>
                  <span className="text-[10px] text-stone-400 font-medium mt-0.5 block">
                    معدل الفاتورة: {formatCurrency(advancedReports?.live_kpis?.avg_order_value || salesReport?.total?.avg_order_value || 0, 'IQD', lang)}
                  </span>
                </div>
              </div>
            </div>

            {/* Real Database 7-Day Performance Chart */}
            <div className="card p-6 bg-white border-stone-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-black text-stone-900 text-base flex items-center gap-2">
                    <BarChart3 size={18} className="text-orange-700" />
                    <span>مخطط الأداء اليومي الحقيقي (آخر 7 أيام من قاعدة البيانات)</span>
                  </h3>
                  <p className="text-xs text-stone-400 font-medium">يتحدث تلقائياً فور تسجيل أي طلب جديد في النظام</p>
                </div>
                <span className="badge badge-served text-xs font-black">مربوط بالـ SQLite والـ WebSocket</span>
              </div>

              {/* Dynamic Real-Data Bar Chart */}
              {(() => {
                const chartList = advancedReports?.chart_data || [];
                const maxRev = Math.max(...chartList.map(c => c.revenue), 10000);

                return (
                  <div className="pt-4 pb-2">
                    <div className="h-48 flex items-end justify-between gap-2 sm:gap-4 border-b border-stone-200 pb-2">
                      {chartList.map((bar, i) => {
                        const isToday = i === chartList.length - 1;
                        const heightPct = Math.max(8, Math.min(100, Math.round((bar.revenue / maxRev) * 100)));

                        return (
                          <div key={i} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                            <span className="text-[10px] font-black text-stone-500 group-hover:text-orange-700 transition">
                              {bar.revenue > 0 ? (bar.revenue / 1000).toFixed(0) + 'k' : '0'}
                            </span>
                            <div
                              className={`w-full max-w-[42px] rounded-t-xl transition-all duration-500 group-hover:brightness-110 shadow-xs ${
                                isToday
                                  ? 'bg-gradient-to-t from-orange-700 to-amber-500 ring-2 ring-orange-300'
                                  : 'bg-gradient-to-t from-stone-400 to-stone-300'
                              }`}
                              style={{ height: `${heightPct}%` }}
                              title={`${bar.day} (${bar.date}): ${formatCurrency(bar.revenue, 'IQD', lang)} - ${bar.orders} طلبات`}
                            />
                            <span className={`text-[11px] mt-1 whitespace-nowrap ${
                              isToday ? 'font-black text-orange-800' : 'font-bold text-stone-600'
                            }`}>
                              {bar.day} {isToday ? '(اليوم)' : ''}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Food Category Share & Live Activity Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Category Breakdown (1 Col) */}
              <div className="card p-5 bg-white border-stone-200 shadow-sm space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-stone-100">
                  <Layers className="text-orange-700" size={18} />
                  <h3 className="font-black text-stone-900 text-base">حصة فئات الطعام من المبيعات</h3>
                </div>

                <div className="space-y-3 text-xs">
                  {(advancedReports?.category_breakdown || []).map((cat) => (
                    <div key={cat.category_id} className="space-y-1">
                      <div className="flex items-center justify-between font-bold">
                        <span className="text-stone-800">{cat.category_name}</span>
                        <span className="text-stone-500 font-mono">
                          {formatCurrency(cat.total_revenue, 'IQD', lang)} ({cat.percentage}%)
                        </span>
                      </div>
                      <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-orange-600 to-amber-500 rounded-full transition-all duration-500"
                          style={{ width: `${Math.max(5, cat.percentage)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Real-Time Live Activity Feed (2 Cols) */}
              <div className="card p-5 bg-white border-stone-200 shadow-sm space-y-4 lg:col-span-2 flex flex-col justify-between">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100">
                  <div className="flex items-center gap-2">
                    <Activity className="text-orange-700" size={18} />
                    <h3 className="font-black text-stone-900 text-base">سجل الطلبات الحية في الصالة والمطبخ</h3>
                  </div>
                  <span className="text-[11px] text-stone-400 font-medium">آخر الطلبات المباشرة</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-right rtl:text-right ltr:text-left text-xs">
                    <thead className="bg-[#FAF7F2] text-stone-700 font-black border-b border-stone-200">
                      <tr>
                        <th className="p-2.5">الطاولة</th>
                        <th className="p-2.5">الأصناف</th>
                        <th className="p-2.5">الحالة</th>
                        <th className="p-2.5">المبلغ</th>
                        <th className="p-2.5">التوقيت</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {(advancedReports?.recent_activity || []).length === 0 ? (
                        <tr>
                          <td colSpan="5" className="p-6 text-center text-stone-400 font-medium">
                            لا توجد حركات مسجلة مؤخراً.
                          </td>
                        </tr>
                      ) : (
                        (advancedReports?.recent_activity || []).map((order) => {
                          const statusLabel =
                            order.status === 'new' ? 'طلب جديد' :
                            order.status === 'preparing' ? 'قيد التحضير' :
                            order.status === 'ready' ? 'جاهز للتقديم' :
                            order.status === 'served' ? 'تم التقديم' :
                            order.status === 'paid' ? 'تم السداد' : 'ملغي';

                          const statusBadgeClass =
                            order.status === 'new' ? 'badge-new' :
                            order.status === 'preparing' ? 'badge-preparing' :
                            order.status === 'ready' ? 'badge-ready' :
                            order.status === 'served' ? 'badge-served' : 'badge-paid';

                          return (
                            <tr key={order.id} className="hover:bg-[#FAF7F2]/60 transition">
                              <td className="p-2.5 font-black text-stone-900">
                                طاولة #{order.table_number}
                              </td>
                              <td className="p-2.5 text-stone-600 max-w-[200px] truncate font-medium">
                                {order.items_summary || '—'}
                              </td>
                              <td className="p-2.5">
                                <span className={`badge text-[10px] ${statusBadgeClass}`}>
                                  {statusLabel}
                                </span>
                              </td>
                              <td className="p-2.5 font-black text-orange-800">
                                {formatCurrency(order.total_amount, 'IQD', lang)}
                              </td>
                              <td className="p-2.5 font-mono text-[10px] text-stone-400 whitespace-nowrap">
                                {new Date(order.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Top Selling Dishes (Zebra Striping Table) */}
            <div className="card p-6 bg-white border-stone-200 shadow-sm space-y-4">
              <h3 className="font-black text-stone-900 text-base flex items-center gap-2">
                <TrendingUp size={18} className="text-orange-700" />
                <span>الأطباق الأكثر طلباً ومبيعاً</span>
              </h3>

              <div className="overflow-x-auto rounded-xl border border-stone-200/90">
                <table className="w-full text-right rtl:text-right ltr:text-left text-xs sm:text-sm">
                  <thead className="bg-[#FAF7F2] text-stone-700 font-black border-b border-stone-200">
                    <tr>
                      <th className="p-3.5">الصنف</th>
                      <th className="p-3.5">السعر الفردي</th>
                      <th className="p-3.5">الكميات المباعة</th>
                      <th className="p-3.5">إجمالي الدخل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {topItems.length === 0 ? (
                      <tr>
                        <td colSpan="4" className="p-8 text-center text-stone-400 font-medium">
                          لا توجد بيانات مبيعات كافية بعد.
                        </td>
                      </tr>
                    ) : (
                      topItems.map((item, idx) => (
                        <tr
                          key={idx}
                          className={`transition ${idx % 2 === 0 ? 'bg-white' : 'bg-[#FAF7F2]/60'} hover:bg-orange-50/50`}
                        >
                          <td className="p-3.5 font-black text-stone-900">{item.name_ar}</td>
                          <td className="p-3.5 text-stone-600 font-medium">
                            {formatCurrency(item.price, 'IQD', lang)}
                          </td>
                          <td className="p-3.5 font-black text-orange-800">{item.total_quantity_sold} طلب</td>
                          <td className="p-3.5 font-black text-stone-900">
                            {formatCurrency(item.total_sales_volume, 'IQD', lang)}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 2: MENU & DISHES */}
        {/* ================================================= */}
        {activeTab === 'menu' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="text-2xl font-black text-stone-900 tracking-tight">إدارة أصناف المنيو</h2>
                <p className="text-xs sm:text-sm text-stone-500 font-medium">
                  تعديل الأسعار بالدينار العراقي (IQD)، رفع الصور، والتحكم بنفاد المخزون
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingDish(null);
                  setDishFormData({
                    name_ar: '', name_en: '', category_id: categories[0]?.id || '',
                    description_ar: '', description_en: '', price: '', image_url: '', is_available: 1
                  });
                  setIsDishModalOpen(true);
                }}
                className="btn btn-primary py-2.5 px-4 text-xs font-black flex items-center gap-2 shadow-md"
              >
                <Plus size={16} />
                <span>إضافة طبق جديد</span>
              </button>
            </div>

            <div className="card overflow-x-auto bg-white border-stone-200 shadow-sm rounded-2xl">
              <table className="w-full text-right rtl:text-right ltr:text-left text-xs sm:text-sm">
                <thead className="bg-[#FAF7F2] text-stone-700 font-black border-b border-stone-200">
                  <tr>
                    <th className="p-3.5">الصورة</th>
                    <th className="p-3.5">الطبق</th>
                    <th className="p-3.5">الفئة</th>
                    <th className="p-3.5">السعر</th>
                    <th className="p-3.5">حالة التوفر</th>
                    <th className="p-3.5">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {menuItems.map((item, idx) => (
                    <tr
                      key={item.id}
                      className={`transition ${idx % 2 === 0 ? 'bg-white' : 'bg-[#FAF7F2]/60'} hover:bg-orange-50/40`}
                    >
                      <td className="p-3.5">
                        <div className="w-14 h-14 rounded-xl bg-stone-100 overflow-hidden border border-stone-200">
                          {item.image_url ? (
                            <img src={item.image_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center font-bold text-stone-300">
                              {item.name_ar.charAt(0)}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-black text-stone-900 text-sm">{item.name_ar}</div>
                        <div className="text-xs text-stone-400 font-medium">{item.name_en}</div>
                      </td>
                      <td className="p-3.5">
                        <span className="bg-stone-100 text-stone-700 px-3 py-1 rounded-full text-xs font-bold border border-stone-200">
                          {item.category_name_ar || item.category_id}
                        </span>
                      </td>
                      <td className="p-3.5 font-black text-orange-800 text-sm">
                        {formatCurrency(item.price, 'IQD', lang)}
                      </td>
                      <td className="p-3.5">
                        <button
                          onClick={() => handleToggleAvailability(item.id)}
                          className={`badge cursor-pointer transition ${
                            item.is_available ? 'badge-served' : 'badge-cancelled'
                          }`}
                        >
                          {item.is_available ? <Eye size={13} /> : <EyeOff size={13} />}
                          <span>{item.is_available ? 'متوفر' : 'نفد المخزون'}</span>
                        </button>
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingDish(item);
                              setDishFormData({
                                name_ar: item.name_ar,
                                name_en: item.name_en,
                                category_id: item.category_id,
                                description_ar: item.description_ar || '',
                                description_en: item.description_en || '',
                                price: item.price,
                                image_url: item.image_url || '',
                                is_available: item.is_available
                              });
                              setIsDishModalOpen(true);
                            }}
                            className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition"
                            title="تعديل الصنف"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            onClick={() => handleDeleteDish(item.id, item.name_ar)}
                            className="p-2 rounded-xl bg-stone-100 hover:bg-red-100 text-stone-700 hover:text-red-700 transition"
                            title="حذف الصنف"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 3: TABLES & QR */}
        {/* ================================================= */}
        {activeTab === 'tables' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="text-2xl font-black text-stone-900 tracking-tight">إدارة الطاولات ورموز QR</h2>
                <p className="text-xs sm:text-sm text-stone-500 font-medium">
                  توليد بطاقات الستاند بترميز فريد غير متسلسل لمنع التخمين
                </p>
              </div>

              <button
                onClick={handleAddTable}
                className="btn btn-primary py-2.5 px-4 text-xs font-black flex items-center gap-2 shadow-md"
              >
                <Plus size={16} />
                <span>إضافة طاولة جديدة</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {tables.map(tbl => (
                <div key={tbl.id} className="card p-5 bg-white border-stone-200 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-stone-900 text-lg">
                      طاولة #{tbl.table_number}
                    </span>
                    <button
                      onClick={() => handleToggleTable(tbl.id)}
                      className={`badge cursor-pointer ${tbl.is_active ? 'badge-served' : 'badge-cancelled'}`}
                    >
                      {tbl.is_active ? 'مفعلة' : 'معطلة'}
                    </button>
                  </div>

                  <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-stone-200 text-center">
                    <img
                      src={tbl.qr_code_url}
                      alt={`QR Table ${tbl.table_number}`}
                      className="w-36 h-36 mx-auto object-contain rounded-xl shadow-xs"
                    />
                    <span className="text-[10px] text-stone-400 block mt-2 font-mono truncate">
                      معرف: {tbl.id.substring(0, 14)}...
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setPrintingTable(tbl)}
                      className="btn btn-secondary py-2 text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <Printer size={14} />
                      <span>بطاقة الستاند</span>
                    </button>
                    <a
                      href={tbl.qr_code_url}
                      download={`table-${tbl.table_number}-qr.png`}
                      className="btn btn-secondary py-2 text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <Download size={14} />
                      <span>تحميل PNG</span>
                    </a>
                  </div>

                  <div className="pt-2 border-t border-stone-100 flex justify-between items-center text-xs">
                    <a
                      href={`/table/${tbl.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-orange-800 font-bold hover:underline"
                    >
                      فتح صفحة الزبون ↗
                    </a>
                    <button
                      onClick={() => handleDeleteTable(tbl.id, tbl.table_number)}
                      className="text-stone-400 hover:text-red-600 transition"
                      title="حذف الطاولة"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 4: STAFF DIRECTORY */}
        {/* ================================================= */}
        {activeTab === 'staff' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="text-2xl font-black text-stone-900 tracking-tight flex items-center gap-2">
                  <Users className="text-orange-700" />
                  <span>دليل وتسجيل أسماء الموظفين</span>
                </h2>
                <p className="text-xs sm:text-sm text-stone-500 font-medium">
                  إدارة الطاقم التشغيلي، المسميات الوظيفية، والورديات
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingStaff(null);
                  setStaffFormData({ name: '', role: 'ويتر صالة (Waiter)', phone: '', shift: 'صباحي' });
                  setIsStaffModalOpen(true);
                }}
                className="btn btn-primary py-2.5 px-4 text-xs font-black flex items-center gap-2 shadow-md"
              >
                <Plus size={16} />
                <span>تسجيل موظف جديد</span>
              </button>
            </div>

            <div className="card overflow-x-auto bg-white border-stone-200 shadow-sm rounded-2xl">
              <table className="w-full text-right rtl:text-right ltr:text-left text-xs sm:text-sm">
                <thead className="bg-[#FAF7F2] text-stone-700 font-black border-b border-stone-200">
                  <tr>
                    <th className="p-3.5">الموظف</th>
                    <th className="p-3.5">المسمى الوظيفي</th>
                    <th className="p-3.5">الوردية</th>
                    <th className="p-3.5">رقم الهاتف</th>
                    <th className="p-3.5">الحالة</th>
                    <th className="p-3.5">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {staffMembers.map((staff, idx) => (
                    <tr
                      key={staff.id}
                      className={`transition ${idx % 2 === 0 ? 'bg-white' : 'bg-[#FAF7F2]/60'} hover:bg-orange-50/40`}
                    >
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-900 font-black flex items-center justify-center border border-amber-200">
                            {staff.name.charAt(0)}
                          </div>
                          <span className="font-black text-stone-900">{staff.name}</span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span className="bg-amber-100 text-amber-900 px-3 py-1 rounded-full text-xs font-bold border border-amber-300">
                          {staff.role}
                        </span>
                      </td>
                      <td className="p-3.5 font-bold text-stone-600">{staff.shift}</td>
                      <td className="p-3.5 font-mono text-stone-400">{staff.phone || '—'}</td>
                      <td className="p-3.5">
                        <button
                          onClick={() => handleToggleStaff(staff.id)}
                          className={`badge cursor-pointer ${staff.is_active ? 'badge-served' : 'badge-cancelled'}`}
                        >
                          {staff.is_active ? 'نشط' : 'معطل'}
                        </button>
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingStaff(staff);
                              setStaffFormData({
                                name: staff.name,
                                role: staff.role,
                                phone: staff.phone || '',
                                shift: staff.shift || 'صباحي'
                              });
                              setIsStaffModalOpen(true);
                            }}
                            className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition"
                            title="تعديل الموظف"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            onClick={() => handleDeleteStaff(staff.id, staff.name)}
                            className="p-2 rounded-xl bg-stone-100 hover:bg-red-100 text-stone-700 hover:text-red-700 transition"
                            title="حذف الموظف"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 5: INCIDENTS MANAGEMENT */}
        {/* ================================================= */}
        {activeTab === 'incidents' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-2xl font-black text-stone-900 tracking-tight flex items-center gap-2">
                <MessageSquareWarning className="text-orange-700" />
                <span>متابعة مشاكل وبلاغات الخدمة</span>
              </h2>
              <p className="text-xs sm:text-sm text-stone-500 font-medium">
                سجل الشكاوى التشغيلية وملاحظات الجودة لضمان رضا الزبائن
              </p>
            </div>

            <div className="card overflow-hidden bg-white border-stone-200 shadow-sm rounded-2xl">
              <div className="divide-y divide-stone-100">
                {incidents.length === 0 ? (
                  <div className="p-12 text-center text-stone-400 font-medium text-xs">
                    لا توجد أي بلاغات مسجلة حالياً.
                  </div>
                ) : (
                  incidents.map(inc => (
                    <div key={inc.id} className="p-5 flex items-start justify-between gap-4 hover:bg-[#FAF7F2] transition">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2.5 flex-wrap">
                          <span className="font-black text-stone-900 text-sm">{inc.issue_type}</span>
                          {inc.table_number && (
                            <span className="bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full text-[10px] font-black border border-amber-300">
                              طاولة #{inc.table_number}
                            </span>
                          )}
                          <span className={`badge text-[10px] ${
                            inc.status === 'resolved' ? 'badge-served' : inc.status === 'in_progress' ? 'badge-preparing' : 'badge-cancelled'
                          }`}>
                            {inc.status === 'resolved' ? 'تم الحل' : inc.status === 'in_progress' ? 'قيد المتابعة' : 'مفتوح'}
                          </span>
                        </div>

                        <p className="text-xs text-stone-700 leading-relaxed font-medium">{inc.description}</p>

                        <div className="text-[11px] text-stone-400 flex items-center gap-2">
                          <span>المسجل: {inc.reported_by}</span>
                          <span>•</span>
                          <span>التوقيت: {new Date(inc.created_at).toLocaleString()}</span>
                          {inc.resolved_at && (
                            <>
                              <span>•</span>
                              <span className="text-emerald-700 font-bold">تم الحل: {new Date(inc.resolved_at).toLocaleTimeString()}</span>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        {inc.status !== 'resolved' && (
                          <button
                            onClick={() => handleUpdateIncident(inc.id, 'resolved')}
                            className="btn btn-success py-1.5 px-3 text-xs font-black"
                          >
                            حل البلاغ
                          </button>
                        )}
                        {inc.status === 'open' && (
                          <button
                            onClick={() => handleUpdateIncident(inc.id, 'in_progress')}
                            className="btn btn-secondary py-1.5 px-3 text-xs font-bold"
                          >
                            متابعة
                          </button>
                        )}
                        <button
                          onClick={() => handleDeleteIncident(inc.id)}
                          className="p-2 rounded-xl hover:bg-red-50 text-stone-400 hover:text-red-600 transition"
                          title="مسح البلاغ"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 6: SETTINGS & SECURITY */}
        {/* ================================================= */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* 1. RESTAURANT IDENTITY & BRANDING (Name & Image/Logo) */}
            <div className="card p-6 bg-white border-stone-200 shadow-sm space-y-5 rounded-3xl">
              <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-stone-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-600 to-amber-600 text-white flex items-center justify-center shadow-sm">
                    <Store size={20} />
                  </div>
                  <div>
                    <h3 className="font-black text-stone-900 text-base">هوية وبيانات المطعم (الاسم والصورة)</h3>
                    <p className="text-xs text-stone-400 font-medium">
                      تعديل اسم المطعم وصورته الرئيسية التي تظهر للزبائن في المنيو والشاشات
                    </p>
                  </div>
                </div>

                {settingsSavedMessage && (
                  <div className="px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-black flex items-center gap-1.5 border border-emerald-300 animate-fade">
                    <CheckCircle2 size={15} />
                    <span>{settingsSavedMessage}</span>
                  </div>
                )}
              </div>

              <form onSubmit={handleSaveRestaurantBranding} className="space-y-5">
                {/* Logo & Picture Upload Area */}
                <div>
                  <label className="text-xs font-black text-stone-800 block mb-2">
                    شعار وصورة المطعم الرئيسية (Logo / Image)
                  </label>

                  <div className="flex items-center flex-wrap gap-5">
                    {/* Logo Preview Box */}
                    <div className="relative group w-24 h-24 rounded-3xl border-2 border-dashed border-stone-300 bg-[#FAF7F2] flex items-center justify-center overflow-hidden shadow-xs flex-shrink-0">
                      {restaurantForm.logo_url ? (
                        <img
                          src={restaurantForm.logo_url}
                          alt="Restaurant Logo"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-stone-400 p-2 text-center">
                          <ImageIcon size={28} className="stroke-1 text-stone-300 mb-1" />
                          <span className="text-[10px] font-bold">لا يوجد شعار</span>
                        </div>
                      )}

                      {/* Hover Overlay to change */}
                      <label className="absolute inset-0 bg-black/50 text-white opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center cursor-pointer transition text-[10px] font-black">
                        <Camera size={20} className="mb-0.5" />
                        <span>تغيير</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="hidden"
                          disabled={uploadingLogo}
                        />
                      </label>
                    </div>

                    {/* Upload Controls */}
                    <div className="space-y-2 flex-1 min-w-[220px]">
                      <div className="flex items-center gap-2">
                        <label className="btn btn-secondary py-2 px-3.5 text-xs font-black cursor-pointer flex items-center gap-1.5">
                          <Upload size={14} />
                          <span>{uploadingLogo ? 'جاري الرفع...' : 'رفع صورة من الجهاز'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleLogoUpload}
                            className="hidden"
                            disabled={uploadingLogo}
                          />
                        </label>

                        {restaurantForm.logo_url && (
                          <button
                            type="button"
                            onClick={() => setRestaurantForm(prev => ({ ...prev, logo_url: '' }))}
                            className="text-stone-400 hover:text-red-600 p-2 text-xs font-bold transition"
                            title="إزالة الصورة"
                          >
                            إزالة
                          </button>
                        )}
                      </div>

                      <div>
                        <span className="text-[11px] font-bold text-stone-500 block mb-1">
                          أو رابط مباشر لصورة الشعار:
                        </span>
                        <input
                          type="text"
                          value={restaurantForm.logo_url}
                          onChange={(e) => setRestaurantForm(prev => ({ ...prev, logo_url: e.target.value }))}
                          placeholder="https://example.com/logo.png أو مسار /uploads/images/..."
                          className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-2.5 text-xs font-mono outline-none focus:bg-white focus:border-orange-600"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Restaurant Names (Arabic & English) + Currency */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                  <div>
                    <label className="text-xs font-black text-stone-800 block mb-1.5">
                      اسم المطعم بالعربية *
                    </label>
                    <input
                      type="text"
                      required
                      value={restaurantForm.restaurant_name_ar}
                      onChange={(e) => setRestaurantForm(prev => ({ ...prev, restaurant_name_ar: e.target.value }))}
                      placeholder="مثال: مطعم اللذة الذكية"
                      className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs font-bold outline-none focus:bg-white focus:border-orange-600"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-stone-800 block mb-1.5">
                      اسم المطعم بالإنجليزية (English)
                    </label>
                    <input
                      type="text"
                      value={restaurantForm.restaurant_name_en}
                      onChange={(e) => setRestaurantForm(prev => ({ ...prev, restaurant_name_en: e.target.value }))}
                      placeholder="e.g. Smart Gourmet Restaurant"
                      className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs font-bold outline-none focus:bg-white focus:border-orange-600"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-stone-800 block mb-1.5">
                      العملة الرسمية
                    </label>
                    <input
                      type="text"
                      value={restaurantForm.currency}
                      onChange={(e) => setRestaurantForm(prev => ({ ...prev, currency: e.target.value }))}
                      placeholder="IQD أو د.ع"
                      className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs font-bold outline-none focus:bg-white focus:border-orange-600"
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    className="btn btn-primary py-3 px-8 text-xs font-black shadow-md flex items-center gap-2"
                  >
                    <CheckCircle2 size={16} />
                    <span>حفظ بيانات وهوية المطعم</span>
                  </button>
                </div>
              </form>
            </div>

            {/* 2. PASSWORDS & AUDIT LOGS GRID */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Passwords */}
              <div className="card p-6 bg-white border-stone-200 shadow-sm space-y-4 rounded-3xl">
                <div className="flex items-center gap-2.5 pb-3 border-b border-stone-100">
                  <ShieldCheck className="text-orange-700" size={20} />
                  <h3 className="font-black text-stone-900 text-base">تغيير كلمات المرور (الأدمن والموظفين)</h3>
                </div>

                {pwMessage && (
                  <div className="p-3 rounded-xl bg-stone-100 text-xs font-bold text-stone-900 border border-stone-200">
                    {pwMessage}
                  </div>
                )}

                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1">الحساب المطلوب تعديله</label>
                    <select
                      value={pwTarget}
                      onChange={(e) => setPwTarget(e.target.value)}
                      className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs font-bold outline-none"
                    >
                      <option value="admin">كلمة مرور المشرف العام (Admin)</option>
                      <option value="staff">كلمة مرور طاقم الخدمة (Staff)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1">كلمة مرور الأدمن الحالية للتأكيد</label>
                    <input
                      type="password"
                      required
                      value={currentPw}
                      onChange={(e) => setCurrentPw(e.target.value)}
                      placeholder="أدخل باسوورد الأدمن الحالي"
                      className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1">كلمة المرور الجديدة</label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={newPw}
                      onChange={(e) => setNewPw(e.target.value)}
                      placeholder="6 خانات على الأقل"
                      className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 text-xs outline-none"
                    />
                  </div>

                  <button type="submit" className="w-full btn btn-primary py-3 text-xs font-black shadow-sm">
                    حفظ وتأكيد كلمة المرور الجديدة
                  </button>
                </form>
              </div>

              {/* Audit Logs */}
              <div className="card p-6 bg-white border-stone-200 shadow-sm space-y-4 rounded-3xl flex flex-col">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <h3 className="font-black text-stone-900 text-base">سجل التدقيق الأمني (Audit Logs)</h3>
                  <span className="text-xs text-stone-400 font-medium">آخر الحركات الأمنية</span>
                </div>

                <div className="overflow-y-auto max-h-80 divide-y divide-stone-100 text-xs">
                  {auditLogs.map(log => (
                    <div key={log.id} className="py-2.5 space-y-1">
                      <div className="flex items-center justify-between font-bold text-stone-900">
                        <span>{log.event_type}</span>
                        <span className="text-[10px] text-stone-400 font-mono">
                          {new Date(log.created_at).toLocaleString()}
                        </span>
                      </div>
                      <div className="text-[11px] text-stone-500 flex items-center gap-2">
                        <span>IP: {log.ip_address}</span>
                        <span>•</span>
                        <span>الدور: {log.role || 'عام'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* DISH MODAL */}
      {isDishModalOpen && (
        <div className="modal-overlay" onClick={() => setIsDishModalOpen(false)}>
          <div
            className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto animate-fade border border-stone-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-black text-stone-900 text-base">
                {editingDish ? 'تعديل طبق' : 'إضافة طبق جديد للمنيو'}
              </h3>
              <button
                onClick={() => setIsDishModalOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveDish} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-stone-700 block mb-1">اسم الصنف بالعربية *</label>
                <input
                  type="text"
                  required
                  value={dishFormData.name_ar}
                  onChange={(e) => setDishFormData({ ...dishFormData, name_ar: e.target.value })}
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">اسم الصنف بالإنجليزية *</label>
                <input
                  type="text"
                  required
                  value={dishFormData.name_en}
                  onChange={(e) => setDishFormData({ ...dishFormData, name_en: e.target.value })}
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">الفئة *</label>
                  <select
                    required
                    value={dishFormData.category_id}
                    onChange={(e) => setDishFormData({ ...dishFormData, category_id: e.target.value })}
                    className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name_ar}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">السعر (د.ع) *</label>
                  <input
                    type="number"
                    step="500"
                    min="0"
                    required
                    value={dishFormData.price}
                    onChange={(e) => setDishFormData({ ...dishFormData, price: e.target.value })}
                    className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">وصف الصنف بالعربية</label>
                <textarea
                  rows={2}
                  value={dishFormData.description_ar}
                  onChange={(e) => setDishFormData({ ...dishFormData, description_ar: e.target.value })}
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none resize-none font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">صورة الصنف (رفع أو رابط)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={dishFormData.image_url}
                    onChange={(e) => setDishFormData({ ...dishFormData, image_url: e.target.value })}
                    placeholder="https://... أو اضغط رفع صورة"
                    className="flex-1 bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none"
                  />
                  <label className="btn btn-secondary py-2 px-3.5 cursor-pointer text-xs font-bold flex items-center gap-1">
                    <Upload size={14} />
                    <span>{uploadingImage ? 'جاري...' : 'رفع'}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </label>
                </div>
              </div>

              <div className="pt-2">
                <button type="submit" className="w-full btn btn-primary py-3.5 text-xs font-black shadow-md">
                  {editingDish ? 'حفظ التعديلات' : 'إضافة الصنف للمنيو'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STAFF MODAL */}
      {isStaffModalOpen && (
        <div className="modal-overlay" onClick={() => setIsStaffModalOpen(false)}>
          <div
            className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6 space-y-4 animate-fade border border-stone-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-black text-stone-900 text-base">
                {editingStaff ? 'تعديل بيانات الموظف' : 'تسجيل موظف جديد في الطاقم'}
              </h3>
              <button
                onClick={() => setIsStaffModalOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveStaff} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-stone-700 block mb-1">الاسم الكامل *</label>
                <input
                  type="text"
                  required
                  value={staffFormData.name}
                  onChange={(e) => setStaffFormData({ ...staffFormData, name: e.target.value })}
                  placeholder="مثال: حسام الكرخي"
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">المسمى الوظيفي *</label>
                  <select
                    value={staffFormData.role}
                    onChange={(e) => setStaffFormData({ ...staffFormData, role: e.target.value })}
                    className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                  >
                    <option value="كاشير (Cashier)">كاشير (Cashier)</option>
                    <option value="شيف أول (Head Chef)">شيف أول (Head Chef)</option>
                    <option value="طاهي مساعد (Assistant Chef)">طاهي مساعد (Assistant Chef)</option>
                    <option value="ويتر صالة (Waiter)">ويتر صالة (Waiter)</option>
                    <option value="مشرف صالة (Floor Supervisor)">مشرف صالة (Floor Supervisor)</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">الوردية *</label>
                  <select
                    value={staffFormData.shift}
                    onChange={(e) => setStaffFormData({ ...staffFormData, shift: e.target.value })}
                    className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold"
                  >
                    <option value="صباحي">صباحي (Morning)</option>
                    <option value="مسائي">مسائي (Evening)</option>
                    <option value="ليلي">ليلي (Night)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">رقم الهاتف للتواصل</label>
                <input
                  type="tel"
                  value={staffFormData.phone}
                  onChange={(e) => setStaffFormData({ ...staffFormData, phone: e.target.value })}
                  placeholder="07XXXXXXXXX"
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-mono"
                />
              </div>

              <div className="pt-2">
                <button type="submit" className="w-full btn btn-primary py-3.5 text-xs font-black shadow-md">
                  {editingStaff ? 'تحديث البيانات' : 'تسجيل الموظف'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINTABLE QR CARD */}
      {printingTable && (
        <div className="modal-overlay" onClick={() => setPrintingTable(null)}>
          <div
            className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl p-6 text-center space-y-4 animate-fade border border-stone-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-end">
              <button
                onClick={() => setPrintingTable(null)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center print:hidden font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 border-4 border-orange-700 rounded-3xl space-y-4 bg-gradient-to-b from-[#FFFDF8] to-white">
              <div className="space-y-1">
                <h3 className="font-black text-xl text-stone-900">
                  {restaurantSettings.restaurant_name_ar || 'مطعم اللذة الذكية'}
                </h3>
                <span className="text-xs text-stone-400 font-bold block">
                  {restaurantSettings.restaurant_name_en || 'Smart Gourmet Restaurant'}
                </span>
              </div>

              <div className="inline-block bg-gradient-to-r from-orange-700 to-amber-700 text-white font-black text-lg px-6 py-2 rounded-full shadow-sm">
                طاولة #{printingTable.table_number}
              </div>

              <div className="bg-white p-3.5 rounded-2xl border-2 border-stone-200 inline-block shadow-sm">
                <img
                  src={printingTable.qr_code_url}
                  alt=""
                  className="w-48 h-48 mx-auto object-contain"
                />
              </div>

              <div className="space-y-1">
                <p className="text-xs font-black text-stone-900">
                  امسح الرمز بكاميرا هاتفك للطلب مباشرة 📱
                </p>
                <p className="text-[11px] text-stone-400 font-medium">
                  Scan QR code with your phone camera to order
                </p>
              </div>
            </div>

            <button
              onClick={() => window.print()}
              className="w-full btn btn-primary py-3.5 text-xs font-black flex items-center justify-center gap-2 print:hidden shadow-md"
            >
              <Printer size={16} />
              <span>طباعة بطاقة الطاولة الآن</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
