import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/formatCurrency';
import { ShoppingBag, X, Plus, Minus, Trash2, Send } from 'lucide-react';

export default function CartDrawer({
  cart,
  isOpen,
  onOpen,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onSubmitOrder,
  isSubmitting,
  currency = 'IQD'
}) {
  const { lang, t } = useLanguage();

  const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (cart.length === 0 && !isOpen) return null;

  return (
    <>
      {/* Floating Bottom Cart Bar */}
      {cart.length > 0 && !isOpen && (
        <div className="fixed bottom-5 left-4 right-4 z-40 max-w-[480px] mx-auto animate-slide-up">
          <button
            onClick={onOpen}
            className="w-full bg-stone-900 text-white p-3.5 rounded-2xl flex items-center justify-between shadow-2xl shadow-stone-950/40 hover:bg-black transition border border-stone-800 active:scale-98"
          >
            <div className="flex items-center gap-3">
              <div className="relative p-2.5 rounded-xl bg-orange-700 text-white flex items-center justify-center">
                <ShoppingBag size={19} />
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-white text-orange-800 text-xs font-black flex items-center justify-center shadow-xs">
                  {totalQuantity}
                </span>
              </div>
              <div className="text-right rtl:text-right ltr:text-left">
                <div className="font-black text-sm text-white">{t('viewCart')}</div>
                <div className="text-xs text-stone-400 font-medium">{totalQuantity} أصناف مضافة</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="font-black text-base text-amber-400">
                {formatCurrency(totalPrice, currency, lang)}
              </span>
            </div>
          </button>
        </div>
      )}

      {/* Cart Bottom Sheet (Smooth Slide-Up Modal) */}
      {isOpen && (
        <div className="modal-overlay" onClick={onClose}>
          <div
            className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md overflow-hidden shadow-2xl animate-slide-up sm:animate-fade fixed sm:relative bottom-0 max-h-[85vh] flex flex-col border border-stone-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-[#FAF7F2]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-orange-700 text-white flex items-center justify-center">
                  <ShoppingBag size={16} />
                </div>
                <h2 className="font-black text-stone-900 text-base">
                  {t('viewCart')} ({totalQuantity})
                </h2>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-stone-200 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition"
              >
                <X size={17} />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1 divide-y divide-stone-100">
              {cart.length === 0 ? (
                <div className="py-12 text-center text-stone-400 space-y-2">
                  <ShoppingBag size={40} className="mx-auto text-stone-300 stroke-1" />
                  <p className="text-sm font-bold">{t('cartEmpty')}</p>
                </div>
              ) : (
                cart.map((item, idx) => {
                  const itemName = lang === 'ar' ? item.name_ar : (item.name_en || item.name_ar);
                  const itemTotal = item.price * item.quantity;
                  return (
                    <div key={idx} className="pt-3 first:pt-0 flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-black text-stone-800 text-sm truncate">{itemName}</h4>
                          <span className="font-black text-orange-700 text-xs whitespace-nowrap">
                            {formatCurrency(itemTotal, currency, lang)}
                          </span>
                        </div>
                        {item.notes && (
                          <p className="text-xs text-stone-600 bg-[#FAF7F2] rounded-lg p-2 mt-1.5 border border-stone-200/80 font-medium">
                            ملاحظة: {item.notes}
                          </p>
                        )}
                        <div className="flex items-center gap-3 mt-2.5">
                          <div className="flex items-center gap-2 bg-stone-100 px-2.5 py-1 rounded-full border border-stone-200">
                            <button
                              onClick={() => onUpdateQuantity(idx, item.quantity - 1)}
                              className="w-5 h-5 rounded-full bg-white text-stone-700 flex items-center justify-center text-xs shadow-xs hover:bg-stone-50"
                            >
                              <Minus size={11} />
                            </button>
                            <span className="font-black text-xs min-w-[16px] text-center">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                              className="w-5 h-5 rounded-full bg-white text-stone-700 flex items-center justify-center text-xs shadow-xs hover:bg-stone-50"
                            >
                              <Plus size={11} />
                            </button>
                          </div>

                          <button
                            onClick={() => onRemoveItem(idx)}
                            className="text-stone-400 hover:text-red-600 p-1 transition"
                            title={t('delete')}
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Cart Footer */}
            {cart.length > 0 && (
              <div className="p-4 border-t border-stone-100 bg-[#FAF7F2] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-stone-600">{t('total')}</span>
                  <span className="text-lg font-black text-stone-900">
                    {formatCurrency(totalPrice, currency, lang)}
                  </span>
                </div>

                <button
                  disabled={isSubmitting}
                  onClick={onSubmitOrder}
                  className="w-full btn btn-primary py-3.5 text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-950/20 active:scale-98"
                >
                  {isSubmitting ? (
                    <span className="font-bold">جاري إرسال الطلب للمطبخ...</span>
                  ) : (
                    <>
                      <Send size={16} />
                      <span className="font-black">{t('sendOrder')}</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
