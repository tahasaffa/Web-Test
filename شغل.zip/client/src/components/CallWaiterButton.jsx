import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Bell, Check, Loader2 } from 'lucide-react';
import { soundAlerts } from './AudioAlert';

export default function CallWaiterButton({ tableId }) {
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [called, setCalled] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    let timer = null;
    if (cooldown > 0) {
      timer = setInterval(() => {
        setCooldown(prev => prev - 1);
      }, 1000);
    } else {
      setCalled(false);
    }
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleCall = async () => {
    if (!tableId || cooldown > 0 || loading) return;

    setLoading(true);
    try {
      const res = await fetch('/api/staff-calls', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ table_id: tableId })
      });
      const data = await res.json();

      if (data.success) {
        soundAlerts.playSuccess();
        setCalled(true);
        setCooldown(45); // 45 seconds cooldown
      } else if (data.retryAfter) {
        setCooldown(data.retryAfter);
      } else {
        alert(data.error || 'فشل في نداء الويتر');
      }
    } catch (err) {
      alert('تعذر الاتصال بالسيرفر');
    } finally {
      setLoading(false);
    }
  };

  if (!tableId) return null;

  return (
    <div className="fixed bottom-20 rtl:left-4 ltr:right-4 z-20">
      <button
        onClick={handleCall}
        disabled={loading || cooldown > 0}
        className={`flex items-center gap-2 px-4 py-2.5 rounded-full shadow-lg transition duration-200 border ${
          called
            ? 'bg-emerald-600 text-white border-emerald-500'
            : cooldown > 0
            ? 'bg-slate-800 text-slate-400 border-slate-700 cursor-not-allowed'
            : 'bg-white text-slate-800 border-slate-200 hover:border-orange-500 hover:text-orange-600 hover:shadow-xl'
        }`}
        title={t('callWaiter')}
      >
        {loading ? (
          <Loader2 size={18} className="animate-spin text-orange-500" />
        ) : called ? (
          <Check size={18} className="text-white" />
        ) : (
          <Bell size={18} className={cooldown > 0 ? 'text-slate-400' : 'text-orange-500 animate-bounce'} />
        )}

        <span className="text-xs font-bold">
          {loading
            ? 'جاري النداء...'
            : called
            ? t('waiterCalled')
            : cooldown > 0
            ? `${cooldown}s`
            : t('callWaiter')}
        </span>
      </button>
    </div>
  );
}
