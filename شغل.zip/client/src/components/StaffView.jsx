import React, { useState, useEffect } from 'react';
import { useSocket } from '../context/SocketContext';
import { useLanguage } from '../context/LanguageContext';
import { soundAlerts } from './AudioAlert';
import { formatCurrency } from '../utils/formatCurrency';
import {
  ChefHat, Receipt, Bell, Volume2, VolumeX, LogOut, CheckCircle,
  Clock, Sparkles, AlertTriangle, Globe, Lock, Users, MessageSquareWarning,
  Plus, Check, Utensils, Coffee, AlertCircle, CreditCard
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function StaffView() {
  const { socket, joinStaff } = useSocket();
  const { lang, toggleLanguage, t } = useLanguage();

  const [token, setToken] = useState(() => localStorage.getItem('staff_token') || '');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Active Tab: 'kds' | 'cashier' | 'calls' | 'incidents' | 'directory'
  const [activeTab, setActiveTab] = useState('kds');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Data
  const [orders, setOrders] = useState([]);
  const [calls, setCalls] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [staffDirectory, setStaffDirectory] = useState([]);
  const [loadingData, setLoadingData] = useState(false);

  // Incident Modal
  const [isIncidentModalOpen, setIsIncidentModalOpen] = useState(false);
  const [incidentForm, setIncidentForm] = useState({
    table_number: '',
    reported_by: '',
    issue_type: 'تأخير في الطلب',
    description: '',
    priority: 'normal'
  });

  useEffect(() => {
    if (token) {
      joinStaff(token);
      loadStaffData();
    }
  }, [token]);

  useEffect(() => {
    if (!socket || !token) return;

    const handleNewOrder = (order) => {
      if (soundEnabled) soundAlerts.playNewOrder();
      setOrders(prev => [order, ...prev.filter(o => o.id !== order.id)]);
    };

    const handleOrderStatusUpdate = (updatedOrder) => {
      setOrders(prev => {
        if (updatedOrder.status === 'paid' || updatedOrder.status === 'cancelled') {
          return prev.filter(o => o.id !== updatedOrder.id);
        }
        return prev.map(o => (o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
      });
    };

    const handleNewStaffCall = (call) => {
      if (soundEnabled) soundAlerts.playWaiterCall();
      setCalls(prev => [call, ...prev.filter(c => c.id !== call.id)]);
    };

    const handleStaffCallAck = (ackCall) => {
      setCalls(prev => prev.filter(c => c.id !== ackCall.id));
    };

    const handleTableSettled = ({ tableId }) => {
      setOrders(prev => prev.filter(o => o.table_id !== tableId));
    };

    socket.on('new_order', handleNewOrder);
    socket.on('order_status_updated', handleOrderStatusUpdate);
    socket.on('new_staff_call', handleNewStaffCall);
    socket.on('staff_call_acknowledged', handleStaffCallAck);
    socket.on('table_settled', handleTableSettled);

    return () => {
      socket.off('new_order', handleNewOrder);
      socket.off('order_status_updated', handleOrderStatusUpdate);
      socket.off('new_staff_call', handleNewStaffCall);
      socket.off('staff_call_acknowledged', handleStaffCallAck);
      socket.off('table_settled', handleTableSettled);
    };
  }, [socket, token, soundEnabled]);

  useEffect(() => {
    if (!token) return;
    const interval = setInterval(() => {
      loadStaffData(false);
    }, 15000);
    return () => clearInterval(interval);
  }, [token]);

  const loadStaffData = async (showLoading = true) => {
    if (showLoading) setLoadingData(true);
    try {
      const headers = { 'Authorization': `Bearer ${token}` };
      const [ordersRes, callsRes, incidentsRes, dirRes] = await Promise.all([
        fetch('/api/staff/orders', { headers }),
        fetch('/api/staff/calls', { headers }),
        fetch('/api/staff/incidents', { headers }),
        fetch('/api/staff/members', { headers })
      ]);

      if (ordersRes.status === 401 || ordersRes.status === 403) {
        handleLogout();
        return;
      }

      const [ordersData, callsData, incidentsData, dirData] = await Promise.all([
        ordersRes.json(), callsRes.json(), incidentsRes.json(), dirRes.json()
      ]);

      if (ordersData.success) setOrders(ordersData.data);
      if (callsData.success) setCalls(callsData.data);
      if (incidentsData.success) setIncidents(incidentsData.data);
      if (dirData.success) setStaffDirectory(dirData.data);
    } catch (e) {
      console.error('Failed loading staff data', e);
    } finally {
      if (showLoading) setLoadingData(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!password) return;
    setIsLoggingIn(true);
    setLoginError('');
    try {
      const res = await fetch('/api/staff/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (data.success) {
        localStorage.setItem('staff_token', data.token);
        setToken(data.token);
        setPassword('');
      } else {
        setLoginError(data.error || 'كلمة المرور غير صحيحة');
      }
    } catch (err) {
      setLoginError('تعذر الاتصال بالخادم');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('staff_token');
    setToken('');
    setOrders([]);
    setCalls([]);
  };

  const handleUpdateStatus = async (orderId, newStatus) => {
    try {
      const res = await fetch(`/api/staff/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ status: newStatus })
      });
      const data = await res.json();
      if (data.success) {
        soundAlerts.playSuccess();
        setOrders(prev => prev.map(o => (o.id === orderId ? { ...o, status: newStatus } : o)));
      }
    } catch (e) {
      alert('فشل تحديث حالة الطلب');
    }
  };

  const handleSettleTable = async (tableId, tableNumber) => {
    if (!confirm(`هل أنت متأكد من تسوية وإغلاق حساب طاولة #${tableNumber} واستلام المبلغ؟`)) return;
    try {
      const res = await fetch(`/api/staff/tables/${tableId}/settle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        confetti({ particleCount: 80, spread: 60, origin: { y: 0.5 } });
        setOrders(prev => prev.filter(o => o.table_id !== tableId));
      }
    } catch (e) {
      alert('فشل إغلاق الحساب');
    }
  };

  const handleAcknowledgeCall = async (callId) => {
    try {
      const res = await fetch(`/api/staff/calls/${callId}/acknowledge`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        soundAlerts.playSuccess();
        setCalls(prev => prev.filter(c => c.id !== callId));
      }
    } catch (e) {
      alert('فشل تأكيد تلبية النداء');
    }
  };

  const handleLogIncident = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/staff/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify(incidentForm)
      });
      const data = await res.json();
      if (data.success) {
        setIsIncidentModalOpen(false);
        setIncidentForm({
          table_number: '',
          reported_by: '',
          issue_type: 'تأخير في الطلب',
          description: '',
          priority: 'normal'
        });
        loadStaffData();
      } else {
        alert(data.error);
      }
    } catch (err) {
      alert('فشل تسجيل البلاغ');
    }
  };

  const handleUpdateIncidentStatus = async (id, status) => {
    try {
      const res = await fetch(`/api/staff/incidents/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ status })
      });
      const data = await res.json();
      if (data.success) {
        setIncidents(prev => prev.map(inc => (inc.id === id ? { ...inc, status } : inc)));
      }
    } catch (e) {
      alert('فشل تحديث حالة البلاغ');
    }
  };

  // 1. Password-only Login Screen (CONFIDENTIAL - ZERO DEFAULT PASSWORDS ON SCREEN)
  if (!token) {
    return (
      <div className="min-h-screen bg-[#141210] flex items-center justify-center p-4">
        <div className="card w-full max-w-sm p-8 bg-[#201D1A] border-[#38332E] text-white animate-fade shadow-2xl">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-700 text-white flex items-center justify-center mx-auto mb-4 shadow-xl shadow-black/60 border border-amber-500/30">
            <Lock size={28} />
          </div>
          <h2 className="text-xl font-black text-center mb-1 tracking-tight">بوابة الموظفين | Staff Portal</h2>
          <p className="text-xs text-[#A8A29E] text-center mb-6 font-medium">
            يرجى إدخال كلمة المرور المخصصة لطاقم الخدمة للمتابعة
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && (
              <div className="p-3 rounded-xl bg-red-950/70 border border-red-800 text-red-300 text-xs font-bold text-center">
                {loginError}
              </div>
            )}

            <div>
              <input
                type="password"
                required
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="كلمة المرور"
                className="w-full bg-[#141210] text-white placeholder:text-[#78716C] rounded-xl px-4 py-3.5 border border-[#38332E] focus:border-amber-500 outline-none text-sm transition"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full btn btn-primary py-3.5 text-sm font-black shadow-md shadow-orange-950/50"
            >
              {isLoggingIn ? 'جاري التحقق...' : 'تسجيل الدخول'}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-[#38332E] flex justify-end items-center text-xs text-[#A8A29E]">
            <button onClick={toggleLanguage} className="hover:text-white flex items-center gap-1.5 font-bold">
              <Globe size={14} />
              <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Active tables summary
  const tableSummaryMap = {};
  orders.forEach(order => {
    if (!tableSummaryMap[order.table_id]) {
      tableSummaryMap[order.table_id] = {
        table_id: order.table_id,
        table_number: order.table_number,
        orders: [],
        total_amount: 0
      };
    }
    tableSummaryMap[order.table_id].orders.push(order);
    tableSummaryMap[order.table_id].total_amount += order.total_amount;
  });
  const activeTablesList = Object.values(tableSummaryMap);

  return (
    <div className="min-h-screen bg-[#FAF7F2] flex flex-col">
      {/* Top Navbar */}
      <header className="bg-[#1C1917] text-white px-4 py-3 sticky top-0 z-30 shadow-md border-b border-stone-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center font-bold shadow-sm">
              <ChefHat size={22} />
            </div>
            <div>
              <h1 className="font-black text-sm md:text-base leading-tight tracking-tight">
                طاقم الخدمة | Staff Portal
              </h1>
              <span className="text-[11px] text-stone-400 font-semibold">
                {orders.length} طلبات نشطة • {calls.length} نداءات • {incidents.filter(i => i.status === 'open').length} بلاغات
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-xl text-xs font-bold transition border border-stone-700 ${
                soundEnabled ? 'bg-stone-800 text-emerald-400' : 'bg-stone-800 text-stone-500'
              }`}
              title={soundEnabled ? 'كتم التنبيه الصوتي' : 'تفعيل التنبيه الصوتي'}
            >
              {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>

            <button
              onClick={toggleLanguage}
              className="p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white border border-stone-700 text-xs font-bold transition"
            >
              <Globe size={16} />
            </button>

            <button
              onClick={handleLogout}
              className="p-2.5 rounded-xl bg-stone-800 hover:bg-red-950/60 text-stone-300 hover:text-red-400 border border-stone-700 text-xs font-bold transition"
              title={t('logout')}
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>

        {/* Spacious, Distinct Navigation Tabs */}
        <div className="max-w-7xl mx-auto mt-3 pt-2.5 border-t border-stone-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('kds')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition flex-shrink-0 ${
              activeTab === 'kds'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-950/30'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <ChefHat size={16} />
            <span>طلبات المطبخ (KDS)</span>
            {orders.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-white text-orange-800 text-[11px] font-black">
                {orders.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('cashier')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition flex-shrink-0 ${
              activeTab === 'cashier'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-950/30'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <Receipt size={16} />
            <span>شاشة الكاشير</span>
            {activeTablesList.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-white text-stone-900 text-[11px] font-black">
                {activeTablesList.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('calls')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition flex-shrink-0 ${
              activeTab === 'calls'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-950/30'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <Bell size={16} className={calls.length > 0 ? 'text-amber-400 animate-bounce' : ''} />
            <span>نداءات الويتر</span>
            {calls.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-black">
                {calls.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('incidents')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition flex-shrink-0 ${
              activeTab === 'incidents'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-950/30'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <MessageSquareWarning size={16} />
            <span>سجل المشاكل والبلاغات</span>
            {incidents.filter(i => i.status === 'open').length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-500 text-stone-950 text-[11px] font-black">
                {incidents.filter(i => i.status === 'open').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('directory')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition flex-shrink-0 ${
              activeTab === 'directory'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-950/30'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <Users size={16} />
            <span>طاقم العمل المتاح</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl w-full mx-auto p-4 sm:p-6 flex-1">
        {/* ================================================= */}
        {/* TAB 1: KITCHEN DISPLAY (KDS) */}
        {/* ================================================= */}
        {activeTab === 'kds' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-black text-stone-900 text-xl tracking-tight">شاشة المطبخ (KDS)</h2>
                <p className="text-xs text-stone-500 font-medium">الطلبات الواردة مرتبة حسب وقت الوصول مع التنبيه الصوتي</p>
              </div>
              <span className="text-xs font-black text-stone-600 bg-white border border-stone-200 px-3.5 py-1.5 rounded-full shadow-xs">
                {orders.length} طلبات قيد العمل
              </span>
            </div>

            {orders.length === 0 ? (
              <div className="card p-14 text-center max-w-md mx-auto my-12 space-y-4 bg-white border-stone-200 shadow-sm">
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <Utensils size={32} />
                </div>
                <div>
                  <h3 className="font-black text-stone-800 text-base">لا توجد طلبات معلقة بالمطبخ حالياً</h3>
                  <p className="text-xs text-stone-400 mt-1 font-medium">
                    جميع الأطباق تم تحضيرها وتقديمها بنجاح! ستظهر الطلبات الجديدة هنا فور إرسالها من الزبائن.
                  </p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
                {orders.map(order => {
                  const isNew = order.status === 'new';
                  const isPrep = order.status === 'preparing';
                  const isReady = order.status === 'ready';

                  return (
                    <div
                      key={order.id}
                      className={`card flex flex-col justify-between border-2 transition-all shadow-sm ${
                        isNew
                          ? 'border-orange-500 bg-[#FFFDF9]'
                          : isPrep
                          ? 'border-amber-400 bg-[#FFFDF6]'
                          : 'border-blue-400 bg-[#F7FAFD]'
                      }`}
                    >
                      {/* Top Header */}
                      <div className="p-4 border-b border-stone-100 flex items-center justify-between">
                        <div>
                          <span className="font-black text-stone-900 text-lg">
                            طاولة #{order.table_number}
                          </span>
                          <span className="text-[11px] text-stone-400 block font-mono">
                            #{order.id.substring(0, 6)} • {new Date(order.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <span className={`badge ${
                          isNew ? 'badge-new' : isPrep ? 'badge-preparing' : 'badge-ready'
                        }`}>
                          {isNew ? 'طلب جديد' : isPrep ? 'قيد التحضير' : 'جاهز للتقديم'}
                        </span>
                      </div>

                      {/* Items List */}
                      <div className="p-4 space-y-2.5 flex-1 overflow-y-auto max-h-64">
                        {order.items?.map((item, idx) => (
                          <div key={idx} className="bg-white p-3 rounded-xl border border-stone-200/90 shadow-xs">
                            <div className="font-black text-stone-900 text-sm">
                              {item.quantity}x {item.name_ar}
                            </div>
                            {item.notes && (
                              <div className="mt-1.5 text-xs font-bold text-red-700 bg-red-50 p-2 rounded-lg border border-red-200 flex items-center gap-1.5">
                                <AlertTriangle size={14} className="flex-shrink-0" />
                                <span>ملاحظة: {item.notes}</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      {/* Action Buttons */}
                      <div className="p-3.5 border-t border-stone-100 bg-[#FAF7F2] space-y-2">
                        {isNew && (
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'preparing')}
                            className="w-full btn btn-primary py-2.5 text-xs font-black flex items-center justify-center gap-1.5 shadow-sm"
                          >
                            <Clock size={15} />
                            <span>بدء التحضير بالمطبخ</span>
                          </button>
                        )}
                        {isPrep && (
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'ready')}
                            className="w-full btn btn-success py-2.5 text-xs font-black flex items-center justify-center gap-1.5 shadow-sm"
                          >
                            <Sparkles size={15} />
                            <span>جاهز للتقديم للزبون</span>
                          </button>
                        )}
                        {isReady && (
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'served')}
                            className="w-full btn bg-stone-900 hover:bg-black text-white py-2.5 text-xs font-black flex items-center justify-center gap-1.5 shadow-sm"
                          >
                            <CheckCircle size={15} />
                            <span>تم التقديم للطاولة</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 2: CASHIER & BILLING */}
        {/* ================================================= */}
        {activeTab === 'cashier' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-black text-stone-900 text-xl tracking-tight">شاشة الكاشير وتسوية الحسابات</h2>
                <p className="text-xs text-stone-500 font-medium">متابعة حسابات الطاولات المشغولة بالدينار العراقي (IQD)</p>
              </div>
              <span className="text-xs font-black text-stone-600 bg-white border border-stone-200 px-3.5 py-1.5 rounded-full shadow-xs">
                {activeTablesList.length} طاولات نشطة
              </span>
            </div>

            {activeTablesList.length === 0 ? (
              <div className="card p-14 text-center max-w-md mx-auto my-12 space-y-4 bg-white border-stone-200 shadow-sm">
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle size={32} />
                </div>
                <div>
                  <h3 className="font-black text-stone-800 text-base">جميع الحسابات مسددة</h3>
                  <p className="text-xs text-stone-400 mt-1 font-medium">لا توجد أي فواتير معلقة حالياً.</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {activeTablesList.map(tbl => (
                  <div key={tbl.table_id} className="card p-5 flex flex-col justify-between border-2 border-stone-200 hover:border-orange-500 transition bg-white shadow-sm">
                    <div>
                      <div className="flex items-center justify-between pb-3.5 border-b border-stone-100">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-700 to-amber-700 text-white flex items-center justify-center font-black text-xl shadow-sm">
                            {tbl.table_number}
                          </div>
                          <div>
                            <h3 className="font-black text-stone-900 text-base">
                              طاولة #{tbl.table_number}
                            </h3>
                            <span className="text-xs text-stone-400 font-medium">
                              {tbl.orders.length} طلبات منفصلة
                            </span>
                          </div>
                        </div>

                        <div className="text-right rtl:text-right ltr:text-left">
                          <span className="text-[11px] text-stone-400 font-bold block">إجمالي الحساب</span>
                          <span className="text-lg font-black text-orange-800">
                            {formatCurrency(tbl.total_amount, 'IQD', lang)}
                          </span>
                        </div>
                      </div>

                      <div className="py-3.5 space-y-2 text-xs divide-y divide-stone-50 max-h-56 overflow-y-auto">
                        {tbl.orders.map(o => (
                          <div key={o.id} className="pt-2 first:pt-0">
                            <div className="flex justify-between font-bold text-stone-700 mb-1">
                              <span>طلب #{o.id.substring(0, 5)}</span>
                              <span className="badge badge-new text-[10px]">{o.status}</span>
                            </div>
                            {o.items?.map((item, i) => (
                              <div key={i} className="flex justify-between text-stone-500 font-medium">
                                <span>{item.quantity}x {item.name_ar}</span>
                                <span className="font-bold">{formatCurrency(item.price_at_order * item.quantity, 'IQD', lang)}</span>
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-stone-100 mt-2">
                      <button
                        onClick={() => handleSettleTable(tbl.table_id, tbl.table_number)}
                        className="w-full btn btn-success py-3 text-xs font-black flex items-center justify-center gap-2 shadow-xs"
                      >
                        <Receipt size={16} />
                        <span>تأكيد الدفع وإغلاق حساب طاولة #{tbl.table_number}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 3: WAITER CALLS DEDICATED SECTION */}
        {/* ================================================= */}
        {activeTab === 'calls' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-black text-stone-900 text-xl flex items-center gap-2">
                  <Bell className="text-amber-700" />
                  <span>نداءات الويتر المباشرة</span>
                </h2>
                <p className="text-xs text-stone-500 font-medium">إشارات النداء الواردة من الطاولات مع توقيت الطلب</p>
              </div>
              <span className="text-xs font-black text-stone-600 bg-amber-100 border border-amber-300 px-3.5 py-1.5 rounded-full shadow-xs">
                {calls.length} نداءات معلقة
              </span>
            </div>

            {calls.length === 0 ? (
              <div className="card p-14 text-center max-w-md mx-auto my-12 space-y-4 bg-white border-stone-200 shadow-sm">
                <div className="w-16 h-16 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
                  <Bell size={32} />
                </div>
                <div>
                  <h3 className="font-black text-stone-800 text-base">لا توجد نداءات معلقة</h3>
                  <p className="text-xs text-stone-400 mt-1 font-medium">
                    عندما يضغط الزبون على "نداء الويتر" سيصدر رنين تنبيه وتظهر الطاولة هنا فوراً.
                  </p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {calls.map(call => {
                  const isPayment = call.call_type === 'payment';

                  return (
                    <div
                      key={call.id}
                      className={`card p-5 border-2 flex flex-col justify-between space-y-4 shadow-md transition ${
                        isPayment
                          ? 'border-emerald-500 bg-[#F4FBF7]'
                          : 'border-amber-500 bg-[#FFFDF8]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div
                          className={`w-11 h-11 rounded-2xl text-white flex items-center justify-center font-black text-lg shadow-sm ${
                            isPayment
                              ? 'bg-gradient-to-br from-emerald-600 to-teal-700'
                              : 'bg-gradient-to-br from-amber-600 to-orange-700'
                          }`}
                        >
                          #{call.table_number}
                        </div>
                        <span
                          className={`badge text-[10px] font-black ${
                            isPayment
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 animate-pulse'
                              : 'badge-new animate-pulse'
                          }`}
                        >
                          {isPayment ? '💳 طلب الحساب والدفع' : '🔔 ينتظر الويتر'}
                        </span>
                      </div>

                      <div>
                        <h4 className="font-black text-stone-900 text-base">
                          طاولة رقم #{call.table_number}
                        </h4>
                        <p className={`text-xs mt-1 font-bold ${isPayment ? 'text-emerald-800' : 'text-stone-500'}`}>
                          {isPayment
                            ? 'انتهى الزبون من طعامه ويريد إحضار الفاتورة والدفع'
                            : `وقت النداء: ${new Date(call.created_at).toLocaleTimeString()}`}
                        </p>
                      </div>

                      <button
                        onClick={() => handleAcknowledgeCall(call.id)}
                        className={`w-full btn py-3 text-xs font-black flex items-center justify-center gap-2 shadow-xs ${
                          isPayment ? 'btn-primary bg-emerald-700 hover:bg-emerald-800' : 'btn-primary'
                        }`}
                      >
                        <Check size={16} />
                        <span>{isPayment ? 'تم استلام الحساب والدفع' : 'تمت التلبية والمساعدة'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 4: INCIDENTS & ISSUES SECTION */}
        {/* ================================================= */}
        {activeTab === 'incidents' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="font-black text-stone-900 text-xl flex items-center gap-2">
                  <MessageSquareWarning className="text-orange-700" />
                  <span>بلاغات ومشاكل الخدمة</span>
                </h2>
                <p className="text-xs text-stone-500 font-medium">تسجيل وتوثيق أي تأخير أو ملاحظات من الزبائن لمتابعتها فوراً</p>
              </div>

              <button
                onClick={() => setIsIncidentModalOpen(true)}
                className="btn btn-primary py-2.5 px-4 text-xs font-black flex items-center gap-2 shadow-sm"
              >
                <Plus size={16} />
                <span>تسجيل بلاغ / مشكلة جديدة</span>
              </button>
            </div>

            <div className="card overflow-hidden bg-white border-stone-200">
              <div className="divide-y divide-stone-100">
                {incidents.length === 0 ? (
                  <div className="p-10 text-center text-stone-400 text-xs font-medium">
                    لا توجد أي بلاغات تشغيلية مسجلة حالياً.
                  </div>
                ) : (
                  incidents.map(inc => (
                    <div key={inc.id} className="p-4.5 flex items-start justify-between gap-4 hover:bg-[#FAF7F2] transition">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-black text-stone-900 text-sm">{inc.issue_type}</span>
                          {inc.table_number && (
                            <span className="bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full text-[10px] font-black border border-amber-300">
                              طاولة #{inc.table_number}
                            </span>
                          )}
                          <span className={`badge text-[10px] ${
                            inc.status === 'resolved' ? 'badge-served' : inc.status === 'in_progress' ? 'badge-preparing' : 'badge-cancelled'
                          }`}>
                            {inc.status === 'resolved' ? 'تم الحل' : inc.status === 'in_progress' ? 'قيد المتابعة' : 'مفتوح'}
                          </span>
                        </div>
                        <p className="text-xs text-stone-700 leading-relaxed font-medium">{inc.description}</p>
                        <div className="text-[11px] text-stone-400 flex items-center gap-2">
                          <span>المسجل: {inc.reported_by}</span>
                          <span>•</span>
                          <span>{new Date(inc.created_at).toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        {inc.status !== 'resolved' && (
                          <button
                            onClick={() => handleUpdateIncidentStatus(inc.id, 'resolved')}
                            className="btn btn-success py-1.5 px-3 text-xs font-black"
                          >
                            تأكيد الحل
                          </button>
                        )}
                        {inc.status === 'open' && (
                          <button
                            onClick={() => handleUpdateIncidentStatus(inc.id, 'in_progress')}
                            className="btn btn-secondary py-1.5 px-3 text-xs font-bold"
                          >
                            بدء المتابعة
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ================================================= */}
        {/* TAB 5: STAFF ON DUTY DIRECTORY */}
        {/* ================================================= */}
        {activeTab === 'directory' && (
          <div className="space-y-4">
            <div>
              <h2 className="font-black text-stone-900 text-xl flex items-center gap-2">
                <Users className="text-orange-700" />
                <span>طاقم العمل والورديات</span>
              </h2>
              <p className="text-xs text-stone-500 font-medium">دليل الموظفين والمسؤولين المناوبين</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {staffDirectory.map(staff => (
                <div key={staff.id} className="card p-4.5 bg-white border-stone-200 flex items-center gap-3.5 shadow-xs">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-800 flex items-center justify-center font-black text-lg border border-amber-200 flex-shrink-0">
                    {staff.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-black text-stone-900 text-sm truncate">{staff.name}</h4>
                    <p className="text-xs text-stone-500 font-medium truncate">{staff.role}</p>
                    <span className="inline-block text-[10px] font-bold text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-full mt-1.5 border border-amber-200">
                      الوردية: {staff.shift || 'صباحي'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Incident Modal */}
      {isIncidentModalOpen && (
        <div className="modal-overlay" onClick={() => setIsIncidentModalOpen(false)}>
          <div
            className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6 space-y-4 animate-fade border border-stone-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-black text-stone-900 text-base">تسجيل بلاغ تشغيلي جديد</h3>
              <button
                onClick={() => setIsIncidentModalOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleLogIncident} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-stone-700 block mb-1">اسم الموظف المبلغ *</label>
                <input
                  type="text"
                  required
                  value={incidentForm.reported_by}
                  onChange={(e) => setIncidentForm({ ...incidentForm, reported_by: e.target.value })}
                  placeholder="مثال: سامي (ويتر)"
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold focus:border-orange-600 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">رقم الطاولة</label>
                  <input
                    type="number"
                    value={incidentForm.table_number}
                    onChange={(e) => setIncidentForm({ ...incidentForm, table_number: e.target.value })}
                    placeholder="رقم الطاولة"
                    className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold focus:border-orange-600 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">نوع المشكلة *</label>
                  <select
                    value={incidentForm.issue_type}
                    onChange={(e) => setIncidentForm({ ...incidentForm, issue_type: e.target.value })}
                    className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none font-bold focus:border-orange-600 focus:bg-white"
                  >
                    <option value="تأخير في الطلب">تأخير في الطلب</option>
                    <option value="صنف غير مطابق">صنف غير مطابق</option>
                    <option value="شكوى من الزبون">شكوى من الزبون</option>
                    <option value="تكييف / صالة">تكييف / صالة</option>
                    <option value="أخرى">أخرى</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">تفاصيل البلاغ *</label>
                <textarea
                  required
                  rows={3}
                  value={incidentForm.description}
                  onChange={(e) => setIncidentForm({ ...incidentForm, description: e.target.value })}
                  placeholder="اشرح المشكلة بدقة..."
                  className="w-full bg-[#FAF7F2] border border-stone-200 rounded-xl p-3 outline-none resize-none font-medium focus:border-orange-600 focus:bg-white"
                />
              </div>

              <button type="submit" className="w-full btn btn-primary py-3.5 text-xs font-black shadow-md">
                حفظ وإرسال البلاغ
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
