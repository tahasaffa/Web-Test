import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/formatCurrency';
import { X, Receipt, CheckCircle2 } from 'lucide-react';

export default function BillSummaryModal({ isOpen, onClose, billData, currency = 'IQD' }) {
  const { lang, t } = useLanguage();

  if (!isOpen) return null;

  const orders = billData?.activeOrders || [];
  const totalAmount = billData?.total_bill_amount || 0;
  const tableNumber = billData?.table_number;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl animate-fade flex flex-col max-h-[85vh] border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-[#FAF7F2]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-orange-700 text-white flex items-center justify-center">
              <Receipt size={17} />
            </div>
            <h2 className="font-black text-stone-900 text-base">
              {t('billSummary')} {tableNumber ? `(#${tableNumber})` : ''}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition"
          >
            <X size={17} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 divide-y divide-stone-100">
          {orders.length === 0 ? (
            <div className="py-12 text-center text-stone-400">
              <CheckCircle2 size={44} className="mx-auto text-emerald-600 mb-2 stroke-1" />
              <p className="font-black text-stone-700">لا توجد طلبات معلقة للدفع</p>
              <p className="text-xs text-stone-400 mt-1">حساب الطاولة مسدد بالكامل أو لم يتم إرسال طلبات بعد.</p>
            </div>
          ) : (
            orders.map((order) => (
              <div key={order.id} className="pt-3 first:pt-0 space-y-2">
                <div className="flex items-center justify-between text-xs font-black text-stone-600">
                  <span>طلب #{order.id.substring(0, 6)}</span>
                  <span className="badge badge-new">{t(`status${order.status.charAt(0).toUpperCase() + order.status.slice(1)}`)}</span>
                </div>

                <div className="space-y-1.5">
                  {order.items?.map((item, iIdx) => {
                    const name = lang === 'ar' ? item.name_ar : (item.name_en || item.name_ar);
                    return (
                      <div key={iIdx} className="flex items-center justify-between text-xs text-stone-700">
                        <span>
                          {item.quantity}x {name}
                        </span>
                        <span className="font-bold">
                          {formatCurrency(item.price_at_order * item.quantity, currency, lang)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {orders.length > 0 && (
          <div className="p-4 border-t border-stone-100 bg-[#FAF7F2] space-y-2">
            <div className="flex items-center justify-between text-sm font-black">
              <span className="text-stone-700">{t('unpaidTotal')}</span>
              <span className="text-xl font-black text-orange-800">
                {formatCurrency(totalAmount, currency, lang)}
              </span>
            </div>
            <p className="text-[11px] text-center text-stone-400 font-medium">
              يتم سداد الحساب لدى الكاشير أو نقداً مع الويتر عند المغادرة.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
