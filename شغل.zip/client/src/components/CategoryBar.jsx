import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Search } from 'lucide-react';

export default function CategoryBar({ categories, activeCategory, onSelectCategory, searchQuery, onSearchChange }) {
  const { lang, t } = useLanguage();

  return (
    <div className="sticky top-[65px] z-30 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-stone-200/90 px-4 py-3 space-y-2.5 max-w-lg mx-auto w-full">
      {/* Search Bar */}
      <div className="relative">
        <Search
          className="absolute top-1/2 -translate-y-1/2 text-stone-400 rtl:right-3.5 ltr:left-3.5"
          size={16}
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full bg-white text-stone-900 placeholder:text-stone-400 text-xs sm:text-sm rounded-xl py-2.5 rtl:pr-10 rtl:pl-4 ltr:pl-10 ltr:pr-4 border border-stone-200/90 shadow-xs focus:border-orange-600 focus:ring-2 focus:ring-orange-600/10 outline-none transition"
        />
      </div>

      {/* Category Pills (Spacious, elegant horizontal scroll) */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        <button
          onClick={() => onSelectCategory('all')}
          className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-black transition-all duration-150 active:scale-95 flex items-center gap-1.5 ${
            activeCategory === 'all'
              ? 'bg-gradient-to-r from-orange-700 to-amber-700 text-white shadow-md shadow-orange-950/20'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50 hover:border-stone-300'
          }`}
        >
          <span>{t('allCategories')}</span>
        </button>

        {categories.map((cat) => {
          const name = lang === 'ar' ? cat.name_ar : (cat.name_en || cat.name_ar);
          const isSelected = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-black transition-all duration-150 active:scale-95 flex items-center gap-2 ${
                isSelected
                  ? 'bg-gradient-to-r from-orange-700 to-amber-700 text-white shadow-md shadow-orange-950/20'
                  : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50 hover:border-stone-300'
              }`}
            >
              <span>{name}</span>
              {cat.items && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-white/25 text-white' : 'bg-stone-100 text-stone-500'
                  }`}
                >
                  {cat.items.length}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
