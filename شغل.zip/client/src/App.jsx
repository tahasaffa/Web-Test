import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import CustomerView from './components/CustomerView';
import StaffView from './components/StaffView';
import AdminView from './components/AdminView';

export default function App() {
  return (
    <Routes>
      {/* Customer Page Routes */}
      <Route path="/" element={<CustomerView />} />
      <Route path="/menu" element={<CustomerView />} />
      <Route path="/table/:tableId" element={<CustomerView />} />

      {/* Staff Page Route (Kitchen & Cashier) */}
      <Route path="/staff" element={<StaffView />} />

      {/* Admin Dashboard Route */}
      <Route path="/admin" element={<AdminView />} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
