/**
 * Format currency amounts dynamically based on currency code and language.
 * - Iraqi Dinar (IQD): displayed without decimals and with thousand separators, e.g. 26,000 د.ع
 * - Other currencies: formatted with appropriate decimals if needed.
 */
export function formatCurrency(amount, currency = 'IQD', lang = 'ar') {
  const num = Number(amount) || 0;
  const isIQD = !currency || currency.toUpperCase() === 'IQD' || currency === 'د.ع';

  if (isIQD) {
    const rounded = Math.round(num);
    const formattedNum = rounded.toLocaleString('en-US');
    return `${formattedNum} ${lang === 'ar' ? 'د.ع' : 'IQD'}`;
  }

  // Other currencies (e.g. SAR, USD, EUR)
  const formatted = num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  return `${formatted} ${currency}`;
}
